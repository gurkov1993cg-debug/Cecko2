#include "ApolloController.hpp"
#include "PluginIds.hpp"

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "public.sdk/source/vst/vstparameters.h"

namespace Steinberg::Vst
{
tresult PLUGIN_API ApolloController::initialize(FUnknown* context)
{
    const auto result = EditController::initialize(context);
    if (result != kResultTrue)
        return result;

    parameters.addParameter(new RangeParameter(STR16("Drive"), kDriveId, STR16("dB"),
                                               -12.0, 12.0, 1.5, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Character"), kCharacterId, STR16("%"),
                                               0.0, 100.0, 35.0, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Output"), kOutputId, STR16("dB"),
                                               -12.0, 12.0, -1.5, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Mix"), kMixId, STR16("%"),
                                               0.0, 100.0, 100.0, 0,
                                               ParameterInfo::kCanAutomate));
    return kResultTrue;
}

tresult PLUGIN_API ApolloController::setComponentState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    float drive = 1.5f, character = 0.35f, output = -1.5f, mix = 1.0f;
    if (!s.readFloat(drive)) return kResultFalse;
    if (!s.readFloat(character)) return kResultFalse;
    if (!s.readFloat(output)) return kResultFalse;
    if (!s.readFloat(mix)) return kResultFalse;

    setParamNormalized(kDriveId, (drive + 12.0) / 24.0);
    setParamNormalized(kCharacterId, character);
    setParamNormalized(kOutputId, (output + 12.0) / 24.0);
    setParamNormalized(kMixId, mix);
    return kResultOk;
}
}
