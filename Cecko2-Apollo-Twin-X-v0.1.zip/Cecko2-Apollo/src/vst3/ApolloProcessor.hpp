#pragma once

#include "ApolloOutputModel.hpp"
#include "public.sdk/source/vst/vstaudioeffect.h"

namespace Steinberg::Vst
{
class ApolloProcessor final : public AudioEffect
{
public:
    ApolloProcessor();

    static FUnknown* createInstance(void*) { return static_cast<IAudioProcessor*>(new ApolloProcessor()); }

    tresult PLUGIN_API initialize(FUnknown* context) SMTG_OVERRIDE;
    tresult PLUGIN_API setBusArrangements(SpeakerArrangement* inputs, int32 numIns,
                                          SpeakerArrangement* outputs, int32 numOuts) SMTG_OVERRIDE;
    tresult PLUGIN_API setupProcessing(ProcessSetup& setup) SMTG_OVERRIDE;
    tresult PLUGIN_API setActive(TBool state) SMTG_OVERRIDE;
    tresult PLUGIN_API setProcessing(TBool state) SMTG_OVERRIDE;
    tresult PLUGIN_API process(ProcessData& data) SMTG_OVERRIDE;
    tresult PLUGIN_API setState(IBStream* state) SMTG_OVERRIDE;
    tresult PLUGIN_API getState(IBStream* state) SMTG_OVERRIDE;

private:
    void applyParameter(ParamID id, ParamValue normalized) noexcept;
    void pushParameters() noexcept;

    apollo::ApolloOutputModel model_;
    apollo::Parameters params_{};
    int32 numChannels_ = 2;
};
}
