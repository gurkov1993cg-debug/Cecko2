#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

namespace
{
constexpr float kPi = 3.14159265358979323846f;

void require(bool ok, const char* message)
{
    if (!ok)
    {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

float rmsOf(const std::vector<float>& v, int start = 0)
{
    double p = 0.0;
    const int n = static_cast<int>(v.size()) - start;
    for (int i = start; i < static_cast<int>(v.size()); ++i)
        p += static_cast<double>(v[i]) * static_cast<double>(v[i]);
    return n > 0 ? static_cast<float>(std::sqrt(p / n)) : 0.0f;
}

double toneAmplitude(const std::vector<float>& v, double sampleRate, double frequency)
{
    double re = 0.0;
    double im = 0.0;
    for (std::size_t i = 0; i < v.size(); ++i)
    {
        const double phase = 2.0 * static_cast<double>(kPi) * frequency
                           * static_cast<double>(i) / sampleRate;
        re += static_cast<double>(v[i]) * std::cos(phase);
        im -= static_cast<double>(v[i]) * std::sin(phase);
    }
    return 2.0 * std::sqrt(re * re + im * im) / static_cast<double>(v.size());
}

float measureThd(float inputAmplitude)
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel m;
    apollo::Parameters p;
    m.setParameters(p);
    m.prepare(48000.0, 1);

    // Let all transient and DC states settle before the FFT window.
    for (int i = 0; i < n; ++i)
    {
        const float x = inputAmplitude * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        m.processSample(x, 0);
    }

    std::vector<float> out(n);
    for (int i = 0; i < n; ++i)
    {
        const float x = inputAmplitude * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        out[i] = m.processSample(x, 0);
    }

    const double fundamental = toneAmplitude(out, 48000.0, 1000.0);
    double harmonicPower = 0.0;
    for (int h = 2; h <= 10; ++h)
    {
        const double a = toneAmplitude(out, 48000.0, 1000.0 * h);
        harmonicPower += a * a;
    }
    return static_cast<float>(std::sqrt(harmonicPower) / std::max(1.0e-12, fundamental));
}

float steadyToneGainDb(float frequency)
{
    constexpr int n = 48000;
    constexpr float amplitude = 0.02f;
    apollo::ApolloOutputModel m;
    apollo::Parameters p;
    m.setParameters(p);
    m.prepare(48000.0, 1);

    for (int i = 0; i < n; ++i)
    {
        const float x = amplitude * std::sin(2.0f * kPi * frequency * i / 48000.0f);
        m.processSample(x, 0);
    }

    std::vector<float> out(n);
    for (int i = 0; i < n; ++i)
    {
        const float x = amplitude * std::sin(2.0f * kPi * frequency * i / 48000.0f);
        out[i] = m.processSample(x, 0);
    }
    const double measured = toneAmplitude(out, 48000.0, frequency);
    return static_cast<float>(20.0 * std::log10(std::max(1.0e-12, measured / amplitude)));
}
}

int main()
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel model;
    model.prepare(48000.0, 2);

    std::vector<float> inL(n), inR(n), outL(n), outR(n);
    for (int i = 0; i < n; ++i)
    {
        const float t = static_cast<float>(i) / 48000.0f;
        inL[i] = 0.85f * std::sin(2.0f * kPi * 997.0f * t);
        inR[i] = 0.85f * std::sin(2.0f * kPi * 997.0f * t + 0.5f);
    }

    const float* inputs[2] = { inL.data(), inR.data() };
    float* outputs[2] = { outL.data(), outR.data() };
    model.process(inputs, outputs, 2, n);

    float peak = 0.0f;
    for (float v : outL)
    {
        require(std::isfinite(v), "output must stay finite");
        peak = std::max(peak, std::abs(v));
    }
    require(peak < 1.20f, "default model should round hot peaks");
    require(rmsOf(outL) > 0.35f, "default output should retain healthy level");

    // Low-level programme should stay essentially unity with +1/-1 default trim.
    model.reset();
    apollo::Parameters p;
    model.setParameters(p);
    model.prepare(48000.0, 2);
    float lowPeak = 0.0f;
    for (int i = 0; i < 8192; ++i)
    {
        const float x = 0.01f * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        lowPeak = std::max(lowPeak, std::abs(model.processSample(x, 0)));
    }
    require(lowPeak > 0.0092f && lowPeak < 0.0108f,
            "small-signal gain should stay very close to unity");

    // No fixed smile/dark EQ: after onset settles, low/mid/high are flat.
    require(std::abs(steadyToneGainDb(20.0f)) < 0.08f, "20 Hz steady response should stay flat");
    require(std::abs(steadyToneGainDb(1000.0f)) < 0.03f, "1 kHz steady response should stay flat");
    require(std::abs(steadyToneGainDb(10000.0f)) < 0.03f, "10 kHz steady response should stay flat");
    require(std::abs(steadyToneGainDb(18000.0f)) < 0.05f, "18 kHz steady response should stay open");

    // Calibrated density target: clean at nominal level, progressively softer
    // near the top rather than constant saturation on the whole mix.
    const float thd18 = measureThd(std::pow(10.0f, -18.0f / 20.0f));
    const float thd6  = measureThd(std::pow(10.0f,  -6.0f / 20.0f));
    const float thd1  = measureThd(std::pow(10.0f,  -1.0f / 20.0f));
    require(thd18 > 0.00015f && thd18 < 0.00080f,
            "-18 dBFS THD should be subtle, not obviously saturated");
    require(thd6 > 0.0010f && thd6 < 0.0040f,
            "-6 dBFS THD should add restrained analogue density");
    require(thd1 > 0.0030f && thd1 < 0.0120f,
            "-1 dBFS THD should round peaks without fuzz");
    require(thd18 < thd6 && thd6 < thd1,
            "harmonic density must rise naturally with level");

    // Character=100% should materially soften a sharp attack, while Character=0
    // is the clean reference. This tests the actual transient path.
    apollo::ApolloOutputModel cleanAttack;
    apollo::ApolloOutputModel sweetAttack;
    apollo::Parameters cleanP;
    cleanP.driveDb = 0.0f;
    cleanP.outputDb = 0.0f;
    cleanP.character = 0.0f;
    cleanP.mix = 1.0f;
    apollo::Parameters sweetP = cleanP;
    sweetP.character = 1.0f;
    cleanAttack.setParameters(cleanP);
    sweetAttack.setParameters(sweetP);
    cleanAttack.prepare(48000.0, 1);
    sweetAttack.prepare(48000.0, 1);

    for (int i = 0; i < 512; ++i)
    {
        cleanAttack.processSample(0.0f, 0);
        sweetAttack.processSample(0.0f, 0);
    }
    float peakClean = 0.0f;
    float peakSweet = 0.0f;
    const float attack[8] = {0.95f, -0.72f, 0.48f, -0.31f, 0.18f, -0.10f, 0.05f, 0.0f};
    for (float x : attack)
    {
        peakClean = std::max(peakClean, std::abs(cleanAttack.processSample(x, 0)));
        peakSweet = std::max(peakSweet, std::abs(sweetAttack.processSample(x, 0)));
    }
    require(peakSweet < peakClean * 0.96f,
            "high Character should soften sharp transient peaks by a useful amount");

    // Stereo path uses one detector. Identical L/R programme must remain bit-close
    // and must not acquire independent transient pumping between channels.
    apollo::ApolloOutputModel stereo;
    stereo.setParameters(p);
    stereo.prepare(48000.0, 2);
    std::vector<float> sameL(4096), sameR(4096), sameOutL(4096), sameOutR(4096);
    for (int i = 0; i < 4096; ++i)
    {
        float x = 0.15f * std::sin(2.0f * kPi * 7000.0f * i / 48000.0f);
        if (i == 512) x += 0.80f;
        sameL[i] = sameR[i] = x;
    }
    const float* sameIn[2] = {sameL.data(), sameR.data()};
    float* sameOut[2] = {sameOutL.data(), sameOutR.data()};
    stereo.process(sameIn, sameOut, 2, 4096);
    float stereoError = 0.0f;
    for (int i = 0; i < 4096; ++i)
        stereoError = std::max(stereoError, std::abs(sameOutL[i] - sameOutR[i]));
    require(stereoError < 1.0e-6f, "stereo-linked detector must preserve a centred image");

    // Mix=0 is transparent at unity output; bypass is true dry after its short ramp.
    model.reset();
    p.driveDb = 0.0f;
    p.outputDb = 0.0f;
    p.character = 1.0f;
    p.mix = 0.0f;
    p.bypass = 0.0f;
    model.setParameters(p);
    model.prepare(48000.0, 1);
    const float dry = model.processSample(0.25f, 0);
    require(std::abs(dry - 0.25f) < 1.0e-5f, "0% Mix should be transparent");

    p.mix = 1.0f;
    p.bypass = 1.0f;
    model.setParameters(p);
    float bypassOut = 0.0f;
    for (int i = 0; i < 4096; ++i)
        bypassOut = model.processSample(0.25f, 0);
    require(std::abs(bypassOut - 0.25f) < 1.0e-4f, "bypass should converge to true dry unity");

    std::cout << "Apollo Twin X commercial-polish DSP tests passed.\n";
    std::cout << "THD: -18 dBFS=" << thd18 * 100.0f << "%  -6 dBFS=" << thd6 * 100.0f
              << "%  -1 dBFS=" << thd1 * 100.0f << "%\n";
    return 0;
}
