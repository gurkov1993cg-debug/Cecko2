#include "ApolloOutputModel.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

static void require(bool ok, const char* message)
{
    if (!ok)
    {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

int main()
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel model;
    model.prepare(48000.0, 2);

    std::vector<float> inL(n), inR(n), outL(n), outR(n);
    for (int i = 0; i < n; ++i)
    {
        const float t = static_cast<float>(i) / 48000.0f;
        inL[i] = 0.85f * std::sin(2.0f * 3.14159265358979323846f * 997.0f * t);
        inR[i] = 0.85f * std::sin(2.0f * 3.14159265358979323846f * 997.0f * t + 0.5f);
    }

    const float* inputs[2] = { inL.data(), inR.data() };
    float* outputs[2] = { outL.data(), outR.data() };
    model.process(inputs, outputs, 2, n);

    float peak = 0.0f;
    double power = 0.0;
    for (float v : outL)
    {
        require(std::isfinite(v), "output must stay finite");
        peak = std::max(peak, std::abs(v));
        power += static_cast<double>(v) * static_cast<double>(v);
    }

    const float rms = static_cast<float>(std::sqrt(power / n));
    require(peak < 1.25f, "default model should round hot peaks");
    require(rms > 0.35f, "default output should retain healthy level");

    // At low signal level the default Drive/Output pair should be close to unity.
    model.reset();
    apollo::Parameters p;
    p.driveDb = 1.5f;
    p.outputDb = -1.5f;
    p.character = 0.35f;
    p.mix = 1.0f;
    model.setParameters(p);

    float lowPeak = 0.0f;
    for (int i = 0; i < 8192; ++i)
    {
        const float x = 0.01f * std::sin(2.0f * 3.14159265358979323846f * 1000.0f * i / 48000.0f);
        lowPeak = std::max(lowPeak, std::abs(model.processSample(x, 0)));
    }
    require(lowPeak > 0.0085f && lowPeak < 0.0115f, "small-signal gain should stay near unity");

    // Full dry path should be mathematically clean apart from output trim smoothing.
    model.reset();
    p.driveDb = 0.0f;
    p.outputDb = 0.0f;
    p.character = 0.0f;
    p.mix = 0.0f;
    model.setParameters(p);
    model.prepare(48000.0, 2);
    const float dry = model.processSample(0.25f, 0);
    require(std::abs(dry - 0.25f) < 1.0e-5f, "0% Mix should be transparent");

    std::cout << "Apollo Twin X output macromodel tests passed.\n";
    return 0;
}
