#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

static void require(bool ok, const char* message)
{
    if (!ok)
    {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

static float rmsOf(const std::vector<float>& v, int start = 0)
{
    double p = 0.0;
    const int n = static_cast<int>(v.size()) - start;
    for (int i = start; i < static_cast<int>(v.size()); ++i)
        p += static_cast<double>(v[i]) * static_cast<double>(v[i]);
    return n > 0 ? static_cast<float>(std::sqrt(p / n)) : 0.0f;
}

int main()
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel model;
    model.prepare(48000.0, 2);

    std::vector<float> inL(n), inR(n), outL(n), outR(n);
    for (int i = 0; i < n; ++i)
    {
        const float t = static_cast<float>(i) / 48000.0f;
        inL[i] = 0.85f * std::sin(2.0f * 3.14159265358979323846f * 997.0f * t);
        inR[i] = 0.85f * std::sin(2.0f * 3.14159265358979323846f * 997.0f * t + 0.5f);
    }

    const float* inputs[2] = { inL.data(), inR.data() };
    float* outputs[2] = { outL.data(), outR.data() };
    model.process(inputs, outputs, 2, n);

    float peak = 0.0f;
    for (float v : outL)
    {
        require(std::isfinite(v), "output must stay finite");
        peak = std::max(peak, std::abs(v));
    }

    const float rms = rmsOf(outL);
    require(peak < 1.25f, "default model should round hot peaks");
    require(rms > 0.35f, "default output should retain healthy level");

    // At low signal level the default Drive/Output pair should be close to unity.
    model.reset();
    apollo::Parameters p;
    p.driveDb = 1.0f;
    p.outputDb = -1.0f;
    p.character = 0.50f;
    p.mix = 1.0f;
    model.setParameters(p);
    model.prepare(48000.0, 2);

    float lowPeak = 0.0f;
    for (int i = 0; i < 8192; ++i)
    {
        const float x = 0.01f * std::sin(2.0f * 3.14159265358979323846f * 1000.0f * i / 48000.0f);
        lowPeak = std::max(lowPeak, std::abs(model.processSample(x, 0)));
    }
    require(lowPeak > 0.0085f && lowPeak < 0.0115f, "small-signal gain should stay near unity");

    // Sustained high-frequency content must open back up after the onset. The
    // transient polish must not behave like a permanent dark low-pass.
    model.reset();
    model.setParameters(p);
    model.prepare(48000.0, 2);
    std::vector<float> hfOut(n);
    for (int i = 0; i < n; ++i)
    {
        const float x = 0.12f * std::sin(2.0f * 3.14159265358979323846f * 9000.0f * i / 48000.0f);
        hfOut[i] = model.processSample(x, 0);
    }
    const float hfSteadyRms = rmsOf(hfOut, n / 2);
    const float hfInRms = 0.12f / std::sqrt(2.0f);
    require(hfSteadyRms > hfInRms * 0.88f, "steady highs must remain open after transient settles");

    // A sharp attack should be softened more at high Character. This checks the
    // actual transient-aware path, not just the static nonlinear rail.
    apollo::ApolloOutputModel cleanAttack;
    apollo::ApolloOutputModel sweetAttack;
    apollo::Parameters cleanP;
    cleanP.driveDb = 0.0f;
    cleanP.outputDb = 0.0f;
    cleanP.character = 0.0f;
    cleanP.mix = 1.0f;
    apollo::Parameters sweetP = cleanP;
    sweetP.character = 1.0f;
    cleanAttack.setParameters(cleanP);
    sweetAttack.setParameters(sweetP);
    cleanAttack.prepare(48000.0, 1);
    sweetAttack.prepare(48000.0, 1);

    // Prime both models with silence, then inject a short high-frequency-rich edge.
    for (int i = 0; i < 512; ++i)
    {
        cleanAttack.processSample(0.0f, 0);
        sweetAttack.processSample(0.0f, 0);
    }
    float peakClean = 0.0f;
    float peakSweet = 0.0f;
    const float attack[8] = {0.95f, -0.72f, 0.48f, -0.31f, 0.18f, -0.10f, 0.05f, 0.0f};
    for (float x : attack)
    {
        peakClean = std::max(peakClean, std::abs(cleanAttack.processSample(x, 0)));
        peakSweet = std::max(peakSweet, std::abs(sweetAttack.processSample(x, 0)));
    }
    require(peakSweet < peakClean * 0.96f, "high Character should soften sharp transient peaks");

    // Full dry path should be mathematically clean apart from output trim smoothing.
    model.reset();
    p.driveDb = 0.0f;
    p.outputDb = 0.0f;
    p.character = 0.0f;
    p.mix = 0.0f;
    model.setParameters(p);
    model.prepare(48000.0, 2);
    const float dry = model.processSample(0.25f, 0);
    require(std::abs(dry - 0.25f) < 1.0e-5f, "0% Mix should be transparent");

    std::cout << "Apollo Twin X sweet-output macromodel tests passed.\n";
    return 0;
}
