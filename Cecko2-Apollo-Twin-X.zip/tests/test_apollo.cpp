#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <vector>

namespace
{
constexpr float kPi = 3.14159265358979323846f;

void require(bool ok, const char* message)
{
    if (!ok)
    {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

float rmsOf(const std::vector<float>& v, int start = 0)
{
    double p = 0.0;
    const int n = static_cast<int>(v.size()) - start;
    for (int i = start; i < static_cast<int>(v.size()); ++i)
        p += static_cast<double>(v[i]) * static_cast<double>(v[i]);
    return n > 0 ? static_cast<float>(std::sqrt(p / n)) : 0.0f;
}

double toneAmplitude(const std::vector<float>& v, double sampleRate, double frequency)
{
    double re = 0.0;
    double im = 0.0;
    for (std::size_t i = 0; i < v.size(); ++i)
    {
        const double phase = 2.0 * static_cast<double>(kPi) * frequency
                           * static_cast<double>(i) / sampleRate;
        re += static_cast<double>(v[i]) * std::cos(phase);
        im -= static_cast<double>(v[i]) * std::sin(phase);
    }
    return 2.0 * std::sqrt(re * re + im * im) / static_cast<double>(v.size());
}

float measureThd(float inputAmplitude, apollo::Parameters p = {})
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel m;
    m.setParameters(p);
    m.prepare(48000.0, 1);

    // Let all transient and DC states settle before the FFT window.
    for (int i = 0; i < n; ++i)
    {
        const float x = inputAmplitude * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        m.processSample(x, 0);
    }

    std::vector<float> out(n);
    for (int i = 0; i < n; ++i)
    {
        const float x = inputAmplitude * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        out[i] = m.processSample(x, 0);
    }

    const double fundamental = toneAmplitude(out, 48000.0, 1000.0);
    double harmonicPower = 0.0;
    for (int h = 2; h <= 10; ++h)
    {
        const double a = toneAmplitude(out, 48000.0, 1000.0 * h);
        harmonicPower += a * a;
    }
    return static_cast<float>(std::sqrt(harmonicPower) / std::max(1.0e-12, fundamental));
}

float steadyToneGainDb(float frequency)
{
    constexpr int n = 48000;
    constexpr float amplitude = 0.02f;
    apollo::ApolloOutputModel m;
    apollo::Parameters p;
    m.setParameters(p);
    m.prepare(48000.0, 1);

    for (int i = 0; i < n; ++i)
    {
        const float x = amplitude * std::sin(2.0f * kPi * frequency * i / 48000.0f);
        m.processSample(x, 0);
    }

    std::vector<float> out(n);
    for (int i = 0; i < n; ++i)
    {
        const float x = amplitude * std::sin(2.0f * kPi * frequency * i / 48000.0f);
        out[i] = m.processSample(x, 0);
    }
    const double measured = toneAmplitude(out, 48000.0, frequency);
    return static_cast<float>(20.0 * std::log10(std::max(1.0e-12, measured / amplitude)));
}

void stressFiniteAtSampleRate(double sampleRate)
{
    constexpr int n = 32768;
    apollo::ApolloOutputModel m;
    apollo::Parameters p;
    p.driveDb = 12.0f;
    p.character = 1.0f;
    p.outputDb = 12.0f;
    p.mix = 1.0f;
    m.setParameters(p);
    m.prepare(sampleRate, 2);

    std::vector<float> l(n), r(n), ol(n), orr(n);
    for (int i = 0; i < n; ++i)
    {
        const double t = static_cast<double>(i) / sampleRate;
        l[i] = 0.99f * std::sin(static_cast<float>(2.0 * kPi * 997.0 * t));
        r[i] = 0.83f * std::sin(static_cast<float>(2.0 * kPi * 1403.0 * t + 0.37));
        if ((i % 4096) == 0)
        {
            l[i] += 0.95f;
            r[i] -= 0.90f;
        }
    }
    const float* in[2] = {l.data(), r.data()};
    float* out[2] = {ol.data(), orr.data()};
    m.process(in, out, 2, n);
    for (int i = 0; i < n; ++i)
    {
        require(std::isfinite(ol[i]) && std::isfinite(orr[i]),
                "extreme legal settings must remain finite at every sample rate");
        require(std::abs(ol[i]) < 32.0f && std::abs(orr[i]) < 32.0f,
                "extreme legal settings must remain numerically bounded");
    }
}
}

int main()
{
    constexpr int n = 48000;
    apollo::ApolloOutputModel model;
    model.prepare(48000.0, 2);

    std::vector<float> inL(n), inR(n), outL(n), outR(n);
    for (int i = 0; i < n; ++i)
    {
        const float t = static_cast<float>(i) / 48000.0f;
        inL[i] = 0.85f * std::sin(2.0f * kPi * 997.0f * t);
        inR[i] = 0.85f * std::sin(2.0f * kPi * 997.0f * t + 0.5f);
    }

    const float* inputs[2] = { inL.data(), inR.data() };
    float* outputs[2] = { outL.data(), outR.data() };
    model.process(inputs, outputs, 2, n);

    float peak = 0.0f;
    for (float v : outL)
    {
        require(std::isfinite(v), "output must stay finite");
        peak = std::max(peak, std::abs(v));
    }
    require(peak < 1.20f, "default model should round hot peaks");
    require(rmsOf(outL) > 0.35f, "default output should retain healthy level");

    // Low-level programme should stay essentially unity with +1/-1 default trim.
    model.reset();
    apollo::Parameters p;
    model.setParameters(p);
    model.prepare(48000.0, 2);
    float lowPeak = 0.0f;
    for (int i = 0; i < 8192; ++i)
    {
        const float x = 0.01f * std::sin(2.0f * kPi * 1000.0f * i / 48000.0f);
        lowPeak = std::max(lowPeak, std::abs(model.processSample(x, 0)));
    }
    require(lowPeak > 0.0092f && lowPeak < 0.0108f,
            "small-signal gain should stay very close to unity");

    // No fixed smile/dark EQ: after onset settles, low/mid/high are flat.
    require(std::abs(steadyToneGainDb(20.0f)) < 0.08f, "20 Hz steady response should stay flat");
    require(std::abs(steadyToneGainDb(1000.0f)) < 0.03f, "1 kHz steady response should stay flat");
    require(std::abs(steadyToneGainDb(10000.0f)) < 0.03f, "10 kHz steady response should stay flat");
    require(std::abs(steadyToneGainDb(18000.0f)) < 0.05f, "18 kHz steady response should stay open");

    // Reference-informed density target. Public Apollo X/Twin X measurements
    // and DAC->ADC loopback comparisons point to a very clean converter path,
    // so the default model must remain much cleaner than the previous voicing
    // while still growing gently toward the top of the digital range.
    const float thd18 = measureThd(std::pow(10.0f, -18.0f / 20.0f));
    const float thd6  = measureThd(std::pow(10.0f,  -6.0f / 20.0f));
    const float thd1  = measureThd(std::pow(10.0f,  -1.0f / 20.0f));
    require(thd18 < 0.000010f,
            "default -18 dBFS THD should be essentially transparent");
    require(thd6 > thd18 && thd6 < 0.0030f,
            "default -6 dBFS THD should be audible but controlled");
    require(thd1 > thd6 && thd1 < 0.0120f,
            "default -1 dBFS THD should provide clear soft-rail density without hard clipping");

    // Character=0 is the clean reference end of the control. It is not allowed
    // to behave like a hidden saturator.
    apollo::Parameters refP;
    refP.driveDb = 0.0f;
    refP.outputDb = 0.0f;
    refP.character = 0.0f;
    const float refThd1 = measureThd(std::pow(10.0f, -1.0f / 20.0f), refP);
    require(refThd1 < 0.000010f,
            "Character=0 should be measurement-clean at -1 dBFS");

    // Drive must be a real musical control rather than just a level trim. With
    // output compensation, the default Character setting should move into
    // clearly audible but still controlled analogue-style density at +12 dB.
    apollo::Parameters drivenP;
    drivenP.driveDb = 12.0f;
    drivenP.outputDb = -12.0f;
    drivenP.character = 0.45f;
    const float drivenThd1 = measureThd(std::pow(10.0f, -1.0f / 20.0f), drivenP);
    require(drivenThd1 > 0.0010f && drivenThd1 < 0.0100f,
            "+12 dB Drive should create useful controlled saturation when level-compensated");

    // Character=100% should materially soften a sharp attack, while Character=0
    // is the clean reference. This tests the actual transient path.
    apollo::ApolloOutputModel cleanAttack;
    apollo::ApolloOutputModel sweetAttack;
    apollo::Parameters cleanP;
    cleanP.driveDb = 0.0f;
    cleanP.outputDb = 0.0f;
    cleanP.character = 0.0f;
    cleanP.mix = 1.0f;
    apollo::Parameters sweetP = cleanP;
    sweetP.character = 1.0f;
    cleanAttack.setParameters(cleanP);
    sweetAttack.setParameters(sweetP);
    cleanAttack.prepare(48000.0, 1);
    sweetAttack.prepare(48000.0, 1);

    for (int i = 0; i < 512; ++i)
    {
        cleanAttack.processSample(0.0f, 0);
        sweetAttack.processSample(0.0f, 0);
    }
    float peakClean = 0.0f;
    float peakSweet = 0.0f;
    const float attack[8] = {0.95f, -0.72f, 0.48f, -0.31f, 0.18f, -0.10f, 0.05f, 0.0f};
    for (float x : attack)
    {
        peakClean = std::max(peakClean, std::abs(cleanAttack.processSample(x, 0)));
        peakSweet = std::max(peakSweet, std::abs(sweetAttack.processSample(x, 0)));
    }
    require(peakSweet < peakClean * 0.90f,
            "high Character should clearly soften sharp transient peaks");

    // The default should already deliver the requested commercial polish, but
    // subtly: roughly a few percent off a pathological digital attack, not a
    // compressor-like flattening of normal programme.
    apollo::ApolloOutputModel defaultAttack;
    apollo::Parameters defaultAttackP = cleanP;
    defaultAttackP.character = 0.45f;
    defaultAttack.setParameters(defaultAttackP);
    defaultAttack.prepare(48000.0, 1);
    for (int i = 0; i < 512; ++i) defaultAttack.processSample(0.0f, 0);
    float peakDefault = 0.0f;
    for (float x : attack)
        peakDefault = std::max(peakDefault, std::abs(defaultAttack.processSample(x, 0)));
    require(peakDefault < peakClean * 0.93f && peakDefault > peakClean * 0.86f,
            "default Character should now be clearly audible on hard attacks without crushing them");

    // Stereo path uses one detector. Identical L/R programme must remain bit-close
    // and must not acquire independent transient pumping between channels.
    apollo::ApolloOutputModel stereo;
    stereo.setParameters(p);
    stereo.prepare(48000.0, 2);
    std::vector<float> sameL(4096), sameR(4096), sameOutL(4096), sameOutR(4096);
    for (int i = 0; i < 4096; ++i)
    {
        float x = 0.15f * std::sin(2.0f * kPi * 7000.0f * i / 48000.0f);
        if (i == 512) x += 0.80f;
        sameL[i] = sameR[i] = x;
    }
    const float* sameIn[2] = {sameL.data(), sameR.data()};
    float* sameOut[2] = {sameOutL.data(), sameOutR.data()};
    stereo.process(sameIn, sameOut, 2, 4096);
    float stereoError = 0.0f;
    for (int i = 0; i < 4096; ++i)
        stereoError = std::max(stereoError, std::abs(sameOutL[i] - sameOutR[i]));
    require(stereoError < 1.0e-6f, "stereo-linked detector must preserve a centred image");

    // Mix=0 is transparent at unity output; bypass is true dry after its short ramp.
    model.reset();
    p.driveDb = 0.0f;
    p.outputDb = 0.0f;
    p.character = 1.0f;
    p.mix = 0.0f;
    p.bypass = 0.0f;
    model.setParameters(p);
    model.prepare(48000.0, 1);
    const float dry = model.processSample(0.25f, 0);
    require(std::abs(dry - 0.25f) < 1.0e-5f, "0% Mix should be transparent");

    p.mix = 1.0f;
    p.bypass = 1.0f;
    model.setParameters(p);
    float bypassOut = 0.0f;
    for (int i = 0; i < 4096; ++i)
        bypassOut = model.processSample(0.25f, 0);
    require(std::abs(bypassOut - 0.25f) < 1.0e-4f, "bypass should converge to true dry unity");

    // Corrupt/legacy state must be sanitised instead of poisoning the real-time path.
    apollo::ApolloOutputModel guarded;
    apollo::Parameters bad;
    bad.driveDb = std::numeric_limits<float>::infinity();
    bad.character = std::numeric_limits<float>::quiet_NaN();
    bad.outputDb = -std::numeric_limits<float>::infinity();
    bad.mix = 99.0f;
    bad.bypass = -5.0f;
    guarded.setParameters(bad);
    guarded.prepare(48000.0, 1);
    for (int i = 0; i < 4096; ++i)
        require(std::isfinite(guarded.processSample(0.5f * std::sin(2.0f * kPi * 440.0f * i / 48000.0f), 0)),
                "malformed parameter state must be sanitised");

    // Standalone API guards: invalid configuration must fail cleanly and invalid
    // channel indices must never address state_[8] or wrap a negative index.
    apollo::ApolloOutputModel apiGuard;
    require(!apiGuard.prepare(std::numeric_limits<double>::quiet_NaN(), 2),
            "NaN sample rate must be rejected");
    require(!apiGuard.prepare(48000.0, 0),
            "zero channels must be rejected");
    require(!apiGuard.prepare(48000.0, apollo::ApolloOutputModel::kMaxChannels + 1),
            "more than eight channels must be rejected");
    require(apiGuard.prepare(48000.0, apollo::ApolloOutputModel::kMaxChannels),
            "eight channels must be accepted");
    require(std::abs(apiGuard.processSample(0.25f, -1) - 0.25f) < 1.0e-7f,
            "negative channel index must return dry without touching state");
    require(std::abs(apiGuard.processSample(0.25f, apollo::ApolloOutputModel::kMaxChannels) - 0.25f) < 1.0e-7f,
            "channel index 8 must return dry without touching state");
    require(std::isfinite(apiGuard.processSample(std::numeric_limits<float>::quiet_NaN(), 0)),
            "NaN input sample must not poison ADAA state");

    // Basic stability at the sample rates likely to be used in Cubase sessions.
    stressFiniteAtSampleRate(44100.0);
    stressFiniteAtSampleRate(48000.0);
    stressFiniteAtSampleRate(88200.0);
    stressFiniteAtSampleRate(96000.0);
    stressFiniteAtSampleRate(192000.0);

    std::cout << "Apollo Twin X reference-informed commercial-polish DSP tests passed.\n";
    std::cout << "THD: -18 dBFS=" << thd18 * 100.0f << "%  -6 dBFS=" << thd6 * 100.0f
              << "%  -1 dBFS=" << thd1 * 100.0f << "%  ref-char0=" << refThd1 * 100.0f
              << "%  drive+12=" << drivenThd1 * 100.0f << "%\n";
    return 0;
}
