# Cecko2 - Apollo Twin X Character

Direct Steinberg VST3 SDK project. **No JUCE.**

Current version: **v0.4.1 commercial-polish calibrated output-path macromodel**.

The project starts from the confirmed/strongly-supported Apollo Twin X Gen1 output architecture and intentionally leaves unknown component-level values as a documented macromodel rather than inventing a schematic.

## Controls

- **Drive**: -12..+12 dB into the analogue model
- **Character**: 0..100% nonlinear intensity
- **Output**: -12..+12 dB
- **Mix**: 0..100%

Default settings are designed to be close to unity at low level while rounding hotter peaks. v0.4 uses stereo-linked transient detection, exact-reconstruction transient bands and anti-aliased nonlinear stages so the mix stays centred and open while attacks are polished.

## Build DSP tests

```bash
cmake -S . -B build-core
cmake --build build-core
ctest --test-dir build-core --output-on-failure
```

## Build VST3

```bash
cmake -S . -B build-vst3 \
  -DBUILD_VST3_ADAPTER=ON \
  -DVST3_SDK_DIR=/path/to/vst3sdk
cmake --build build-vst3 --config Release --target ApolloTwinXCharacter
```

See `docs/MODEL.md` for the exact v0.1 model boundary.


## sweet-output build hardening

- Explicit 32-bit VST3 sample-size advertisement.
- Host-visible Bypass parameter with clean sample copy.
- Backward-compatible state restore.
- GitHub Actions checks the macOS bundle executable before upload.


## Commercial-polish DSP

The current build uses a stereo-linked fast/slow programme detector and an exact-reconstruction low/presence/air split. Only attacks are softened; sustain returns to unity, so there is no permanent high-cut. Both nonlinear output stages use antiderivative anti-aliasing and the bypass is click-free true dry. Character controls transient polish and analogue density together.

## Custom GUI

The VST3 opens a custom 1056x792 Apollo Twin X Character editor using the approved visual.
Drive, Character, Output and Mix are real parameter-bound VSTGUI knobs. The baked/frozen LED states and knob pointers were removed from the background artwork, so each knob now has one moving indication only. The Bypass switch is parameter-bound, and Input/Output L/R meters are driven by read-only VST3 parameters published by the audio processor.
The GUI uses Steinberg VSTGUI from the VST3 SDK; JUCE is not used.
