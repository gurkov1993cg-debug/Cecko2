# Cecko2 - Apollo Twin X Character

Direct Steinberg VST3 SDK project. **No JUCE.**

Current version: **sweet-output calibrated output-path macromodel**.

The project starts from the confirmed/strongly-supported Apollo Twin X Gen1 output architecture and intentionally leaves unknown component-level values as a documented macromodel rather than inventing a schematic.

## Controls

- **Drive**: -12..+12 dB into the analogue model
- **Character**: 0..100% nonlinear intensity
- **Output**: -12..+12 dB
- **Mix**: 0..100%

Default settings are designed to be close to unity at low level while rounding hotter peaks.

## Build DSP tests

```bash
cmake -S . -B build-core
cmake --build build-core
ctest --test-dir build-core --output-on-failure
```

## Build VST3

```bash
cmake -S . -B build-vst3 \
  -DBUILD_VST3_ADAPTER=ON \
  -DVST3_SDK_DIR=/path/to/vst3sdk
cmake --build build-vst3 --config Release --target ApolloTwinXCharacter
```

See `docs/MODEL.md` for the exact v0.1 model boundary.


## sweet-output build hardening

- Explicit 32-bit VST3 sample-size advertisement.
- Host-visible Bypass parameter with clean sample copy.
- Backward-compatible state restore.
- GitHub Actions checks the macOS bundle executable before upload.


## Sweet-output DSP

The current build includes transient-aware HF polish for a more commercial, benign leading edge without a permanent low-pass or dark tonal tilt. Character controls the strength of this behaviour together with the output-stage nonlinearity.

## Custom GUI

The VST3 opens a custom 1056x792 Apollo Twin X Character editor using the approved visual.
Drive, Character, Output and Mix are now real visible VSTGUI knobs with live value readouts; the Bypass switch has a visible state. Input and output L/R meters are driven by read-only VST3 parameters published by the audio processor, so the editor is no longer a static picture with invisible hit areas.
The GUI uses Steinberg VSTGUI from the VST3 SDK; JUCE is not used.
