# Cecko2 - Apollo Twin X Character

Direct Steinberg VST3 SDK project.

Current version: **v0.5.1 reference-informed commercial-polish output macromodel**.

The project starts from the confirmed/strongly-supported Apollo Twin X Gen1 output architecture and keeps unknown component-level values as a documented macromodel instead of inventing a schematic.

## Controls

- **Drive**: -12..+12 dB into the analogue model
- **Character**: 0..100% transient polish + analogue residual
- **Output**: -12..+12 dB
- **Mix**: 0..100%
- **Bypass**: click-free true dry

Default settings are **+0.5 dB Drive / 45% Character / -0.5 dB Output / 100% Mix**. The low-level gain stays close to unity while sharp attacks are polished without a permanent high-cut.

## Reference-informed voicing

v0.5.1 was re-tuned around the fact that the real Apollo X/Twin X conversion path is very clean at normal programme level. Public Twin X Gen1 specifications quote -117 dB THD+N for line/monitor output and essentially flat 20 Hz-20 kHz response. Public Apollo x8 DAC->ADC converter shootouts also show that the audible differences are subtle when levels are matched. v0.5.1 therefore keeps static coloration extremely low and puts the intended commercial finish into short stereo-linked transient shaping rather than a permanent dark EQ or obvious saturator.

The plug-in therefore no longer treats constant saturation as the Apollo sound. Character=0 is the clean reference end; higher Character adds a small level-dependent residual plus programme-aware transient smoothing. Drive remains available when a deliberately stronger effect is wanted.

See `docs/REFERENCE_METHOD.md` for the evidence boundary and calibration method.

## Build DSP tests

```bash
cmake -S . -B build-core
cmake --build build-core
ctest --test-dir build-core --output-on-failure
```

## Build VST3

```bash
cmake -S . -B build-vst3 \
  -DBUILD_VST3_ADAPTER=ON \
  -DVST3_SDK_DIR=/path/to/vst3sdk
cmake --build build-vst3 --config Release --target ApolloTwinXCharacter
```

## DSP

- stereo-linked fast/slow transient detector;
- exact-reconstruction low/presence/air split;
- no permanent smile EQ or fixed high-cut;
- ADAA nonlinear stages;
- near-transparent Character=0 reference end;
- harmonic density rises with level and Character instead of saturating the whole mix;
- click-free true bypass crossfade;
- 32-bit float VST3 processing;
- read-only input/output meter parameters.

## GUI

The editor is now **1056x730**. The old decorative top strip containing **Default / previous-next / A-B / Copy / settings / power** is clipped out completely because those functions were not implemented.

Drive, Character, Output and Mix are real parameter-bound VSTGUI knobs. The frozen pointers/LED states were removed from the visible layer, so only the live controls indicate position. Input/Output L/R meters are driven by the processor. **Bypass is a real latched parameter control: OFF is dark, ON is illuminated green.**
