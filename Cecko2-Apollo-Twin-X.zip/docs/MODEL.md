# Apollo Twin X Character — commercial-polish output model

This is a **calibrated output-path macromodel**, not a claim of a complete Apollo Twin X Gen1 component-level netlist. Unknown component values are not invented.

## Hardware constraints

- ESS ES9016-family DAC in the Twin X Gen1 output architecture.
- Balanced monitor/line output topology.
- Published +20.2 dBu maximum monitor/line output and 100 ohm balanced output impedance.
- Analogue output stages after the DAC and hardware mute relays.
- Apollo X-family evidence points to LME49720-class output amplification; exact Twin X Gen1 R/C values remain incomplete.
- Repair evidence indicates bipolar analogue rails around +/-7 V in the affected output section.

## v0.4 sound-engineering revision

The previous revision had three important weaknesses for a mastering/output-character plug-in: transient control was channel-independent, the final soft rail was a separate non-ADAA waveshaper, and bypass switched hard. v0.4 corrects those issues.

Signal path:

1. **Stereo-linked programme detector** — fast and slow envelopes create a level-normalised onset cue. The linked detector prevents L/R from changing tone independently on centred drums and mix-bus attacks.
2. **Three-band transient polish** — exact-reconstruction low / presence / air decomposition. Only detected attacks are softened; steady-state response returns to unity. The air band gets the most reduction, presence gets less, and the body receives only a very small crest trim.
3. **ADAA asymmetric analogue-density stage** — slope-normalised at zero, with restrained bias for a small musical H2 contribution without constant saturation.
4. **ADAA high-headroom output rail** — a second anti-aliased soft stage that rounds near-full-scale peaks progressively instead of producing a hard digital corner.
5. **1 Hz implementation-only DC protection** — the real hardware output is DC-coupled; this only removes tiny DC produced by the intentionally asymmetric model.
6. **Click-free true bypass** — short internal crossfade to exact dry unity.

There is **no permanent smile EQ and no fixed high-cut**. After an onset settles, the three transient bands sum back to the original signal.

## Default voicing

- Drive: +1.0 dB
- Character: 50%
- Output: -1.0 dB
- Mix: 100%

Measured by the built-in regression test at 48 kHz / 1 kHz, defaults are intentionally level-dependent: roughly a few hundredths of a percent THD around -18 dBFS, around two-tenths of a percent near -6 dBFS, and roughly half a percent near -1 dBFS. The exact numbers are printed by the test executable and are bounded by regression limits.

The engineering target is: **clean body, softer crest, restrained H2/H3 density, open sustain, no brittle digital edge**.

## Model boundary

When reliable Twin X PCB values become available, this macromodel can be replaced stage-by-stage with recovered R/C networks, exact op-amp configuration, monitor level element, relay placement and load-dependent output behaviour.
