# Apollo Twin X Character — reference-informed commercial output model

This is a **calibrated output-path macromodel**, not a claim of a complete Apollo Twin X Gen1 component-level netlist. Unknown component values are not invented.

## Hardware constraints

- ESS ES9016-family DAC in the Twin X Gen1 output architecture.
- Balanced monitor/line output topology.
- Published +20.2 dBu maximum monitor/line output and 100 ohm balanced output impedance.
- Published Twin X Gen1 line/monitor THD+N around -117 dB at high level.
- Published frequency response is essentially flat across 20 Hz-20 kHz.
- Analogue output stages after the DAC and hardware mute relays.
- Apollo X-family teardown evidence points to LME49720-class output amplification; exact Twin X Gen1 R/C values remain incomplete.
- Repair evidence indicates bipolar analogue rails around +/-7 V in the affected output section.

## v0.5.1 sound-engineering revision

The earlier voicing was too nonlinear to be credible as an Apollo X-family converter/output reference. v0.5.1 moves the constant harmonic residue down dramatically and lets **Character** scale the coloration from a near-transparent reference end to an intentionally more musical enhancement.

Signal path:

1. **Stereo-linked programme detector** — fast and slow envelopes create a level-normalised onset cue. The linked detector prevents L/R from changing tone independently on centred drums and mix-bus attacks.
2. **Three-band transient polish** — exact-reconstruction low / presence / air decomposition. Only detected attacks are softened; steady-state response returns to unity. Air receives the strongest action, presence less, body only a small crest trim.
3. **Reference-scaled ADAA asymmetric stage** — Character uses a nonlinear curve so the low end of the control remains extremely clean. Bias and shape rise gradually to add restrained H2/H3 only when requested.
4. **High-headroom ADAA output rail** — the effective rail is extremely high at the clean end and lowers progressively with Character, so loud crests round before the rest of the mix sounds saturated.
5. **1 Hz implementation-only DC protection** — the real hardware output is DC-coupled; this only removes tiny DC produced by the intentionally asymmetric model.
6. **Click-free true bypass** — short internal crossfade to exact dry unity.

There is **no permanent smile EQ and no fixed high-cut**. After an onset settles, the transient bands sum back to the original signal.

## Default voicing

- Drive: +0.5 dB
- Character: 45%
- Output: -0.5 dB
- Mix: 100%

Built-in 48 kHz / 1 kHz regression measurement after the v0.5.1 tuning is approximately:

- -18 dBFS: **~0.00017% THD**
- -6 dBFS: **~0.00030% THD**
- -1 dBFS: **~0.00048% THD**
- Character 0, -1 dBFS: **~0.00020% THD**
- At +12 dB Drive with -12 dB output compensation and 45% Character: **~0.37% THD**

The strong-Drive figure is intentionally the user-invoked saturation range; the default figures stay converter-clean. These are plug-in test-harness THD figures, not claims that the real Apollo hardware produces those exact numbers. The published hardware THD+N remains the stricter reference. In v0.5.1 the static nonlinear residue was reduced sharply; the musical voicing is carried mainly by short, stereo-linked transient polish so steady programme remains open and clean.

The engineering target is: **clean body, larger perceived solidity without fake widening, softer crest, open sustain, restrained harmonic density, no brittle digital edge**.

## Model boundary

When reliable Twin X PCB values or controlled matched dry/reference loopback WAVs become available, this macromodel can be fitted further stage-by-stage without changing the plug-in architecture.
