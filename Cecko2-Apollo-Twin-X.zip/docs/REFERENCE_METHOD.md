# Apollo X reference method

This revision separates **hard calibration evidence** from **qualitative listening evidence**.

## Hard constraints used

1. Universal Audio Apollo Twin X Gen1 published output specifications: approximately flat 20 Hz-20 kHz response, +20.2 dBu maximum output, 100 ohm output impedance, and around -117 dB THD+N on line/monitor outputs.
2. Apollo x6/X-family published specifications and manuals describing an open/natural high-dynamic-range conversion path.
3. Public converter shootouts from Aeonica Music in which mastered tracks are routed through **UA Apollo x8 DAC -> Apollo x8 ADC** with no processing between conversion stages. Their methodology uses level matching and notes that converter differences are subtle.

## Qualitative material found

DTM DRIVER publishes direct Apollo x6 / Apollo X-family comparison audio, including raw Apollo X microphone/DI recordings and Apollo x6 versus earlier Apollo recordings. Those files are useful for qualitative descriptors such as clear, forward and large image, but they are **not isolated D/A-output measurements**, so they are not treated as a numeric transfer-function target.

## How the DSP uses this evidence

- Steady-state frequency response remains neutral instead of adding a permanent EQ curve.
- Character=0 is kept close to a transparent converter path.
- Harmonic residue is level-dependent and much lower than the previous revision.
- The 'commercial' part is implemented mainly as short programme-dependent transient polishing rather than broad compression, fixed HF roll-off or obvious saturation.
- Stereo detection is linked to avoid centre-image movement.

## Future exact fitting

The strongest next dataset would be a matched pair made from the **same digital source**:

`original digital file -> Apollo X/Twin X D/A -> clean reference A/D -> recorded WAV`

with level alignment, latency alignment and no analogue processing between D/A and A/D. Multiple levels (-24, -18, -12, -6, -3, -1 dBFS), impulses, swept tones and full mixes would allow fitting harmonic growth, transient residual and any tiny level/frequency dependence much more precisely.

## Public reference recordings located

- DTM DRIVER: Apollo 8 Quad vs Apollo x6 comparison, including direct WAV links for `APOLLO-8.wav` and `APOLLO-X.wav`. The comparison is a DI/recording-path test with identical Unison 1073/1176 settings, so it is qualitative evidence for the X-family character, not an isolated D/A transfer.
- DTM DRIVER: Apollo X normal microphone recording against SSL2/UR22C, with no post-record EQ/compression on the normal comparison. Again, this includes preamp/A/D behaviour and is not a pure D/A measurement.
- Aeonica Music: Apollo x8 DAC -> Apollo x8 ADC converter loops on mastered programme, including techno, downtempo and rock material; this is the most useful public method found for converter-path matching because the D/A and A/D stages are isolated from extra processing and level matching is emphasized.

The plug-in does **not** contain or redistribute those recordings. Raw binary audio from those hosts was not available to this build environment for sample-by-sample fitting, so v0.5.1 is deliberately described as **reference-informed**, not as a machine-learned clone. The DSP parameters are constrained by the published specifications and by the public comparison methodology/qualitative results.
