#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>

namespace apollo
{
namespace
{
constexpr float kPi = 3.14159265358979323846f;

float timeCoeff(double sampleRate, double seconds) noexcept
{
    const double fs = sampleRate > 1000.0 ? sampleRate : 44100.0;
    return static_cast<float>(std::exp(-1.0 / std::max(1.0, seconds * fs)));
}
}

void ApolloOutputModel::prepare(double sampleRate, int)
{
    sampleRate_ = sampleRate > 1000.0 ? sampleRate : 44100.0;
    smoothCoeff_ = timeCoeff(sampleRate_, 0.020);
    dcCoeff_ = std::exp(-2.0f * kPi * 1.0f / static_cast<float>(sampleRate_));

    // Two programme envelopes: the fast one catches the leading edge, while
    // the slow one follows body/sustain. The difference is therefore a true
    // transient cue rather than a compressor-style level detector.
    fastAttackCoeff_ = timeCoeff(sampleRate_, 0.00008);   // 0.08 ms
    fastReleaseCoeff_ = timeCoeff(sampleRate_, 0.0060);   // 6 ms
    slowAttackCoeff_ = timeCoeff(sampleRate_, 0.0035);    // 3.5 ms
    slowReleaseCoeff_ = timeCoeff(sampleRate_, 0.0500);   // 50 ms
    transientControlCoeff_ = timeCoeff(sampleRate_, 0.00012); // fast attack control
    transientReleaseCoeff_ = timeCoeff(sampleRate_, 0.0045); // quick recovery

    // Dynamic high-band split. At unity high-band gain lp+(x-lp) reconstructs
    // exactly, so there is no permanent EQ or phase coloration when inactive.
    const float hfSplitHz = 7200.0f;
    hfSplitCoeff_ = std::exp(-2.0f * kPi * hfSplitHz / static_cast<float>(sampleRate_));

    current_ = target_;
    reset();
}

void ApolloOutputModel::reset()
{
    for (auto& s : state_)
        s = {};
}

float ApolloOutputModel::dbToGain(float db) noexcept
{
    return std::pow(10.0f, db / 20.0f);
}

float ApolloOutputModel::clamp01(float x) noexcept
{
    return std::max(0.0f, std::min(1.0f, x));
}

float ApolloOutputModel::smoothStep(float edge0, float edge1, float x) noexcept
{
    if (edge1 <= edge0)
        return x >= edge1 ? 1.0f : 0.0f;
    const float t = clamp01((x - edge0) / (edge1 - edge0));
    return t * t * (3.0f - 2.0f * t);
}

float ApolloOutputModel::logCosh(float x) noexcept
{
    const float a = std::abs(x);
    return a + std::log1p(std::exp(-2.0f * a)) - 0.6931471805599453f;
}

float ApolloOutputModel::adaaTanh(float x, float& previous, float amount) noexcept
{
    // First-order antiderivative anti-aliasing for tanh(amount*x)/amount.
    // Use double precision in the antiderivative difference: at low signal
    // levels float log(cosh()) subtraction loses too much precision.
    amount = std::max(0.05f, amount);
    const double a = static_cast<double>(amount);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);
    const double dx = xd - pd;
    double y;

    if (std::abs(dx) > 1.0e-7)
    {
        const auto logCoshD = [] (double v)
        {
            const double av = std::abs(v);
            return av + std::log1p(std::exp(-2.0 * av)) - 0.69314718055994530942;
        };
        const double invA2 = 1.0 / (a * a);
        const double f1 = logCoshD(a * xd) * invA2;
        const double f0 = logCoshD(a * pd) * invA2;
        y = (f1 - f0) / dx;
    }
    else
    {
        y = std::tanh(a * 0.5 * (xd + pd)) / a;
    }

    // Endpoint correction removes the fixed half-sample/low-pass character
    // of first-order ADAA in the linear limit. For f(x)=x this becomes exactly
    // y=x, so the antialiasing helper does not permanently dull the top end.
    const double fCurr = std::tanh(a * xd) / a;
    const double fPrev = std::tanh(a * pd) / a;
    y += 0.5 * (fCurr - fPrev);

    previous = x;
    return static_cast<float>(y);
}

float ApolloOutputModel::asymmetricDriver(float x, float character) noexcept
{
    // Very small asymmetry: enough to introduce a restrained H2 component
    // without turning the output model into an exciter.
    const float c = clamp01(character);
    const float amount = 0.085f + 0.115f * c;
    const float bias = 0.015f + 0.028f * c;
    const float tb = std::tanh(amount * bias);
    const float denom = amount * (1.0f - tb * tb);
    const float num = std::tanh(amount * (x + bias)) - tb;
    return num / std::max(denom, 1.0e-5f);
}

float ApolloOutputModel::softRail(float x, float rail) noexcept
{
    // Smooth 4th-order rail: no hard digital corner. The default rail rounds
    // only hot peaks and lets normal programme level remain very clean.
    rail = std::max(0.65f, rail);
    const float a = std::abs(x) / rail;
    const float d = std::pow(1.0f + a*a*a*a, 0.25f);
    return x / d;
}

float ApolloOutputModel::polishTransient(float x, ChannelState& s, float character) noexcept
{
    const float c = clamp01(character);
    const float level = std::abs(x);

    const float fCoeff = level > s.fastEnv ? fastAttackCoeff_ : fastReleaseCoeff_;
    s.fastEnv = fCoeff * s.fastEnv + (1.0f - fCoeff) * level;

    const float slCoeff = level > s.slowEnv ? slowAttackCoeff_ : slowReleaseCoeff_;
    s.slowEnv = slCoeff * s.slowEnv + (1.0f - slCoeff) * level;

    // Scale-normalised onset measure. Sustained tones converge to ~0 even at
    // high level, so the top end opens back up immediately after the attack.
    const float delta = std::max(0.0f, s.fastEnv - s.slowEnv);
    const float onset = delta / (0.018f + s.fastEnv);
    const float detected = smoothStep(0.055f, 0.42f, onset);

    // Smooth the control itself to avoid grain on complex cymbal/percussion
    // edges. Release is intentionally quick enough not to dull sustain.
    const float targetControl = detected;
    const float ctrlCoeff = targetControl > s.transientControl
        ? transientControlCoeff_
        : transientReleaseCoeff_;
    s.transientControl = ctrlCoeff * s.transientControl
                       + (1.0f - ctrlCoeff) * targetControl;

    // Perfect-reconstruction split when highGain==1. Only the very beginning
    // of an aggressive transient gets a small high-band reduction. At the
    // default Character=50% the maximum reduction is about 2.4 dB above the
    // split frequency, which is enough to remove "digital glass" without
    // turning the plug-in dark.
    s.hfSplitLp = hfSplitCoeff_ * s.hfSplitLp + (1.0f - hfSplitCoeff_) * x;
    const float high = x - s.hfSplitLp;
    const float maxReduction = 0.055f + 0.315f * c; // linear high-band reduction
    const float highGain = 1.0f - maxReduction * s.transientControl;

    return s.hfSplitLp + high * highGain;
}

void ApolloOutputModel::smoothParameters() noexcept
{
    const float a = smoothCoeff_;
    const float b = 1.0f - a;
    current_.driveDb   = a * current_.driveDb   + b * target_.driveDb;
    current_.character = a * current_.character + b * target_.character;
    current_.outputDb  = a * current_.outputDb  + b * target_.outputDb;
    current_.mix       = a * current_.mix       + b * target_.mix;
}

float ApolloOutputModel::processSample(float x, int channel) noexcept
{
    smoothParameters();
    return processSampleInternal(x, channel);
}

float ApolloOutputModel::processSampleInternal(float x, int channel) noexcept
{
    channel = std::max(0, std::min(channel, static_cast<int>(state_.size()) - 1));
    auto& s = state_[static_cast<std::size_t>(channel)];

    const float character = clamp01(current_.character);
    const float dry = x;

    // First remove only the abrasive leading-edge HF excess. This is dynamic
    // and programme-dependent; it is not a fixed low-pass or smile EQ.
    const float polished = polishTransient(x, s, character);
    const float driven = polished * dbToGain(current_.driveDb);

    // Stage 1: DAC I/V / filter amplifier family behaviour.
    // We do not claim the unknown Twin X R/C values here; this is a calibrated
    // macromodel constrained by the confirmed clean, high-headroom topology.
    const float stage1Amount = 0.07f + 0.15f * character;
    float y = adaaTanh(driven, s.prevStage1, stage1Amount);

    // Stage 2: balanced output amplifier family. Tiny asymmetry plus a rail
    // that becomes progressively softer with Character.
    y = asymmetricDriver(y, character);
    const float rail = 1.88f - 0.33f * character;
    y = softRail(y, rail);

    // The hardware output is DC-coupled. This 1 Hz blocker exists only to
    // prevent the intentionally asymmetric macromodel from accumulating DC.
    const float hp = y - s.prevDcIn + dcCoeff_ * s.prevDcOut;
    s.prevDcIn = y;
    s.prevDcOut = hp;

    const float mix = clamp01(current_.mix);
    const float wetDry = dry + (hp - dry) * mix;
    return wetDry * dbToGain(current_.outputDb);
}

void ApolloOutputModel::process(const float* const* inputs,
                                float* const* outputs,
                                int channels,
                                int samples) noexcept
{
    const int nCh = std::max(0, std::min(channels, static_cast<int>(state_.size())));
    if (!inputs || !outputs || samples <= 0)
        return;

    for (int i = 0; i < samples; ++i)
    {
        // Smooth once per audio frame so L/R see identical parameter state.
        smoothParameters();
        for (int ch = 0; ch < nCh; ++ch)
        {
            if (!inputs[ch] || !outputs[ch])
                continue;
            outputs[ch][i] = processSampleInternal(inputs[ch][i], ch);
        }
    }
}
} // namespace apollo
