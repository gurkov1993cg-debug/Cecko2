#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>

namespace apollo
{
namespace
{
constexpr float kPi = 3.14159265358979323846f;

float timeCoeff(double sampleRate, double seconds) noexcept
{
    const double fs = sampleRate > 1000.0 ? sampleRate : 44100.0;
    return static_cast<float>(std::exp(-1.0 / std::max(1.0, seconds * fs)));
}
}

void ApolloOutputModel::prepare(double sampleRate, int)
{
    sampleRate_ = sampleRate > 1000.0 ? sampleRate : 44100.0;

    // Slow enough to prevent zipper noise, fast enough to feel immediate.
    smoothCoeff_ = timeCoeff(sampleRate_, 0.018);
    bypassSmoothCoeff_ = timeCoeff(sampleRate_, 0.004);

    // The real Twin X output is DC-coupled. This is an implementation guard
    // against tiny DC created by our deliberately asymmetric macromodel.
    dcCoeff_ = std::exp(-2.0f * kPi * 1.0f / static_cast<float>(sampleRate_));

    // Programme-aware onset detector. Fast follows the leading edge, slow
    // follows the body. Their normalised difference is largely level invariant.
    fastAttackCoeff_ = timeCoeff(sampleRate_, 0.00006);   // 0.06 ms
    fastReleaseCoeff_ = timeCoeff(sampleRate_, 0.0070);   // 7 ms
    slowAttackCoeff_ = timeCoeff(sampleRate_, 0.0040);    // 4 ms
    slowReleaseCoeff_ = timeCoeff(sampleRate_, 0.0700);   // 70 ms
    transientAttackCoeff_ = timeCoeff(sampleRate_, 0.00004);
    transientReleaseCoeff_ = timeCoeff(sampleRate_, 0.0075);

    // Two complementary one-pole splits. The bands sum exactly to x, so once
    // transient gain returns to 1 there is no permanent EQ or phase shift.
    const float presenceHz = 4200.0f;
    const float airHz = std::min(10500.0f, 0.42f * static_cast<float>(sampleRate_));
    presenceSplitCoeff_ = std::exp(-2.0f * kPi * presenceHz / static_cast<float>(sampleRate_));
    airSplitCoeff_ = std::exp(-2.0f * kPi * airHz / static_cast<float>(sampleRate_));

    current_ = target_;
    reset();
}

void ApolloOutputModel::reset()
{
    linkedDetector_ = {};
    for (auto& s : state_)
        s = {};
}

void ApolloOutputModel::setParameters(const Parameters& p) noexcept
{
    // Keep malformed/legacy host state from ever reaching exp/tanh with
    // unbounded or non-finite values. Normal automation already arrives 0..1,
    // but defensive clamping makes the audio path deterministic.
    target_.driveDb = std::isfinite(p.driveDb) ? std::clamp(p.driveDb, -12.0f, 12.0f) : 0.5f;
    target_.character = std::isfinite(p.character) ? clamp01(p.character) : 0.45f;
    target_.outputDb = std::isfinite(p.outputDb) ? std::clamp(p.outputDb, -12.0f, 12.0f) : -0.5f;
    target_.mix = std::isfinite(p.mix) ? clamp01(p.mix) : 1.0f;
    target_.bypass = std::isfinite(p.bypass) ? clamp01(p.bypass) : 0.0f;
}

float ApolloOutputModel::dbToGain(float db) noexcept
{
    return std::pow(10.0f, db / 20.0f);
}

float ApolloOutputModel::clamp01(float x) noexcept
{
    return std::max(0.0f, std::min(1.0f, x));
}

float ApolloOutputModel::smoothStep(float edge0, float edge1, float x) noexcept
{
    if (edge1 <= edge0)
        return x >= edge1 ? 1.0f : 0.0f;
    const float t = clamp01((x - edge0) / (edge1 - edge0));
    return t * t * (3.0f - 2.0f * t);
}

double ApolloOutputModel::logCoshD(double x) noexcept
{
    const double a = std::abs(x);
    return a + std::log1p(std::exp(-2.0 * a)) - 0.69314718055994530942;
}

float ApolloOutputModel::adaaAsymmetricTanh(float x, float& previous,
                                            float shape, float bias) noexcept
{
    // f(x) = [tanh(a(x+b)) - tanh(ab)] / [a(1-tanh^2(ab))]
    // It is slope-normalised at zero, so low-level gain stays exactly 1.
    shape = std::max(0.005f, shape);
    bias = std::max(-0.20f, std::min(0.20f, bias));

    const double a = static_cast<double>(shape);
    const double b = static_cast<double>(bias);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);
    const double tb = std::tanh(a * b);
    const double norm = a * std::max(1.0e-8, 1.0 - tb * tb);

    const auto f = [a, b, tb, norm] (double v)
    {
        return (std::tanh(a * (v + b)) - tb) / norm;
    };
    const auto F = [a, b, tb, norm] (double v)
    {
        // Integral of f(x).
        return (logCoshD(a * (v + b)) / a - tb * v) / norm;
    };

    const double dx = xd - pd;
    double y = std::abs(dx) > 1.0e-8 ? (F(xd) - F(pd)) / dx
                                      : f(0.5 * (xd + pd));

    // Endpoint correction restores the exact current sample in the linear
    // limit while retaining the antiderivative smoothing of nonlinear edges.
    y += 0.5 * (f(xd) - f(pd));
    previous = x;
    return static_cast<float>(y);
}

float ApolloOutputModel::adaaRailTanh(float x, float& previous, float rail) noexcept
{
    // Symmetric, slope-normalised analogue rail: f(x)=rail*tanh(x/rail).
    // At normal programme levels it is virtually linear; near full scale it
    // rounds crest factor smoothly instead of making a digital corner.
    rail = std::max(1.25f, rail);
    const double r = static_cast<double>(rail);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);

    const auto f = [r] (double v) { return r * std::tanh(v / r); };
    const auto F = [r] (double v) { return r * r * logCoshD(v / r); };

    const double dx = xd - pd;
    double y = std::abs(dx) > 1.0e-8 ? (F(xd) - F(pd)) / dx
                                      : f(0.5 * (xd + pd));
    y += 0.5 * (f(xd) - f(pd));
    previous = x;
    return static_cast<float>(y);
}

float ApolloOutputModel::detectTransient(float level, DetectorState& d) noexcept
{
    level = std::max(0.0f, level);

    const float fCoeff = level > d.fastEnv ? fastAttackCoeff_ : fastReleaseCoeff_;
    d.fastEnv = fCoeff * d.fastEnv + (1.0f - fCoeff) * level;

    const float sCoeff = level > d.slowEnv ? slowAttackCoeff_ : slowReleaseCoeff_;
    d.slowEnv = sCoeff * d.slowEnv + (1.0f - sCoeff) * level;

    const float delta = std::max(0.0f, d.fastEnv - d.slowEnv);
    const float onset = delta / (0.020f + d.fastEnv);

    // Do not chase tiny low-level noise/reverb tails. The detector fades in
    // from roughly -40 dBFS and is fully active around -22 dBFS.
    const float levelGate = smoothStep(0.010f, 0.080f, d.fastEnv);
    const float detected = smoothStep(0.050f, 0.40f, onset) * levelGate;

    const float coeff = detected > d.transientControl
        ? transientAttackCoeff_
        : transientReleaseCoeff_;
    d.transientControl = coeff * d.transientControl
                       + (1.0f - coeff) * detected;
    return clamp01(d.transientControl);
}

float ApolloOutputModel::polishTransient(float x, ChannelState& s,
                                         float control, float character) noexcept
{
    const float c = clamp01(character);
    control = clamp01(control);

    // Exact-reconstruction 3-band decomposition while inactive.
    s.presenceLp = presenceSplitCoeff_ * s.presenceLp
                 + (1.0f - presenceSplitCoeff_) * x;
    s.airLp = airSplitCoeff_ * s.airLp
            + (1.0f - airSplitCoeff_) * x;

    float low = s.presenceLp;
    float presence = s.airLp - s.presenceLp;
    float air = x - s.airLp;

    // Sound-engineering intent:
    // - tiny whole-crest softening prevents the attack from feeling detached;
    // - more action in 4.2-10.5 kHz removes hard presence;
    // - strongest, shortest action in the air band removes digital glass.
    // Character=0 leaves this stage at exact unity.
    const float bodyGain = 1.0f - (0.035f * c) * control;
    const float presenceGain = 1.0f - (0.140f * c) * control;
    const float airGain = 1.0f - (0.340f * c) * control;

    low *= bodyGain;
    presence *= bodyGain * presenceGain;
    air *= bodyGain * airGain;
    return low + presence + air;
}

void ApolloOutputModel::smoothParameters() noexcept
{
    const float a = smoothCoeff_;
    const float b = 1.0f - a;
    current_.driveDb   = a * current_.driveDb   + b * target_.driveDb;
    current_.character = a * current_.character + b * target_.character;
    current_.outputDb  = a * current_.outputDb  + b * target_.outputDb;
    current_.mix       = a * current_.mix       + b * target_.mix;

    const float ba = bypassSmoothCoeff_;
    current_.bypass = ba * current_.bypass + (1.0f - ba) * clamp01(target_.bypass);
}

float ApolloOutputModel::processSample(float x, int channel) noexcept
{
    smoothParameters();
    channel = std::max(0, std::min(channel, static_cast<int>(state_.size()) - 1));
    auto& s = state_[static_cast<std::size_t>(channel)];
    const float control = detectTransient(std::abs(x), s.localDetector);
    return processSampleInternal(x, channel, control);
}

float ApolloOutputModel::processSampleInternal(float x, int channel,
                                               float transientControl) noexcept
{
    channel = std::max(0, std::min(channel, static_cast<int>(state_.size()) - 1));
    auto& s = state_[static_cast<std::size_t>(channel)];

    const float character = clamp01(current_.character);
    const float dry = x;

    // 1) Programme-dependent transient polish. No fixed EQ is applied.
    const float polished = polishTransient(x, s, transientControl, character);

    // 2) Internal analogue level. Drive is the intentional user push into the
    // output macromodel; low-level gain of the stages themselves is unity.
    const float driven = polished * dbToGain(current_.driveDb);

    // 3) DAC I/V / output-amplifier density. The asymmetry is deliberately
    // restrained: it adds a small H2 component without turning into an exciter.
    // Public Apollo X/Twin X measurements and converter loopback shootouts
    // point to a very clean path at normal level.  Character therefore scales
    // the *residual* analogue density instead of imposing constant saturation.
    // At Character=0 this stage is close to measurement-transparent; the
    // default adds only a trace, level-dependent H2/H3 residue, while Drive can
    // still deliberately push the model harder.  This keeps the base path
    // converter-clean; the audible polish comes mainly from the short linked
    // transient stage rather than from permanent saturation.
    const float cCurve = std::pow(character, 1.40f);
    const float drivePush = smoothStep(0.0f, 12.0f, current_.driveDb);
    const float driveCurve = std::pow(drivePush, 1.20f);
    const float shape = 0.005f + 0.007f * cCurve + 0.160f * cCurve * driveCurve;
    const float bias = 0.0005f + 0.006f * cCurve + 0.040f * cCurve * driveCurve;
    float y = adaaAsymmetricTanh(driven, s.prevStage1, shape, bias);

    // 4) High-headroom balanced output rail. At the reference/default point it
    // is effectively linear. Positive Drive progressively lowers the virtual
    // headroom only when Character is also asking for colour, making the Drive
    // control genuinely useful without hiding saturation in the normal path.
    const float baseRail = 2500.0f - 1500.0f * std::pow(character, 0.80f);
    const float rail = baseRail / (1.0f + 24.0f * cCurve * driveCurve);
    y = adaaRailTanh(y, s.prevStage2, rail);

    // 5) Implementation-only 1 Hz DC blocker.
    const float hp = y - s.prevDcIn + dcCoeff_ * s.prevDcOut;
    s.prevDcIn = y;
    s.prevDcOut = hp;

    const float mix = clamp01(current_.mix);
    const float effected = (dry + (hp - dry) * mix) * dbToGain(current_.outputDb);

    // True-bypass crossfade after output trim. This eliminates clicks and also
    // guarantees fully dry unity once the bypass ramp reaches 1.
    const float by = clamp01(current_.bypass);
    return effected + (dry - effected) * by;
}

void ApolloOutputModel::process(const float* const* inputs,
                                float* const* outputs,
                                int channels,
                                int samples) noexcept
{
    const int nCh = std::max(0, std::min(channels, static_cast<int>(state_.size())));
    if (!inputs || !outputs || samples <= 0 || nCh <= 0)
        return;

    for (int i = 0; i < samples; ++i)
    {
        // One shared parameter state and one shared transient detector per
        // frame: L/R remain coherent instead of changing tone independently.
        smoothParameters();

        float linkedLevel = 0.0f;
        for (int ch = 0; ch < nCh; ++ch)
        {
            if (inputs[ch])
                linkedLevel = std::max(linkedLevel, std::abs(inputs[ch][i]));
        }
        const float transientControl = detectTransient(linkedLevel, linkedDetector_);

        for (int ch = 0; ch < nCh; ++ch)
        {
            if (!inputs[ch] || !outputs[ch])
                continue;
            outputs[ch][i] = processSampleInternal(inputs[ch][i], ch, transientControl);
        }
    }
}
} // namespace apollo
