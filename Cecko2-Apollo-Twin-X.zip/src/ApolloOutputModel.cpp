#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>

namespace apollo
{
namespace
{
constexpr float kPi = 3.14159265358979323846f;
}

void ApolloOutputModel::prepare(double sampleRate, int)
{
    sampleRate_ = sampleRate > 1000.0 ? sampleRate : 44100.0;
    smoothCoeff_ = std::exp(-1.0f / static_cast<float>(0.020 * sampleRate_));
    dcCoeff_ = std::exp(-2.0f * kPi * 1.0f / static_cast<float>(sampleRate_));
    current_ = target_;
    reset();
}

void ApolloOutputModel::reset()
{
    for (auto& s : state_)
        s = {};
}

float ApolloOutputModel::dbToGain(float db) noexcept
{
    return std::pow(10.0f, db / 20.0f);
}

float ApolloOutputModel::clamp01(float x) noexcept
{
    return std::max(0.0f, std::min(1.0f, x));
}

float ApolloOutputModel::logCosh(float x) noexcept
{
    const float a = std::abs(x);
    return a + std::log1p(std::exp(-2.0f * a)) - 0.6931471805599453f;
}

float ApolloOutputModel::adaaTanh(float x, float& previous, float amount) noexcept
{
    // First-order antiderivative anti-aliasing for tanh(amount*x)/amount.
    // Use double precision in the antiderivative difference: at low signal
    // levels float log(cosh()) subtraction loses too much precision.
    amount = std::max(0.05f, amount);
    const double a = static_cast<double>(amount);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);
    const double dx = xd - pd;
    double y;

    if (std::abs(dx) > 1.0e-7)
    {
        const auto logCoshD = [] (double v)
        {
            const double av = std::abs(v);
            return av + std::log1p(std::exp(-2.0 * av)) - 0.69314718055994530942;
        };
        const double invA2 = 1.0 / (a * a);
        const double f1 = logCoshD(a * xd) * invA2;
        const double f0 = logCoshD(a * pd) * invA2;
        y = (f1 - f0) / dx;
    }
    else
    {
        y = std::tanh(a * 0.5 * (xd + pd)) / a;
    }

    previous = x;
    return static_cast<float>(y);
}

float ApolloOutputModel::asymmetricDriver(float x, float character) noexcept
{
    // Very small asymmetry: enough to introduce a restrained H2 component
    // without turning the output model into an exciter.
    const float c = clamp01(character);
    const float amount = 0.10f + 0.12f * c;
    const float bias = 0.020f + 0.030f * c;
    const float tb = std::tanh(amount * bias);
    const float denom = amount * (1.0f - tb * tb);
    const float num = std::tanh(amount * (x + bias)) - tb;
    return num / std::max(denom, 1.0e-5f);
}

float ApolloOutputModel::softRail(float x, float rail) noexcept
{
    // Smooth 4th-order rail. With 0 dBFS treated as the nominal full-scale
    // analogue output, the default rail only rounds the very top of peaks.
    rail = std::max(0.65f, rail);
    const float a = std::abs(x) / rail;
    const float d = std::pow(1.0f + a*a*a*a, 0.25f);
    return x / d;
}

void ApolloOutputModel::smoothParameters() noexcept
{
    const float a = smoothCoeff_;
    const float b = 1.0f - a;
    current_.driveDb   = a * current_.driveDb   + b * target_.driveDb;
    current_.character = a * current_.character + b * target_.character;
    current_.outputDb  = a * current_.outputDb  + b * target_.outputDb;
    current_.mix       = a * current_.mix       + b * target_.mix;
}

float ApolloOutputModel::processSample(float x, int channel) noexcept
{
    smoothParameters();
    return processSampleInternal(x, channel);
}

float ApolloOutputModel::processSampleInternal(float x, int channel) noexcept
{
    channel = std::max(0, std::min(channel, static_cast<int>(state_.size()) - 1));
    auto& s = state_[static_cast<std::size_t>(channel)];

    const float character = clamp01(current_.character);
    const float dry = x;
    const float driven = x * dbToGain(current_.driveDb);

    // Stage 1: DAC I/V / filter amplifier family behaviour.
    // We do not claim the unknown Twin X R/C values here; this is a calibrated
    // macromodel constrained by the confirmed clean, high-headroom topology.
    const float stage1Amount = 0.08f + 0.18f * character;
    float y = adaaTanh(driven, s.prevStage1, stage1Amount);

    // Stage 2: balanced output amplifier family. Tiny asymmetry plus a rail
    // that becomes progressively softer with Character.
    y = asymmetricDriver(y, character);
    const float rail = 1.80f - 0.35f * character;
    y = softRail(y, rail);

    // The hardware output is DC-coupled. This 1 Hz blocker exists only to
    // prevent the intentionally asymmetric macromodel from accumulating DC.
    const float hp = y - s.prevDcIn + dcCoeff_ * s.prevDcOut;
    s.prevDcIn = y;
    s.prevDcOut = hp;

    const float mix = clamp01(current_.mix);
    const float wetDry = dry + (hp - dry) * mix;
    return wetDry * dbToGain(current_.outputDb);
}

void ApolloOutputModel::process(const float* const* inputs,
                                float* const* outputs,
                                int channels,
                                int samples) noexcept
{
    const int nCh = std::max(0, std::min(channels, static_cast<int>(state_.size())));
    if (!inputs || !outputs || samples <= 0)
        return;

    for (int i = 0; i < samples; ++i)
    {
        // Smooth once per audio frame so L/R see identical parameter state.
        smoothParameters();
        for (int ch = 0; ch < nCh; ++ch)
        {
            if (!inputs[ch] || !outputs[ch])
                continue;
            outputs[ch][i] = processSampleInternal(inputs[ch][i], ch);
        }
    }
}
} // namespace apollo
