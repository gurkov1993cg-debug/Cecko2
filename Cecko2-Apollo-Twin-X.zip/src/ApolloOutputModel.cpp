#include "ApolloOutputModel.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace apollo
{
namespace
{
constexpr float kPi = 3.14159265358979323846f;
constexpr double kLn2 = 0.693147180559945309417232121458;

float timeCoeff(double sampleRate, double seconds) noexcept
{
    const double fs = (std::isfinite(sampleRate) && sampleRate >= 8000.0)
        ? sampleRate
        : 44100.0;
    return static_cast<float>(std::exp(-1.0 / std::max(1.0, seconds * fs)));
}
}

bool ApolloOutputModel::prepare(double sampleRate, int channels) noexcept
{
    if (!std::isfinite(sampleRate) || sampleRate < 8000.0 || sampleRate > 768000.0)
    {
        prepared_ = false;
        return false;
    }

    if (channels < 1 || channels > kMaxChannels)
    {
        prepared_ = false;
        return false;
    }

    sampleRate_ = sampleRate;
    preparedChannels_ = channels;

    // Slow enough to prevent zipper noise, fast enough to feel immediate.
    smoothCoeff_ = timeCoeff(sampleRate_, 0.018);
    bypassSmoothCoeff_ = timeCoeff(sampleRate_, 0.004);

    // Implementation guard against tiny DC created by the asymmetric macromodel.
    dcCoeff_ = std::exp(-2.0f * kPi * 1.0f / static_cast<float>(sampleRate_));

    // Programme-aware onset detector.
    fastAttackCoeff_ = timeCoeff(sampleRate_, 0.00006);   // 0.06 ms
    fastReleaseCoeff_ = timeCoeff(sampleRate_, 0.0070);   // 7 ms
    slowAttackCoeff_ = timeCoeff(sampleRate_, 0.0040);    // 4 ms
    slowReleaseCoeff_ = timeCoeff(sampleRate_, 0.0700);   // 70 ms
    transientAttackCoeff_ = timeCoeff(sampleRate_, 0.00004);
    transientReleaseCoeff_ = timeCoeff(sampleRate_, 0.0075);

    // Complementary one-pole splits; bands sum exactly to x while inactive.
    const float presenceHz = 4200.0f;
    const float airHz = std::min(10500.0f, 0.42f * static_cast<float>(sampleRate_));
    presenceSplitCoeff_ = std::exp(-2.0f * kPi * presenceHz / static_cast<float>(sampleRate_));
    airSplitCoeff_ = std::exp(-2.0f * kPi * airHz / static_cast<float>(sampleRate_));

    syncParametersFromControlThread();
    current_ = target_;
    reset();
    prepared_ = true;
    return true;
}

void ApolloOutputModel::reset() noexcept
{
    linkedDetector_ = {};
    for (auto& s : state_)
        s = {};
}

void ApolloOutputModel::setParameters(const Parameters& p) noexcept
{
    const float drive = std::isfinite(p.driveDb)
        ? std::clamp(p.driveDb, kMinDriveDb, kMaxDriveDb)
        : 0.5f;
    const float character = std::isfinite(p.character) ? clamp01(p.character) : 0.45f;
    const float output = std::isfinite(p.outputDb)
        ? std::clamp(p.outputDb, kMinOutputDb, kMaxOutputDb)
        : -0.5f;
    const float mix = std::isfinite(p.mix) ? clamp01(p.mix) : 1.0f;
    const float bypass = std::isfinite(p.bypass) ? clamp01(p.bypass) : 0.0f;

    // Odd sequence means a write is in progress; even means stable.
    pendingParameters_.sequence.fetch_add(1u, std::memory_order_acq_rel);
    pendingParameters_.driveDb.store(drive, std::memory_order_relaxed);
    pendingParameters_.character.store(character, std::memory_order_relaxed);
    pendingParameters_.outputDb.store(output, std::memory_order_relaxed);
    pendingParameters_.mix.store(mix, std::memory_order_relaxed);
    pendingParameters_.bypass.store(bypass, std::memory_order_relaxed);
    pendingParameters_.sequence.fetch_add(1u, std::memory_order_release);
}

void ApolloOutputModel::syncParametersFromControlThread() noexcept
{
    // Bounded retry: never spin indefinitely on the real-time thread.
    for (int attempt = 0; attempt < 3; ++attempt)
    {
        const std::uint32_t before = pendingParameters_.sequence.load(std::memory_order_acquire);
        if ((before & 1u) != 0u)
            continue;

        Parameters snapshot;
        snapshot.driveDb = pendingParameters_.driveDb.load(std::memory_order_relaxed);
        snapshot.character = pendingParameters_.character.load(std::memory_order_relaxed);
        snapshot.outputDb = pendingParameters_.outputDb.load(std::memory_order_relaxed);
        snapshot.mix = pendingParameters_.mix.load(std::memory_order_relaxed);
        snapshot.bypass = pendingParameters_.bypass.load(std::memory_order_relaxed);

        const std::uint32_t after = pendingParameters_.sequence.load(std::memory_order_acquire);
        if (before == after && (after & 1u) == 0u)
        {
            target_ = snapshot;
            return;
        }
    }
    // If the UI happens to update during all attempts, keep the previous target
    // for this block. Parameter smoothing makes this inaudible and avoids locks.
}

float ApolloOutputModel::dbToGain(float db) noexcept
{
    if (!std::isfinite(db))
        return 1.0f;
    return std::pow(10.0f, db / 20.0f);
}

float ApolloOutputModel::clamp01(float x) noexcept
{
    if (!std::isfinite(x))
        return 0.0f;
    return std::clamp(x, 0.0f, 1.0f);
}

float ApolloOutputModel::smoothStep(float edge0, float edge1, float x) noexcept
{
    if (!std::isfinite(edge0) || !std::isfinite(edge1) || !std::isfinite(x))
        return 0.0f;
    if (edge1 <= edge0)
        return x >= edge1 ? 1.0f : 0.0f;
    const float t = clamp01((x - edge0) / (edge1 - edge0));
    return t * t * (3.0f - 2.0f * t);
}

float ApolloOutputModel::flushTiny(float x) noexcept
{
    if (!std::isfinite(x))
        return 0.0f;
    return std::abs(x) < 1.0e-20f ? 0.0f : x;
}

float ApolloOutputModel::sanitizeSample(float x) noexcept
{
    return std::isfinite(x) ? x : 0.0f;
}

double ApolloOutputModel::logCoshD(double x) noexcept
{
    if (!std::isfinite(x))
        return std::numeric_limits<double>::infinity();

    const double ax = std::abs(x);

    // Avoid cancellation close to zero.
    if (ax < 1.0e-4)
    {
        const double x2 = x * x;
        return 0.5 * x2 - (x2 * x2) / 12.0 + (x2 * x2 * x2) / 45.0;
    }

    // Stable for very large |x|; never forms cosh(x) directly.
    return ax + std::log1p(std::exp(-2.0 * ax)) - kLn2;
}

float ApolloOutputModel::adaaAsymmetricTanh(float x, float& previous,
                                            float shape, float bias) noexcept
{
    x = sanitizeSample(x);
    if (!std::isfinite(previous))
        previous = x;

    shape = std::isfinite(shape) ? std::clamp(shape, 0.001f, 4.0f) : 0.005f;
    bias = std::isfinite(bias) ? std::clamp(bias, -0.20f, 0.20f) : 0.0f;

    const double a = static_cast<double>(shape);
    const double b = static_cast<double>(bias);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);
    const double tb = std::tanh(a * b);
    const double slope = std::max(1.0e-12, 1.0 - tb * tb);
    const double norm = a * slope;

    const auto f = [a, b, tb, norm] (double v) noexcept
    {
        return (std::tanh(a * (v + b)) - tb) / norm;
    };
    const auto F = [a, b, tb, norm] (double v) noexcept
    {
        return (ApolloOutputModel::logCoshD(a * (v + b)) / a - tb * v) / norm;
    };

    const double dx = xd - pd;
    const double scale = 1.0 + std::max(std::abs(xd), std::abs(pd));
    const double epsilon = 1.0e-7 * scale;

    double y = std::abs(dx) > epsilon
        ? (F(xd) - F(pd)) / dx
        : f(0.5 * (xd + pd));

    // Endpoint correction preserves the current-sample linear limit and keeps
    // dry/wet alignment practical. This is intentionally a modified first-order ADAA.
    y += 0.5 * (f(xd) - f(pd));

    previous = x;
    if (!std::isfinite(y))
        return 0.0f;
    return static_cast<float>(y);
}

float ApolloOutputModel::adaaRailTanh(float x, float& previous, float rail) noexcept
{
    x = sanitizeSample(x);
    if (!std::isfinite(previous))
        previous = x;

    rail = std::isfinite(rail) ? std::clamp(rail, 1.05f, 10000.0f) : 10000.0f;
    const double r = static_cast<double>(rail);
    const double xd = static_cast<double>(x);
    const double pd = static_cast<double>(previous);

    const auto f = [r] (double v) noexcept { return r * std::tanh(v / r); };
    const auto F = [r] (double v) noexcept
    {
        return r * r * ApolloOutputModel::logCoshD(v / r);
    };

    const double dx = xd - pd;
    const double scale = 1.0 + std::max(std::abs(xd), std::abs(pd));
    const double epsilon = 1.0e-7 * scale;

    double y = std::abs(dx) > epsilon
        ? (F(xd) - F(pd)) / dx
        : f(0.5 * (xd + pd));

    y += 0.5 * (f(xd) - f(pd));
    previous = x;

    if (!std::isfinite(y))
        return 0.0f;
    return static_cast<float>(y);
}

float ApolloOutputModel::detectTransient(float level, DetectorState& d) noexcept
{
    level = std::max(0.0f, sanitizeSample(level));

    const float fCoeff = level > d.fastEnv ? fastAttackCoeff_ : fastReleaseCoeff_;
    d.fastEnv = flushTiny(fCoeff * d.fastEnv + (1.0f - fCoeff) * level);

    const float sCoeff = level > d.slowEnv ? slowAttackCoeff_ : slowReleaseCoeff_;
    d.slowEnv = flushTiny(sCoeff * d.slowEnv + (1.0f - sCoeff) * level);

    const float delta = std::max(0.0f, d.fastEnv - d.slowEnv);
    const float onset = delta / std::max(0.020f, 0.020f + d.fastEnv);

    const float levelGate = smoothStep(0.010f, 0.080f, d.fastEnv);
    const float detected = smoothStep(0.050f, 0.40f, onset) * levelGate;

    const float coeff = detected > d.transientControl
        ? transientAttackCoeff_
        : transientReleaseCoeff_;
    d.transientControl = flushTiny(coeff * d.transientControl
                       + (1.0f - coeff) * detected);
    return clamp01(d.transientControl);
}

float ApolloOutputModel::polishTransient(float x, ChannelState& s,
                                         float control, float character) noexcept
{
    x = sanitizeSample(x);
    const float c = clamp01(character);
    control = clamp01(control);

    s.presenceLp = flushTiny(presenceSplitCoeff_ * s.presenceLp
                 + (1.0f - presenceSplitCoeff_) * x);
    s.airLp = flushTiny(airSplitCoeff_ * s.airLp
            + (1.0f - airSplitCoeff_) * x);

    float low = s.presenceLp;
    float presence = s.airLp - s.presenceLp;
    float air = x - s.airLp;

    // Character response is deliberately front-loaded compared with the old
    // pow(character, 1.4): the middle half of the knob now does useful work.
    // This is attenuation only during detected attacks, never a permanent HF boost.
    const float cCurve = std::pow(c, 0.50f);
    const float bodyGain = 1.0f - 0.080f * cCurve * control;
    const float presenceGain = 1.0f - 0.300f * cCurve * control;
    const float airGain = 1.0f - 0.550f * cCurve * control;

    low *= bodyGain;
    presence *= bodyGain * presenceGain;
    air *= bodyGain * airGain;
    return low + presence + air;
}

void ApolloOutputModel::smoothParameters() noexcept
{
    const float a = smoothCoeff_;
    const float b = 1.0f - a;
    current_.driveDb   = a * current_.driveDb   + b * target_.driveDb;
    current_.character = a * current_.character + b * target_.character;
    current_.outputDb  = a * current_.outputDb  + b * target_.outputDb;
    current_.mix       = a * current_.mix       + b * target_.mix;

    const float ba = bypassSmoothCoeff_;
    current_.bypass = ba * current_.bypass + (1.0f - ba) * target_.bypass;
}

float ApolloOutputModel::processSample(float x, int channel) noexcept
{
    x = sanitizeSample(x);
    if (!prepared_ || channel < 0 || channel >= preparedChannels_ || channel >= kMaxChannels)
        return x;

    syncParametersFromControlThread();
    smoothParameters();
    auto& s = state_[static_cast<std::size_t>(channel)];
    const float control = detectTransient(std::abs(x), s.localDetector);
    return processSampleInternal(x, channel, control);
}

float ApolloOutputModel::processSampleInternal(float x, int channel,
                                               float transientControl) noexcept
{
    x = sanitizeSample(x);
    if (channel < 0 || channel >= preparedChannels_ || channel >= kMaxChannels)
        return x;

    auto& s = state_[static_cast<std::size_t>(channel)];
    const float character = clamp01(current_.character);
    const float dry = x;

    // 1) Programme-dependent transient polish. No fixed EQ/air boost is applied.
    const float polished = polishTransient(x, s, transientControl, character);

    // 2) Intentional user drive into the analogue macromodel.
    const float driven = polished * dbToGain(current_.driveDb);

    // 3) Character controls analogue density even at modest Drive. The stronger
    // response comes from asymmetric low-order saturation, not an exciter shelf.
    const float cCurve = std::pow(character, 0.50f);
    const float drivePush = smoothStep(0.0f, 12.0f, current_.driveDb);
    const float driveCurve = std::pow(drivePush, 1.10f);

    // Character is intentionally audible without needing Drive.  It does not
    // add a static HF shelf: it changes crest shape and low-order asymmetry.
    // The level-dependent term keeps quiet tails cleaner than loud programme.
    const float crestActivity = smoothStep(0.05f, 0.70f, std::abs(driven));
    const float shape = 0.006f
        + 0.015f * cCurve
        + 0.060f * cCurve * crestActivity
        + 0.015f * cCurve * driveCurve;
    const float bias = 0.0005f
        + 0.0020f * cCurve
        + 0.0040f * cCurve * crestActivity
        + 0.0020f * cCurve * driveCurve;
    float y = adaaAsymmetricTanh(driven, s.prevStage1, shape, bias);

    // 4) Character-dependent soft rail. At Character=0 the rail is effectively
    // absent. Around the middle of the knob it starts rounding real musical
    // crests; at 100% it is deliberately obvious but remains smooth/ADAA-based.
    const float cSat = character * character;
    const float crestRail = std::pow(crestActivity, 1.70f);
    const float rail = 10000.0f /
        (1.0f
         + 2500.0f * cSat * crestRail);
    y = adaaRailTanh(y, s.prevStage2, rail);

    // 5) Implementation-only 1 Hz DC blocker.
    const float hp = sanitizeSample(y - s.prevDcIn + dcCoeff_ * s.prevDcOut);
    s.prevDcIn = flushTiny(y);
    s.prevDcOut = flushTiny(hp);

    const float mix = clamp01(current_.mix);
    const float effected = (dry + (hp - dry) * mix) * dbToGain(current_.outputDb);

    const float by = clamp01(current_.bypass);
    return sanitizeSample(effected + (dry - effected) * by);
}

void ApolloOutputModel::process(const float* const* inputs,
                                float* const* outputs,
                                int channels,
                                int samples) noexcept
{
    if (!prepared_ || !inputs || !outputs || samples <= 0)
        return;

    if (channels < 1 || channels > preparedChannels_ || channels > kMaxChannels)
        return;

    syncParametersFromControlThread();

    for (int i = 0; i < samples; ++i)
    {
        // One shared parameter state and detector per frame: channel image remains coherent.
        smoothParameters();

        float linkedLevel = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
        {
            if (inputs[ch])
                linkedLevel = std::max(linkedLevel, std::abs(sanitizeSample(inputs[ch][i])));
        }
        const float transientControl = detectTransient(linkedLevel, linkedDetector_);

        for (int ch = 0; ch < channels; ++ch)
        {
            if (!inputs[ch] || !outputs[ch])
                continue;
            outputs[ch][i] = processSampleInternal(inputs[ch][i], ch, transientControl);
        }
    }
}
} // namespace apollo
