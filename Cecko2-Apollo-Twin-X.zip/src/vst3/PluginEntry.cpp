#include "ApolloController.hpp"
#include "ApolloProcessor.hpp"
#include "PluginIds.hpp"

#include "public.sdk/source/main/pluginfactory_constexpr.h"

#ifndef APOLLO_TWIN_X_MODEL_VERSION
#define APOLLO_TWIN_X_MODEL_VERSION "0.5.1"
#endif

#define stringCompanyName "Cecko Audio"
#define stringCompanyWeb  "https://github.com/gurkov1993cg-debug/Cecko2"
#define stringCompanyEmail ""
#define stringPluginName  "Apollo Twin X Character"

BEGIN_FACTORY_DEF(stringCompanyName, stringCompanyWeb, stringCompanyEmail, 2)

DEF_CLASS(Steinberg::Vst::ApolloProcessorUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          stringPluginName,
          Steinberg::Vst::kDistributable,
          "Fx|Distortion",
          APOLLO_TWIN_X_MODEL_VERSION,
          kVstVersionString,
          Steinberg::Vst::ApolloProcessor::createInstance,
          nullptr)

DEF_CLASS(Steinberg::Vst::ApolloControllerUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstComponentControllerClass,
          stringPluginName " Controller",
          0,
          "",
          APOLLO_TWIN_X_MODEL_VERSION,
          kVstVersionString,
          Steinberg::Vst::ApolloController::createInstance,
          nullptr)

END_FACTORY
