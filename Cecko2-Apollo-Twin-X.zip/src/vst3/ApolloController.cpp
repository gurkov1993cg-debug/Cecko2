#include "ApolloController.hpp"
#include "PluginIds.hpp"

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "public.sdk/source/vst/vstparameters.h"

#include <cstring>

namespace Steinberg::Vst
{
tresult PLUGIN_API ApolloController::initialize(FUnknown* context)
{
    const auto result = EditController::initialize(context);
    if (result != kResultTrue)
        return result;

    parameters.addParameter(new RangeParameter(STR16("Drive"), kDriveId, STR16("dB"),
                                               -12.0, 12.0, 1.0, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Character"), kCharacterId, STR16("%"),
                                               0.0, 100.0, 50.0, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Output"), kOutputId, STR16("dB"),
                                               -12.0, 12.0, -1.0, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(new RangeParameter(STR16("Mix"), kMixId, STR16("%"),
                                               0.0, 100.0, 100.0, 0,
                                               ParameterInfo::kCanAutomate));
    parameters.addParameter(STR16("Bypass"), nullptr, 1, 0.0,
                            ParameterInfo::kCanAutomate | ParameterInfo::kIsBypass, kBypassId);

    // Read-only meter parameters. The audio processor publishes these through
    // ProcessData::outputParameterChanges; VST3Editor routes them back to the
    // GUI so the meter controls animate without any custom polling thread.
    parameters.addParameter(new RangeParameter(STR16("Input L"), kInputMeterLId, STR16("dB"),
                                               -60.0, 0.0, -60.0, 0,
                                               ParameterInfo::kIsReadOnly));
    parameters.addParameter(new RangeParameter(STR16("Input R"), kInputMeterRId, STR16("dB"),
                                               -60.0, 0.0, -60.0, 0,
                                               ParameterInfo::kIsReadOnly));
    parameters.addParameter(new RangeParameter(STR16("Output L"), kOutputMeterLId, STR16("dB"),
                                               -60.0, 0.0, -60.0, 0,
                                               ParameterInfo::kIsReadOnly));
    parameters.addParameter(new RangeParameter(STR16("Output R"), kOutputMeterRId, STR16("dB"),
                                               -60.0, 0.0, -60.0, 0,
                                               ParameterInfo::kIsReadOnly));
    return kResultTrue;
}


IPlugView* PLUGIN_API ApolloController::createView(const char* name)
{
    if (name && std::strcmp(name, ViewType::kEditor) == 0)
        return new VSTGUI::VST3Editor(this, "view", "apollo.uidesc");
    return nullptr;
}

tresult PLUGIN_API ApolloController::setComponentState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    float drive = 1.0f, character = 0.50f, output = -1.0f, mix = 1.0f;
    if (!s.readFloat(drive)) return kResultFalse;
    if (!s.readFloat(character)) return kResultFalse;
    if (!s.readFloat(output)) return kResultFalse;
    if (!s.readFloat(mix)) return kResultFalse;
    int32 bypass = 0;
    s.readInt32(bypass);

    setParamNormalized(kDriveId, (drive + 12.0) / 24.0);
    setParamNormalized(kCharacterId, character);
    setParamNormalized(kOutputId, (output + 12.0) / 24.0);
    setParamNormalized(kMixId, mix);
    setParamNormalized(kBypassId, bypass ? 1.0 : 0.0);
    return kResultOk;
}
}
