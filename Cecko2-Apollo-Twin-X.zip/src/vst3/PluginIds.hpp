#pragma once

#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace Steinberg::Vst
{
enum ParamIds : ParamID
{
    kDriveId = 100,
    kCharacterId = 101,
    kOutputId = 102,
    kMixId = 103,
    kBypassId = 104,

    // Read-only GUI meter parameters. The processor writes normalized values
    // back to the host so the editor can animate in sync with audio.
    kInputMeterLId = 110,
    kInputMeterRId = 111,
    kOutputMeterLId = 112,
    kOutputMeterRId = 113
};

static DECLARE_UID(ApolloProcessorUID, 0x6E4A4C10, 0x7E584F84, 0x9D4F4D57, 0xA9BB7C11);
static DECLARE_UID(ApolloControllerUID, 0x1AC44B67, 0x0D2F4DB1, 0xA8D0D77A, 0xE55429C2);
}
