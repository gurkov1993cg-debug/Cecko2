#include "ApolloProcessor.hpp"
#include "PluginIds.hpp"

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"

#include <algorithm>

namespace Steinberg::Vst
{
ApolloProcessor::ApolloProcessor()
{
    setControllerClass(FUID::fromTUID(ApolloControllerUID));
}

tresult PLUGIN_API ApolloProcessor::initialize(FUnknown* context)
{
    const auto result = AudioEffect::initialize(context);
    if (result == kResultTrue)
    {
        addAudioInput(STR16("Stereo In"), SpeakerArr::kStereo);
        addAudioOutput(STR16("Stereo Out"), SpeakerArr::kStereo);
        numChannels_ = 2;
    }
    return result;
}

tresult PLUGIN_API ApolloProcessor::setBusArrangements(SpeakerArrangement* inputs, int32 numIns,
                                                        SpeakerArrangement* outputs, int32 numOuts)
{
    if (numIns == 1 && numOuts == 1 && inputs[0] == outputs[0] &&
        (inputs[0] == SpeakerArr::kMono || inputs[0] == SpeakerArr::kStereo))
    {
        const auto result = AudioEffect::setBusArrangements(inputs, numIns, outputs, numOuts);
        if (result == kResultOk)
            numChannels_ = SpeakerArr::getChannelCount(outputs[0]);
        return result;
    }
    return kResultFalse;
}

tresult PLUGIN_API ApolloProcessor::setupProcessing(ProcessSetup& setup)
{
    const auto result = AudioEffect::setupProcessing(setup);
    if (result == kResultOk)
    {
        model_.prepare(setup.sampleRate, numChannels_);
        model_.setParameters(params_);
    }
    return result;
}

tresult PLUGIN_API ApolloProcessor::setActive(TBool state)
{
    if (state)
    {
        model_.prepare(processSetup.sampleRate, numChannels_);
        model_.setParameters(params_);
    }
    else
    {
        model_.reset();
    }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API ApolloProcessor::setProcessing(TBool state)
{
    if (state)
        model_.reset();
    return kResultOk;
}

void ApolloProcessor::applyParameter(ParamID id, ParamValue n) noexcept
{
    n = std::max<ParamValue>(0.0, std::min<ParamValue>(1.0, n));
    switch (id)
    {
        case kDriveId:     params_.driveDb = static_cast<float>(-12.0 + 24.0 * n); break;
        case kCharacterId: params_.character = static_cast<float>(n); break;
        case kOutputId:    params_.outputDb = static_cast<float>(-12.0 + 24.0 * n); break;
        case kMixId:       params_.mix = static_cast<float>(n); break;
        case kBypassId:    bypass_ = n >= 0.5; break;
        default: break;
    }
}

void ApolloProcessor::pushParameters() noexcept
{
    model_.setParameters(params_);
}


tresult PLUGIN_API ApolloProcessor::canProcessSampleSize(int32 symbolicSampleSize)
{
    return symbolicSampleSize == kSample32 ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API ApolloProcessor::process(ProcessData& data)
{
    if (data.inputParameterChanges)
    {
        const int32 changed = data.inputParameterChanges->getParameterCount();
        for (int32 i = 0; i < changed; ++i)
        {
            if (auto* q = data.inputParameterChanges->getParameterData(i))
            {
                const int32 points = q->getPointCount();
                if (points <= 0)
                    continue;
                int32 offset = 0;
                ParamValue value = 0.0;
                if (q->getPoint(points - 1, offset, value) == kResultTrue)
                    applyParameter(q->getParameterId(), value);
            }
        }
        pushParameters();
    }

    if (data.numSamples <= 0 || data.numInputs < 1 || data.numOutputs < 1)
        return kResultTrue;

    if (data.symbolicSampleSize != kSample32)
        return kResultFalse;

    const int32 channels = std::min<int32>(numChannels_, data.inputs[0].numChannels);
    if (channels <= 0)
        return kResultTrue;

    const float* in[8]{};
    float* out[8]{};
    const int32 n = std::min<int32>(channels, 8);
    for (int32 ch = 0; ch < n; ++ch)
    {
        in[ch] = data.inputs[0].channelBuffers32[ch];
        out[ch] = data.outputs[0].channelBuffers32[ch];
    }

    if (bypass_)
    {
        for (int32 ch = 0; ch < n; ++ch)
        {
            if (!in[ch] || !out[ch])
                continue;
            if (in[ch] != out[ch])
                std::copy_n(in[ch], data.numSamples, out[ch]);
        }
    }
    else
    {
        model_.process(in, out, n, data.numSamples);
    }
    return kResultTrue;
}

tresult PLUGIN_API ApolloProcessor::setState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    if (!s.readFloat(params_.driveDb)) return kResultFalse;
    if (!s.readFloat(params_.character)) return kResultFalse;
    if (!s.readFloat(params_.outputDb)) return kResultFalse;
    if (!s.readFloat(params_.mix)) return kResultFalse;
    int32 savedBypass = 0;
    if (s.readInt32(savedBypass))
        bypass_ = savedBypass != 0;
    pushParameters();
    return kResultOk;
}

tresult PLUGIN_API ApolloProcessor::getState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    s.writeFloat(params_.driveDb);
    s.writeFloat(params_.character);
    s.writeFloat(params_.outputDb);
    s.writeFloat(params_.mix);
    s.writeInt32(bypass_ ? 1 : 0);
    return kResultOk;
}
}
