#include "ApolloProcessor.hpp"
#include "PluginIds.hpp"

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"

#include <algorithm>
#include <cmath>

namespace Steinberg::Vst
{
ApolloProcessor::ApolloProcessor()
{
    setControllerClass(FUID::fromTUID(ApolloControllerUID));
}

tresult PLUGIN_API ApolloProcessor::initialize(FUnknown* context)
{
    const auto result = AudioEffect::initialize(context);
    if (result == kResultTrue)
    {
        addAudioInput(STR16("Stereo In"), SpeakerArr::kStereo);
        addAudioOutput(STR16("Stereo Out"), SpeakerArr::kStereo);
        numChannels_ = 2;
    }
    return result;
}

tresult PLUGIN_API ApolloProcessor::setBusArrangements(SpeakerArrangement* inputs, int32 numIns,
                                                        SpeakerArrangement* outputs, int32 numOuts)
{
    if (numIns == 1 && numOuts == 1 && inputs[0] == outputs[0] &&
        (inputs[0] == SpeakerArr::kMono || inputs[0] == SpeakerArr::kStereo))
    {
        const auto result = AudioEffect::setBusArrangements(inputs, numIns, outputs, numOuts);
        if (result == kResultOk)
            numChannels_ = SpeakerArr::getChannelCount(outputs[0]);
        return result;
    }
    return kResultFalse;
}

tresult PLUGIN_API ApolloProcessor::setupProcessing(ProcessSetup& setup)
{
    const auto result = AudioEffect::setupProcessing(setup);
    if (result == kResultOk)
    {
        model_.prepare(setup.sampleRate, numChannels_);
        model_.setParameters(params_);
    }
    return result;
}

tresult PLUGIN_API ApolloProcessor::setActive(TBool state)
{
    if (state)
    {
        model_.prepare(processSetup.sampleRate, numChannels_);
        model_.setParameters(params_);
    }
    else
    {
        model_.reset();
    }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API ApolloProcessor::setProcessing(TBool state)
{
    if (state)
        model_.reset();
    return AudioEffect::setProcessing(state);
}

void ApolloProcessor::applyParameter(ParamID id, ParamValue n) noexcept
{
    n = std::max<ParamValue>(0.0, std::min<ParamValue>(1.0, n));
    switch (id)
    {
        case kDriveId:     params_.driveDb = static_cast<float>(-12.0 + 24.0 * n); break;
        case kCharacterId: params_.character = static_cast<float>(n); break;
        case kOutputId:    params_.outputDb = static_cast<float>(-12.0 + 24.0 * n); break;
        case kMixId:       params_.mix = static_cast<float>(n); break;
        case kBypassId:
            bypass_ = n >= 0.5;
            params_.bypass = bypass_ ? 1.0f : 0.0f;
            break;
        default: break;
    }
}

void ApolloProcessor::pushParameters() noexcept
{
    model_.setParameters(params_);
}



ParamValue ApolloProcessor::peakToMeter(float peak) noexcept
{
    // 0 = -60 dBFS or below, 1 = 0 dBFS. This is deliberately a display
    // mapping only; it does not touch the audio path.
    const float p = std::max(peak, 1.0e-6f);
    const float db = 20.0f * std::log10(p);
    return std::max<ParamValue>(0.0, std::min<ParamValue>(1.0, (db + 60.0f) / 60.0f));
}

void ApolloProcessor::publishMeters(ProcessData& data, float inL, float inR,
                                    float outL, float outR) noexcept
{
    if (!data.outputParameterChanges)
        return;

    const ParamID ids[4] {kInputMeterLId, kInputMeterRId, kOutputMeterLId, kOutputMeterRId};
    const ParamValue values[4] {peakToMeter(inL), peakToMeter(inR),
                                peakToMeter(outL), peakToMeter(outR)};

    for (int i = 0; i < 4; ++i)
    {
        // Avoid filling the host queue with identical values, but keep enough
        // resolution for a smooth meter.
        if (lastMeter_[i] >= 0.0 && std::abs(values[i] - lastMeter_[i]) < 0.001)
            continue;
        int32 queueIndex = 0;
        if (auto* queue = data.outputParameterChanges->addParameterData(ids[i], queueIndex))
        {
            int32 pointIndex = 0;
            queue->addPoint(0, values[i], pointIndex);
            lastMeter_[i] = values[i];
        }
    }
}

tresult PLUGIN_API ApolloProcessor::canProcessSampleSize(int32 symbolicSampleSize)
{
    return symbolicSampleSize == kSample32 ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API ApolloProcessor::process(ProcessData& data)
{
    if (data.inputParameterChanges)
    {
        const int32 changed = data.inputParameterChanges->getParameterCount();
        for (int32 i = 0; i < changed; ++i)
        {
            if (auto* q = data.inputParameterChanges->getParameterData(i))
            {
                const int32 points = q->getPointCount();
                if (points <= 0)
                    continue;
                int32 offset = 0;
                ParamValue value = 0.0;
                if (q->getPoint(points - 1, offset, value) == kResultTrue)
                    applyParameter(q->getParameterId(), value);
            }
        }
        pushParameters();
    }

    if (data.numSamples <= 0 || data.numInputs < 1 || data.numOutputs < 1)
        return kResultTrue;

    if (data.symbolicSampleSize != kSample32)
        return kResultFalse;

    const int32 channels = std::min<int32>(numChannels_,
        std::min<int32>(data.inputs[0].numChannels, data.outputs[0].numChannels));
    if (channels <= 0)
        return kResultTrue;

    const float* in[8]{};
    float* out[8]{};
    const int32 n = std::min<int32>(channels, 8);
    for (int32 ch = 0; ch < n; ++ch)
    {
        in[ch] = data.inputs[0].channelBuffers32[ch];
        out[ch] = data.outputs[0].channelBuffers32[ch];
    }

    float inPeakL = 0.0f, inPeakR = 0.0f;
    if (n > 0 && in[0])
        for (int32 i = 0; i < data.numSamples; ++i) inPeakL = std::max(inPeakL, std::abs(in[0][i]));
    if (n > 1 && in[1])
        for (int32 i = 0; i < data.numSamples; ++i) inPeakR = std::max(inPeakR, std::abs(in[1][i]));
    else
        inPeakR = inPeakL;

    // Always run the model: bypass is a short, click-free crossfade inside DSP.
    model_.process(in, out, n, data.numSamples);

    float outPeakL = 0.0f, outPeakR = 0.0f;
    if (n > 0 && out[0])
        for (int32 i = 0; i < data.numSamples; ++i) outPeakL = std::max(outPeakL, std::abs(out[0][i]));
    if (n > 1 && out[1])
        for (int32 i = 0; i < data.numSamples; ++i) outPeakR = std::max(outPeakR, std::abs(out[1][i]));
    else
        outPeakR = outPeakL;

    publishMeters(data, inPeakL, inPeakR, outPeakL, outPeakR);
    return kResultTrue;
}

tresult PLUGIN_API ApolloProcessor::setState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    if (!s.readFloat(params_.driveDb)) return kResultFalse;
    if (!s.readFloat(params_.character)) return kResultFalse;
    if (!s.readFloat(params_.outputDb)) return kResultFalse;
    if (!s.readFloat(params_.mix)) return kResultFalse;
    int32 savedBypass = 0;
    if (s.readInt32(savedBypass))
        bypass_ = savedBypass != 0;
    params_.bypass = bypass_ ? 1.0f : 0.0f;
    pushParameters();
    return kResultOk;
}

tresult PLUGIN_API ApolloProcessor::getState(IBStream* state)
{
    if (!state)
        return kResultFalse;

    IBStreamer s(state, kLittleEndian);
    s.writeFloat(params_.driveDb);
    s.writeFloat(params_.character);
    s.writeFloat(params_.outputDb);
    s.writeFloat(params_.mix);
    s.writeInt32(bypass_ ? 1 : 0);
    return kResultOk;
}
}
