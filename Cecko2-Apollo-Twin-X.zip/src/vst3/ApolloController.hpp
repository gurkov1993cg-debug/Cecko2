#pragma once

#include "public.sdk/source/vst/vsteditcontroller.h"

namespace Steinberg::Vst
{
class ApolloController final : public EditController
{
public:
    static FUnknown* createInstance(void*) { return static_cast<IEditController*>(new ApolloController()); }

    tresult PLUGIN_API initialize(FUnknown* context) SMTG_OVERRIDE;
    tresult PLUGIN_API setComponentState(IBStream* state) SMTG_OVERRIDE;
};
}
