#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace apollo
{
static_assert(std::atomic<float>::is_always_lock_free,
              "ApolloOutputModel requires lock-free atomic<float> for real-time parameter updates");
static_assert(std::atomic<std::uint32_t>::is_always_lock_free,
              "ApolloOutputModel requires lock-free atomic<uint32_t> for real-time parameter updates");

struct Parameters
{
    float driveDb = 0.5f;
    float character = 0.45f; // 0..1, transient polish + analogue density
    float outputDb = -0.5f;
    float mix = 1.0f;        // 0..1
    float bypass = 0.0f;     // 0 = active, 1 = true dry; internally smoothed
};

class ApolloOutputModel final
{
public:
    static constexpr int kMaxChannels = 8;
    static constexpr int kDefaultChannels = 2;
    static constexpr float kMinDriveDb = -12.0f;
    static constexpr float kMaxDriveDb = 12.0f;
    static constexpr float kMinOutputDb = -12.0f;
    static constexpr float kMaxOutputDb = 12.0f;

    ApolloOutputModel() noexcept = default;
    ~ApolloOutputModel() = default;

    ApolloOutputModel(const ApolloOutputModel&) = delete;
    ApolloOutputModel& operator=(const ApolloOutputModel&) = delete;
    ApolloOutputModel(ApolloOutputModel&&) = delete;
    ApolloOutputModel& operator=(ApolloOutputModel&&) = delete;

    // prepare()/reset() must not run concurrently with process().
    // Returns false for an invalid sample rate or channel count.
    bool prepare(double sampleRate, int channels = kDefaultChannels) noexcept;
    void reset() noexcept;

    // Safe to call from a control/UI thread while process() is running.
    void setParameters(const Parameters& p) noexcept;

    void process(const float* const* inputs,
                 float* const* outputs,
                 int channels,
                 int samples) noexcept;

    // Convenience path for tests/mono processing. Multi-channel process() uses
    // one linked transient detector to preserve the image.
    float processSample(float x, int channel) noexcept;

private:
    struct DetectorState
    {
        float fastEnv = 0.0f;
        float slowEnv = 0.0f;
        float transientControl = 0.0f;
    };

    struct ChannelState
    {
        // Exact-reconstruction three-band transient split:
        // low = presenceLp, presence = airLp-presenceLp, air = x-airLp.
        float presenceLp = 0.0f;
        float airLp = 0.0f;

        // ADAA histories for the two analogue nonlinear stages.
        float prevStage1 = 0.0f;
        float prevStage2 = 0.0f;

        // Implementation-only DC protection after the asymmetric stage.
        float prevDcIn = 0.0f;
        float prevDcOut = 0.0f;

        // Used only by processSample(). Bulk processing uses linkedDetector_.
        DetectorState localDetector{};
    };

    // Cross-thread parameter transport. Each member is atomic so no UI/audio
    // data race exists. sequence makes a complete setParameters() update appear
    // as one coherent snapshot to the audio thread without locks.
    struct AtomicParameters
    {
        std::atomic<std::uint32_t> sequence {0};
        std::atomic<float> driveDb {0.5f};
        std::atomic<float> character {0.45f};
        std::atomic<float> outputDb {-0.5f};
        std::atomic<float> mix {1.0f};
        std::atomic<float> bypass {0.0f};
    };

    static float dbToGain(float db) noexcept;
    static float clamp01(float x) noexcept;
    static float smoothStep(float edge0, float edge1, float x) noexcept;
    static float flushTiny(float x) noexcept;
    static float sanitizeSample(float x) noexcept;
    static double logCoshD(double x) noexcept;
    static float adaaAsymmetricTanh(float x, float& previous,
                                    float shape, float bias) noexcept;
    static float adaaRailTanh(float x, float& previous, float rail) noexcept;

    void syncParametersFromControlThread() noexcept;
    void smoothParameters() noexcept;
    float detectTransient(float level, DetectorState& detector) noexcept;
    float polishTransient(float x, ChannelState& s,
                          float transientControl, float character) noexcept;
    float processSampleInternal(float x, int channel,
                                float transientControl) noexcept;

    double sampleRate_ = 44100.0;
    int preparedChannels_ = kDefaultChannels;
    bool prepared_ = false;

    float smoothCoeff_ = 0.0f;
    float bypassSmoothCoeff_ = 0.0f;
    float dcCoeff_ = 0.0f;

    float fastAttackCoeff_ = 0.0f;
    float fastReleaseCoeff_ = 0.0f;
    float slowAttackCoeff_ = 0.0f;
    float slowReleaseCoeff_ = 0.0f;
    float transientAttackCoeff_ = 0.0f;
    float transientReleaseCoeff_ = 0.0f;
    float presenceSplitCoeff_ = 0.0f;
    float airSplitCoeff_ = 0.0f;

    alignas(64) AtomicParameters pendingParameters_{};

    // Audio-thread owned copies.
    Parameters target_{};
    Parameters current_{};
    DetectorState linkedDetector_{};
    std::array<ChannelState, kMaxChannels> state_{};
};
} // namespace apollo
