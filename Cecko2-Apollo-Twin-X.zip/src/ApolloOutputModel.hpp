#pragma once

#include <array>

namespace apollo
{
struct Parameters
{
    float driveDb = 1.0f;
    float character = 0.50f; // 0..1, includes transient polish intensity
    float outputDb = -1.0f;
    float mix = 1.0f;        // 0..1
};

class ApolloOutputModel
{
public:
    void prepare(double sampleRate, int channels = 2);
    void reset();
    void setParameters(const Parameters& p) noexcept { target_ = p; }

    void process(const float* const* inputs,
                 float* const* outputs,
                 int channels,
                 int samples) noexcept;

    float processSample(float x, int channel) noexcept;

private:
    struct ChannelState
    {
        float prevStage1 = 0.0f;
        float prevDcIn = 0.0f;
        float prevDcOut = 0.0f;

        // Transient-polish states. These act only when a fast envelope rises
        // above the slower program envelope; sustained material stays open.
        float fastEnv = 0.0f;
        float slowEnv = 0.0f;
        float hfSplitLp = 0.0f;
        float transientControl = 0.0f;
    };

    static float dbToGain(float db) noexcept;
    static float logCosh(float x) noexcept;
    static float adaaTanh(float x, float& previous, float amount) noexcept;
    static float asymmetricDriver(float x, float character) noexcept;
    static float softRail(float x, float rail) noexcept;
    static float clamp01(float x) noexcept;
    static float smoothStep(float edge0, float edge1, float x) noexcept;

    void smoothParameters() noexcept;
    float polishTransient(float x, ChannelState& s, float character) noexcept;
    float processSampleInternal(float x, int channel) noexcept;

    double sampleRate_ = 44100.0;
    float smoothCoeff_ = 0.0f;
    float dcCoeff_ = 0.0f;

    // Envelope/spectral-split coefficients for transient-aware analogue polish.
    float fastAttackCoeff_ = 0.0f;
    float fastReleaseCoeff_ = 0.0f;
    float slowAttackCoeff_ = 0.0f;
    float slowReleaseCoeff_ = 0.0f;
    float transientControlCoeff_ = 0.0f;
    float transientReleaseCoeff_ = 0.0f;
    float hfSplitCoeff_ = 0.0f;

    Parameters target_{};
    Parameters current_{};
    std::array<ChannelState, 8> state_{};
};
} // namespace apollo
