#pragma once

#include <array>

namespace apollo
{
struct Parameters
{
    float driveDb = 1.5f;
    float character = 0.35f; // 0..1
    float outputDb = -1.5f;
    float mix = 1.0f;        // 0..1
};

class ApolloOutputModel
{
public:
    void prepare(double sampleRate, int channels = 2);
    void reset();
    void setParameters(const Parameters& p) noexcept { target_ = p; }

    void process(const float* const* inputs,
                 float* const* outputs,
                 int channels,
                 int samples) noexcept;

    float processSample(float x, int channel) noexcept;

private:
    struct ChannelState
    {
        float prevStage1 = 0.0f;
        float prevDcIn = 0.0f;
        float prevDcOut = 0.0f;
    };

    static float dbToGain(float db) noexcept;
    static float logCosh(float x) noexcept;
    static float adaaTanh(float x, float& previous, float amount) noexcept;
    static float asymmetricDriver(float x, float character) noexcept;
    static float softRail(float x, float rail) noexcept;
    static float clamp01(float x) noexcept;

    void smoothParameters() noexcept;
    float processSampleInternal(float x, int channel) noexcept;

    double sampleRate_ = 44100.0;
    float smoothCoeff_ = 0.0f;
    float dcCoeff_ = 0.0f;
    Parameters target_{};
    Parameters current_{};
    std::array<ChannelState, 8> state_{};
};
} // namespace apollo
