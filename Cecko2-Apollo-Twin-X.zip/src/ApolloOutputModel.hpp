#pragma once

#include <array>

namespace apollo
{
struct Parameters
{
    float driveDb = 0.5f;
    float character = 0.45f; // 0..1, transient polish + analogue density
    float outputDb = -0.5f;
    float mix = 1.0f;        // 0..1
    float bypass = 0.0f;     // 0 = active, 1 = true dry; internally smoothed
};

class ApolloOutputModel
{
public:
    void prepare(double sampleRate, int channels = 2);
    void reset();
    void setParameters(const Parameters& p) noexcept;

    void process(const float* const* inputs,
                 float* const* outputs,
                 int channels,
                 int samples) noexcept;

    // Convenience path for tests/mono processing. Multi-channel process() uses
    // a stereo-linked transient detector to preserve the image.
    float processSample(float x, int channel) noexcept;

private:
    struct DetectorState
    {
        float fastEnv = 0.0f;
        float slowEnv = 0.0f;
        float transientControl = 0.0f;
    };

    struct ChannelState
    {
        // Exact-reconstruction three-band transient split:
        // low = presenceLp, presence = airLp-presenceLp, air = x-airLp.
        float presenceLp = 0.0f;
        float airLp = 0.0f;

        // ADAA histories for the two analogue nonlinear stages.
        float prevStage1 = 0.0f;
        float prevStage2 = 0.0f;

        // Implementation-only DC protection after the asymmetric stage.
        float prevDcIn = 0.0f;
        float prevDcOut = 0.0f;

        // Used only by processSample(). Bulk stereo processing uses linkedDetector_.
        DetectorState localDetector{};
    };

    static float dbToGain(float db) noexcept;
    static float clamp01(float x) noexcept;
    static float smoothStep(float edge0, float edge1, float x) noexcept;
    static double logCoshD(double x) noexcept;
    static float adaaAsymmetricTanh(float x, float& previous,
                                    float shape, float bias) noexcept;
    static float adaaRailTanh(float x, float& previous, float rail) noexcept;

    void smoothParameters() noexcept;
    float detectTransient(float level, DetectorState& detector) noexcept;
    float polishTransient(float x, ChannelState& s,
                          float transientControl, float character) noexcept;
    float processSampleInternal(float x, int channel,
                                float transientControl) noexcept;

    double sampleRate_ = 44100.0;
    float smoothCoeff_ = 0.0f;
    float bypassSmoothCoeff_ = 0.0f;
    float dcCoeff_ = 0.0f;

    float fastAttackCoeff_ = 0.0f;
    float fastReleaseCoeff_ = 0.0f;
    float slowAttackCoeff_ = 0.0f;
    float slowReleaseCoeff_ = 0.0f;
    float transientAttackCoeff_ = 0.0f;
    float transientReleaseCoeff_ = 0.0f;
    float presenceSplitCoeff_ = 0.0f;
    float airSplitCoeff_ = 0.0f;

    Parameters target_{};
    Parameters current_{};
    DetectorState linkedDetector_{};
    std::array<ChannelState, 8> state_{};
};
} // namespace apollo
