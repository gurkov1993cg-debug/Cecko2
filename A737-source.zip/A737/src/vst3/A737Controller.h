#pragma once
#include "public.sdk/source/vst/vsteditcontroller.h"

namespace a737 { namespace vst3 {
class A737EditorView;

class A737Controller final : public Steinberg::Vst::EditControllerEx1 {
public:
    static Steinberg::FUnknown* createInstance(void*) { return static_cast<Steinberg::Vst::IEditController*>(new A737Controller()); }
    Steinberg::tresult PLUGIN_API initialize(Steinberg::FUnknown* context) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setComponentState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setParamNormalized(Steinberg::Vst::ParamID tag, Steinberg::Vst::ParamValue value) SMTG_OVERRIDE;
    Steinberg::IPlugView* PLUGIN_API createView(Steinberg::FIDString name) SMTG_OVERRIDE;

    // Native GUI -> controller bridge. These keep all host automation gestures
    // inside the Steinberg controller contract; the Cocoa view never talks to DSP directly.
    void guiBeginEdit(Steinberg::Vst::ParamID tag);
    void guiPerformEdit(Steinberg::Vst::ParamID tag, Steinberg::Vst::ParamValue value);
    void guiEndEdit(Steinberg::Vst::ParamID tag);
    Steinberg::Vst::ParamValue guiValue(Steinberg::Vst::ParamID tag) const;

    void setEditorView(A737EditorView* view) noexcept { editorView_ = view; }

private:
    A737EditorView* editorView_ = nullptr; // non-owning; view clears on destruction
};
}} // namespace a737::vst3
