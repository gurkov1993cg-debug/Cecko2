#pragma once

#include "public.sdk/source/vst/vstaudioeffect.h"
#include "A737Parameters.h"
#include "../dsp/A737Channel.h"
#include <array>

namespace a737 { namespace vst3 {

class A737Processor final : public Steinberg::Vst::AudioEffect {
public:
    A737Processor();
    static Steinberg::FUnknown* createInstance(void*) { return static_cast<Steinberg::Vst::IAudioProcessor*>(new A737Processor()); }

    Steinberg::tresult PLUGIN_API initialize(Steinberg::FUnknown* context) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setupProcessing(Steinberg::Vst::ProcessSetup& setup) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setActive(Steinberg::TBool state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API canProcessSampleSize(Steinberg::int32 symbolicSampleSize) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API process(Steinberg::Vst::ProcessData& data) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API getState(Steinberg::IBStream* state) SMTG_OVERRIDE;
private:
    void readParameterChanges(Steinberg::Vst::IParameterChanges* changes) noexcept;
    void applyControls() noexcept;
    a737::dsp::A737Controls makeControls() const noexcept;
    void pushMeters(Steinberg::Vst::ProcessData& data, double outPeak, double grDb) noexcept;

    std::array<double, kParameterCount> params_{};
    a737::dsp::A737Channel left_;
    a737::dsp::A737Channel right_;
    double vuState_ = 0.0;
    double grState_ = 0.0;
};

}} // namespace a737::vst3
