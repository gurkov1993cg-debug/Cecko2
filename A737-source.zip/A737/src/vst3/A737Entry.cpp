#include "A737Processor.h"
#include "A737Controller.h"
#include "A737Ids.h"
#include "public.sdk/source/main/pluginfactory.h"

using namespace Steinberg;
using namespace Steinberg::Vst;

#define A737_VERSION "0.3.0"
#define A737_NAME "A737"

BEGIN_FACTORY_DEF("Vetra Audio", "", "")
DEF_CLASS2(INLINE_UID_FROM_FUID(a737::vst3::kProcessorUID),
           PClassInfo::kManyInstances,
           kVstAudioEffectClass,
           A737_NAME,
           Vst::kDistributable,
           "Fx|Dynamics|EQ",
           A737_VERSION,
           kVstVersionString,
           a737::vst3::A737Processor::createInstance)
DEF_CLASS2(INLINE_UID_FROM_FUID(a737::vst3::kControllerUID),
           PClassInfo::kManyInstances,
           kVstComponentControllerClass,
           A737_NAME " Controller",
           0,
           "",
           A737_VERSION,
           kVstVersionString,
           a737::vst3::A737Controller::createInstance)
END_FACTORY
