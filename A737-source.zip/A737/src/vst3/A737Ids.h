#pragma once
#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace a737 { namespace vst3 {
// Stable A737 class IDs. Do not change after presets/projects are in use.
static const Steinberg::FUID kProcessorUID(0xA7372026, 0x09110001, 0xC7A34D91, 0x2A8137F1);
static const Steinberg::FUID kControllerUID(0xA7372026, 0x09110002, 0x91B54F20, 0x7C1137E2);
}} // namespace a737::vst3
