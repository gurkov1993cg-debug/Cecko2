#include "A737Processor.h"
#include "A737Ids.h"
#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include <algorithm>
#include <cmath>
#include "pluginterfaces/vst/vstspeaker.h"

using namespace Steinberg;

namespace a737 { namespace vst3 {

A737Processor::A737Processor() : left_(44100.0), right_(44100.0) {
    setControllerClass(kControllerUID);
    params_.fill(0.0);
    params_[kInputMode] = 1.0; // Line
    params_[kPreampGain] = 0.5;
    params_[kThreshold] = 0.5;
    params_[kCompression] = 0.5;
    params_[kBassFrequency] = 1.0/3.0;
    params_[kBassGain] = 0.5;
    params_[kLowMidFrequency] = 0.5;
    params_[kLowMidGain] = 0.5;
    params_[kHighMidFrequency] = 0.5;
    params_[kHighMidGain] = 0.5;
    params_[kTrebleFrequency] = 1.0/3.0;
    params_[kTrebleGain] = 0.5;
    params_[kOutput] = 0.5;
}

tresult PLUGIN_API A737Processor::initialize(FUnknown* context) {
    tresult r = AudioEffect::initialize(context);
    if (r != kResultOk) return r;
    addAudioInput(STR16("Stereo In"), Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Stereo Out"), Vst::SpeakerArr::kStereo);
    return kResultOk;
}

tresult PLUGIN_API A737Processor::setupProcessing(Vst::ProcessSetup& setup) {
    left_.setSampleRate(setup.sampleRate);
    right_.setSampleRate(setup.sampleRate);
    return AudioEffect::setupProcessing(setup);
}

tresult PLUGIN_API A737Processor::setActive(TBool state) {
    if (state) { left_.reset(); right_.reset(); vuState_ = 0.0; grState_ = 0.0; }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API A737Processor::canProcessSampleSize(int32 symbolicSampleSize) {
    return (symbolicSampleSize == Vst::kSample32 || symbolicSampleSize == Vst::kSample64) ? kResultTrue : kResultFalse;
}

void A737Processor::readParameterChanges(Vst::IParameterChanges* changes) noexcept {
    if (!changes) return;
    const int32 n = changes->getParameterCount();
    for (int32 i=0; i<n; ++i) {
        Vst::IParamValueQueue* q = changes->getParameterData(i);
        if (!q) continue;
        const Vst::ParamID id = q->getParameterId();
        if (id >= kParameterCount || q->getPointCount() <= 0) continue;
        int32 sampleOffset = 0;
        Vst::ParamValue value = 0.0;
        if (q->getPoint(q->getPointCount()-1, sampleOffset, value) == kResultTrue)
            params_[id] = value;
    }
}

a737::dsp::A737Controls A737Processor::makeControls() const noexcept {
    using namespace a737::dsp;
    A737Controls c;
    c.bypass = params_[kBypass] >= 0.5;
    const int im = static_cast<int>(params_[kInputMode] * 2.0 + 0.5);
    c.inputMode = im <= 0 ? InputMode::Mic : (im == 1 ? InputMode::Instrument : InputMode::Line);
    c.preampGain01 = params_[kPreampGain];
    c.highGain = params_[kHighGain] >= 0.5;
    c.phaseReverse = params_[kPhase] >= 0.5;
    c.highPassEnabled = params_[kHPFOn] >= 0.5;
    c.highPassFrequency01 = params_[kHPFFrequency];
    c.eqBeforeCompressor = params_[kEQBeforeComp] >= 0.5;
    c.compressor.enabled = params_[kCompressorOn] >= 0.5;
    c.compressor.threshold01 = params_[kThreshold];
    c.compressor.compression01 = params_[kCompression];
    c.compressor.attack01 = params_[kAttack];
    c.compressor.release01 = params_[kRelease];
    c.eq.enabled = params_[kEQOn] >= 0.5;
    c.eq.sidechainMids = params_[kSCMids] >= 0.5;
    c.eq.bassFrequencyIndex = static_cast<int>(params_[kBassFrequency] * 3.0 + 0.5);
    c.eq.bassGain01 = params_[kBassGain];
    c.eq.lowMidFrequency01 = params_[kLowMidFrequency];
    c.eq.lowMidX10 = params_[kLowMidX10] >= 0.5;
    c.eq.lowMidHighQ = params_[kLowMidQ] >= 0.5;
    c.eq.lowMidGain01 = params_[kLowMidGain];
    c.eq.highMidFrequency01 = params_[kHighMidFrequency];
    c.eq.highMidX10 = params_[kHighMidX10] >= 0.5;
    c.eq.highMidHighQ = params_[kHighMidQ] >= 0.5;
    c.eq.highMidGain01 = params_[kHighMidGain];
    c.eq.trebleFrequencyIndex = static_cast<int>(params_[kTrebleFrequency] * 3.0 + 0.5);
    c.eq.trebleGain01 = params_[kTrebleGain];
    c.output01 = params_[kOutput];
    return c;
}

void A737Processor::applyControls() noexcept {
    const a737::dsp::A737Controls c = makeControls();
    left_.setControls(c); right_.setControls(c);
}

void A737Processor::pushMeters(Vst::ProcessData& data, double outPeak, double grDb) noexcept {
    // Metering is UI-only and does not alter the audio path.
    // ASSUMPTION: 300 ms VU-style smoothing and 120 ms GR display smoothing.
    const double blockSeconds = processSetup.sampleRate > 1.0 ? static_cast<double>(data.numSamples) / processSetup.sampleRate : 0.0;
    const double vuA = std::exp(-blockSeconds / 0.300);
    const double grA = std::exp(-blockSeconds / 0.120);
    vuState_ = outPeak + (vuState_ - outPeak) * vuA;
    grState_ = grDb + (grState_ - grDb) * grA;

    // Output meter normalized for a -30..+3 dBFS-ish display range.
    const double db = 20.0 * std::log10(std::max(vuState_, 1.0e-12));
    const double outNorm = std::max(0.0, std::min(1.0, (db + 30.0) / 33.0));
    // GR meter: 0..20 dB maps to 0..1.
    const double grNorm = std::max(0.0, std::min(1.0, grState_ / 20.0));

    if (!data.outputParameterChanges || data.numSamples <= 0) return;
    int32 queueIndex = 0;
    Vst::IParamValueQueue* qOut = data.outputParameterChanges->addParameterData(kMeterOut, queueIndex);
    int32 pointIndex = 0;
    if (qOut) qOut->addPoint(data.numSamples - 1, outNorm, pointIndex);
    queueIndex = 0; pointIndex = 0;
    Vst::IParamValueQueue* qGR = data.outputParameterChanges->addParameterData(kMeterGR, queueIndex);
    if (qGR) qGR->addPoint(data.numSamples - 1, grNorm, pointIndex);
}

tresult PLUGIN_API A737Processor::process(Vst::ProcessData& data) {
    readParameterChanges(data.inputParameterChanges);
    applyControls();
    if (data.numInputs == 0 || data.numOutputs == 0 || data.numSamples <= 0) return kResultOk;
    const int32 channels = std::min(data.inputs[0].numChannels, data.outputs[0].numChannels);
    double peak = 0.0;
    if (processSetup.symbolicSampleSize == Vst::kSample64) {
        for (int32 c=0; c<channels; ++c) {
            Vst::Sample64* in = data.inputs[0].channelBuffers64[c];
            Vst::Sample64* out = data.outputs[0].channelBuffers64[c];
            a737::dsp::A737Channel& ch = (c == 0 ? left_ : right_);
            for (int32 i=0; i<data.numSamples; ++i) {
                out[i] = ch.processSample(in[i]);
                peak = std::max(peak, std::abs(static_cast<double>(out[i])));
            }
        }
    } else {
        for (int32 c=0; c<channels; ++c) {
            Vst::Sample32* in = data.inputs[0].channelBuffers32[c];
            Vst::Sample32* out = data.outputs[0].channelBuffers32[c];
            a737::dsp::A737Channel& ch = (c == 0 ? left_ : right_);
            for (int32 i=0; i<data.numSamples; ++i) {
                out[i] = static_cast<Vst::Sample32>(ch.processSample(in[i]));
                peak = std::max(peak, std::abs(static_cast<double>(out[i])));
            }
        }
    }
    const double gr = std::max(left_.gainReductionDb(), right_.gainReductionDb());
    pushMeters(data, peak, gr);
    return kResultOk;
}

tresult PLUGIN_API A737Processor::setState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    for (int i=0;i<kParameterCount;++i) {
        double v=0.0; if (!s.readDouble(v)) return kResultFalse; params_[i]=v;
    }
    applyControls();
    return kResultOk;
}

tresult PLUGIN_API A737Processor::getState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    for (int i=0;i<kParameterCount;++i) if (!s.writeDouble(params_[i])) return kResultFalse;
    return kResultOk;
}

}} // namespace a737::vst3
