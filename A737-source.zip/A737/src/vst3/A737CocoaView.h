#pragma once

#if defined(__APPLE__)
#include "public.sdk/source/common/pluginview.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace a737 { namespace vst3 {
class A737Controller;

class A737EditorView final : public Steinberg::CPluginView {
public:
    explicit A737EditorView(A737Controller* controller);
    ~A737EditorView() SMTG_OVERRIDE;

    Steinberg::tresult PLUGIN_API isPlatformTypeSupported(Steinberg::FIDString type) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API attached(void* parent, Steinberg::FIDString type) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API removed() SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API onSize(Steinberg::ViewRect* newSize) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API getSize(Steinberg::ViewRect* size) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API canResize() SMTG_OVERRIDE { return Steinberg::kResultFalse; }
    Steinberg::tresult PLUGIN_API checkSizeConstraint(Steinberg::ViewRect* rect) SMTG_OVERRIDE;

    void parameterChanged(Steinberg::Vst::ParamID tag, Steinberg::Vst::ParamValue value) noexcept;

private:
    A737Controller* controller_ = nullptr;
    void* nativeView_ = nullptr;
};
}} // namespace a737::vst3
#endif
