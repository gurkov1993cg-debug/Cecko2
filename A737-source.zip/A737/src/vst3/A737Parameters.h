#pragma once
#include "pluginterfaces/vst/vsttypes.h"

namespace a737 { namespace vst3 {

enum ParameterIds : Steinberg::Vst::ParamID {
    kBypass = 0,
    kInputMode,
    kPreampGain,
    kHighGain,
    kPhase,
    kHPFOn,
    kHPFFrequency,
    kCompressorOn,
    kThreshold,
    kCompression,
    kAttack,
    kRelease,
    kEQOn,
    kEQBeforeComp,
    kSCMids,
    kBassFrequency,
    kBassGain,
    kLowMidFrequency,
    kLowMidX10,
    kLowMidQ,
    kLowMidGain,
    kHighMidFrequency,
    kHighMidX10,
    kHighMidQ,
    kHighMidGain,
    kTrebleFrequency,
    kTrebleGain,
    kOutput,
    kParameterCount,

    // Read-only UI metering. These IDs are deliberately outside the persisted
    // parameter-state range above.
    kMeterOut = 1000,
    kMeterGR = 1001
};

}} // namespace a737::vst3
