#if defined(__APPLE__)

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

#include "A737CocoaView.h"
#include "A737Controller.h"
#include "A737Parameters.h"
#include "pluginterfaces/gui/iplugview.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

using Steinberg::Vst::ParamID;
using Steinberg::Vst::ParamValue;

namespace {
static const CGFloat kDesignW = 1648.0;
static const CGFloat kDesignH = 880.0;
static const CGFloat kPi = 3.14159265358979323846;

struct HitControl {
    ParamID id;
    NSRect rect;
    bool knob;
    double minNorm;
    double maxNorm;
    int fixedChoice; // -1 normal; 0..N selects stepped choice
};

static NSColor* metalTop()    { return [NSColor colorWithCalibratedWhite:0.86 alpha:1.0]; }
static NSColor* metalBottom() { return [NSColor colorWithCalibratedWhite:0.68 alpha:1.0]; }
static NSColor* ink()         { return [NSColor colorWithCalibratedWhite:0.08 alpha:1.0]; }
static NSColor* redLED()      { return [NSColor colorWithCalibratedRed:0.87 green:0.03 blue:0.02 alpha:1.0]; }
static NSColor* panelBlack()  { return [NSColor colorWithCalibratedRed:0.035 green:0.043 blue:0.050 alpha:1.0]; }

static void drawText(NSString* text, NSRect r, CGFloat size, NSFontWeight weight, NSColor* color, NSTextAlignment align=NSTextAlignmentCenter) {
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSDictionary* attrs = @{
        NSFontAttributeName: [NSFont systemFontOfSize:size weight:weight],
        NSForegroundColorAttributeName: color,
        NSParagraphStyleAttributeName: ps
    };
    [text drawInRect:r withAttributes:attrs];
    [ps release];
}

static void drawHairline(CGContextRef c, CGFloat x1, CGFloat y1, CGFloat x2, CGFloat y2, CGFloat a=0.35) {
    CGContextSaveGState(c);
    CGContextSetStrokeColorWithColor(c, [[NSColor colorWithCalibratedWhite:0.18 alpha:a] CGColor]);
    CGContextSetLineWidth(c, 1.0);
    CGContextMoveToPoint(c, x1, y1);
    CGContextAddLineToPoint(c, x2, y2);
    CGContextStrokePath(c);
    CGContextRestoreGState(c);
}

static void drawVetraMark(CGContextRef c, CGPoint center, CGFloat s) {
    CGContextSaveGState(c);
    CGContextTranslateCTM(c, center.x, center.y);
    CGContextSetStrokeColorWithColor(c, [[NSColor colorWithCalibratedWhite:0.08 alpha:1.0] CGColor]);
    CGContextSetLineWidth(c, 5.0 * s);
    CGContextSetLineJoin(c, kCGLineJoinMiter);
    CGMutablePathRef p = CGPathCreateMutable();
    CGPathMoveToPoint(p, nullptr, -30*s, 24*s);
    CGPathAddLineToPoint(p, nullptr, 0, -24*s);
    CGPathAddLineToPoint(p, nullptr, 30*s, 24*s);
    CGPathAddLineToPoint(p, nullptr, 16*s, 24*s);
    CGPathAddLineToPoint(p, nullptr, 0, -2*s);
    CGPathAddLineToPoint(p, nullptr, -16*s, 24*s);
    CGPathCloseSubpath(p);
    CGContextAddPath(c, p);
    CGContextStrokePath(c);
    CGPathRelease(p);
    CGContextRestoreGState(c);
}

static void drawScrew(CGContextRef c, CGPoint p) {
    CGContextSaveGState(c);
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
    CGFloat locs[3] = {0, 0.45, 1};
    NSArray* colors = @[(id)[[NSColor colorWithCalibratedWhite:0.08 alpha:1] CGColor],
                        (id)[[NSColor colorWithCalibratedWhite:0.42 alpha:1] CGColor],
                        (id)[[NSColor colorWithCalibratedWhite:0.04 alpha:1] CGColor]];
    CGGradientRef g = CGGradientCreateWithColors(cs, (CFArrayRef)colors, locs);
    CGContextAddEllipseInRect(c, CGRectMake(p.x-13, p.y-13, 26, 26));
    CGContextClip(c);
    CGContextDrawRadialGradient(c, g, CGPointMake(p.x-5,p.y+6), 2, p, 14, 0);
    CGContextResetClip(c);
    CGContextSetStrokeColorWithColor(c, [[NSColor blackColor] CGColor]);
    CGContextSetLineWidth(c, 2.2);
    CGContextMoveToPoint(c, p.x-6, p.y-6); CGContextAddLineToPoint(c, p.x+6, p.y+6);
    CGContextMoveToPoint(c, p.x-6, p.y+6); CGContextAddLineToPoint(c, p.x+6, p.y-6);
    CGContextStrokePath(c);
    CGGradientRelease(g); CGColorSpaceRelease(cs);
    CGContextRestoreGState(c);
}

static void drawKnob(CGContextRef c, CGPoint p, CGFloat radius, double v, bool small=false) {
    v = std::max(0.0, std::min(1.0, v));
    CGContextSaveGState(c);
    for (int i=0;i<17;++i) {
        const double a = (-140.0 + (280.0*i/16.0)) * kPi/180.0;
        const CGFloat r1 = radius + 7;
        const CGFloat r2 = radius + (i%4==0 ? 14 : 11);
        CGContextSetStrokeColorWithColor(c, [[NSColor colorWithCalibratedWhite:0.10 alpha:0.8] CGColor]);
        CGContextSetLineWidth(c, i%4==0 ? 1.4 : 0.8);
        CGContextMoveToPoint(c, p.x + std::sin(a)*r1, p.y - std::cos(a)*r1);
        CGContextAddLineToPoint(c, p.x + std::sin(a)*r2, p.y - std::cos(a)*r2);
        CGContextStrokePath(c);
    }

    CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
    CGFloat locs[4] = {0,0.28,0.60,1};
    NSArray* ringColors=@[(id)[[NSColor colorWithCalibratedWhite:0.04 alpha:1] CGColor],
                          (id)[[NSColor colorWithCalibratedWhite:0.35 alpha:1] CGColor],
                          (id)[[NSColor colorWithCalibratedWhite:0.07 alpha:1] CGColor],
                          (id)[[NSColor colorWithCalibratedWhite:0.28 alpha:1] CGColor]];
    CGGradientRef rg=CGGradientCreateWithColors(cs,(CFArrayRef)ringColors,locs);
    CGContextAddEllipseInRect(c, CGRectMake(p.x-radius-4,p.y-radius-4,2*(radius+4),2*(radius+4)));
    CGContextClip(c);
    CGContextDrawLinearGradient(c,rg,CGPointMake(p.x-radius,p.y+radius),CGPointMake(p.x+radius,p.y-radius),0);
    CGContextResetClip(c);

    NSArray* faceColors=@[(id)[[NSColor colorWithCalibratedWhite:0.18 alpha:1] CGColor],
                          (id)[[NSColor colorWithCalibratedWhite:0.72 alpha:1] CGColor],
                          (id)[[NSColor colorWithCalibratedWhite:0.25 alpha:1] CGColor]];
    CGFloat flocs[3]={0,0.48,1};
    CGGradientRef fg=CGGradientCreateWithColors(cs,(CFArrayRef)faceColors,flocs);
    CGContextAddEllipseInRect(c,CGRectMake(p.x-radius,p.y-radius,2*radius,2*radius));
    CGContextClip(c);
    CGContextDrawLinearGradient(c,fg,CGPointMake(p.x-radius,p.y+radius),CGPointMake(p.x+radius,p.y-radius),0);
    CGContextResetClip(c);

    const double ang=(-140.0+280.0*v)*kPi/180.0;
    CGContextSetStrokeColorWithColor(c,[[NSColor colorWithCalibratedWhite:0.95 alpha:1] CGColor]);
    CGContextSetLineWidth(c,small?2.1:3.0);
    CGContextMoveToPoint(c,p.x,p.y);
    CGContextAddLineToPoint(c,p.x+std::sin(ang)*(radius-8),p.y-std::cos(ang)*(radius-8));
    CGContextStrokePath(c);
    CGContextSetStrokeColorWithColor(c,[[NSColor colorWithCalibratedWhite:0 alpha:0.7] CGColor]);
    CGContextSetLineWidth(c,1.2);
    CGContextStrokeEllipseInRect(c,CGRectMake(p.x-radius,p.y-radius,2*radius,2*radius));

    CGGradientRelease(rg); CGGradientRelease(fg); CGColorSpaceRelease(cs);
    CGContextRestoreGState(c);
}

static void drawButton(CGContextRef c, NSRect r, NSString* label, bool active) {
    CGContextSaveGState(c);
    NSBezierPath* p=[NSBezierPath bezierPathWithRoundedRect:r xRadius:3 yRadius:3];
    NSColor* fill=active?redLED():[NSColor colorWithCalibratedWhite:0.08 alpha:1.0];
    [fill setFill]; [p fill];
    [[NSColor colorWithCalibratedWhite:0 alpha:0.9] setStroke]; [p setLineWidth:2.0]; [p stroke];
    if(active){
        NSShadow* sh=[[NSShadow alloc] init]; sh.shadowBlurRadius=9; sh.shadowColor=[redLED() colorWithAlphaComponent:0.7]; sh.shadowOffset=NSMakeSize(0,0);
        [NSGraphicsContext saveGraphicsState]; [sh set]; [p stroke]; [NSGraphicsContext restoreGraphicsState]; [sh release];
    }
    drawText(label,NSInsetRect(r,2,4),13,NSFontWeightSemibold,[NSColor whiteColor]);
    CGContextRestoreGState(c);
}


static double plainFromNormalized(ParamID id, double n, int inputMode) {
    n = std::max(0.0, std::min(1.0, n));
    using namespace a737::vst3;
    switch(id) {
        case kPreampGain: return (inputMode==0 ? 58.0 : (inputMode==1 ? 30.0 : 55.0)) * n + (inputMode==2 ? -27.0 : 0.0);
        case kHPFFrequency: return 30.0 + 110.0*n;
        case kThreshold: return -30.0 + 50.0*n;
        case kCompression: return 1.0 + 19.0*n;
        case kAttack: return 2.0 + 198.0*n;
        case kRelease: return 0.1 + 4.9*n;
        case kBassGain: return -24.0 + 48.0*n;
        case kLowMidGain: case kHighMidGain: return -16.0 + 32.0*n;
        case kTrebleGain: return -20.0 + 40.0*n;
        case kLowMidFrequency: return 30.0 * std::pow(450.0/30.0,n);
        case kHighMidFrequency: return 200.0 * std::pow(2800.0/200.0,n);
        case kOutput: return n<=0.5 ? (-45.0+90.0*n) : (20.0*(n-0.5));
        case kBassFrequency: { const double a[4]={15,30,60,150}; return a[(int)std::lround(n*3.0)]; }
        case kTrebleFrequency: { const double a[4]={10000,15000,20000,32000}; return a[(int)std::lround(n*3.0)]; }
        default: return n;
    }
}

static double normalizedFromPlain(ParamID id, double p, int inputMode) {
    using namespace a737::vst3;
    double n=p;
    switch(id) {
        case kPreampGain: n=(p-(inputMode==2?-27.0:0.0))/(inputMode==0?58.0:(inputMode==1?30.0:55.0)); break;
        case kHPFFrequency: n=(p-30.0)/110.0; break;
        case kThreshold: n=(p+30.0)/50.0; break;
        case kCompression: n=(p-1.0)/19.0; break;
        case kAttack: n=(p-2.0)/198.0; break;
        case kRelease: n=(p-0.1)/4.9; break;
        case kBassGain: n=(p+24.0)/48.0; break;
        case kLowMidGain: case kHighMidGain: n=(p+16.0)/32.0; break;
        case kTrebleGain: n=(p+20.0)/40.0; break;
        case kLowMidFrequency: n=std::log(std::max(30.0,std::min(450.0,p))/30.0)/std::log(450.0/30.0); break;
        case kHighMidFrequency: n=std::log(std::max(200.0,std::min(2800.0,p))/200.0)/std::log(2800.0/200.0); break;
        case kOutput: n=p<=0.0 ? (p+45.0)/90.0 : 0.5+p/20.0; break;
        case kBassFrequency: { const double a[4]={15,30,60,150}; int best=0; for(int i=1;i<4;++i) if(std::abs(a[i]-p)<std::abs(a[best]-p))best=i; n=best/3.0; break; }
        case kTrebleFrequency: { const double a[4]={10000,15000,20000,32000}; int best=0; for(int i=1;i<4;++i) if(std::abs(a[i]-p)<std::abs(a[best]-p))best=i; n=best/3.0; break; }
        default: break;
    }
    return std::max(0.0,std::min(1.0,n));
}

static NSString* unitsForParam(ParamID id) {
    using namespace a737::vst3;
    switch(id){
        case kHPFFrequency: case kLowMidFrequency: case kHighMidFrequency: case kBassFrequency: case kTrebleFrequency: return @"Hz";
        case kAttack: return @"ms";
        case kRelease: return @"s";
        case kCompression: return @":1";
        case kPreampGain: case kThreshold: case kBassGain: case kLowMidGain: case kHighMidGain: case kTrebleGain: case kOutput: return @"dB";
        default: return @"";
    }
}

static void drawVU(CGContextRef c, NSRect r, double outNorm, double grNorm, bool showGR) {
    CGContextSaveGState(c);
    NSBezierPath* bezel=[NSBezierPath bezierPathWithRoundedRect:r xRadius:5 yRadius:5];
    [[NSColor colorWithCalibratedWhite:0.05 alpha:1] setFill]; [bezel fill];
    NSRect inner=NSInsetRect(r,8,8);
    NSBezierPath* glass=[NSBezierPath bezierPathWithRoundedRect:inner xRadius:6 yRadius:6];
    [[NSColor colorWithCalibratedRed:0.92 green:0.71 blue:0.39 alpha:1] setFill]; [glass fill];
    const CGPoint center=CGPointMake(NSMidX(inner),NSMaxY(inner)-17);
    const CGFloat rad=NSWidth(inner)*0.42;
    for(int i=0;i<=10;++i){
        const double a=(-58.0+116.0*i/10.0)*kPi/180.0;
        CGFloat rr1=rad-6, rr2=rad;
        CGContextSetStrokeColorWithColor(c,[[NSColor colorWithCalibratedWhite:0.10 alpha:0.8] CGColor]);
        CGContextSetLineWidth(c,1.0);
        CGContextMoveToPoint(c,center.x+std::sin(a)*rr1,center.y-std::cos(a)*rr1);
        CGContextAddLineToPoint(c,center.x+std::sin(a)*rr2,center.y-std::cos(a)*rr2);
        CGContextStrokePath(c);
    }
    const double nv=showGR ? 1.0-grNorm : outNorm;
    const double a=(-52.0+104.0*std::max(0.0,std::min(1.0,nv)))*kPi/180.0;
    CGContextSetStrokeColorWithColor(c,[[NSColor colorWithCalibratedRed:0.12 green:0.06 blue:0.03 alpha:1] CGColor]);
    CGContextSetLineWidth(c,2.0);
    CGContextMoveToPoint(c,center.x,center.y);
    CGContextAddLineToPoint(c,center.x+std::sin(a)*(rad-12),center.y-std::cos(a)*(rad-12));
    CGContextStrokePath(c);
    drawText(showGR?@"GR":@"VU",NSMakeRect(NSMinX(inner),NSMidY(inner)-10,NSWidth(inner),26),25,NSFontWeightBold,ink());
    drawText(@"VETRA AUDIO",NSMakeRect(NSMinX(inner),NSMidY(inner)-34,NSWidth(inner),16),12,NSFontWeightSemibold,ink());
    CGContextRestoreGState(c);
}

@interface A737PanelView : NSView {
@public
    std::vector<HitControl> _hits;
}
@property(nonatomic, assign) a737::vst3::A737Controller* controller;
@property(nonatomic) double meterOut;
@property(nonatomic) double meterGR;
@property(nonatomic) ParamID activeParam;
@property(nonatomic) BOOL dragging;
@property(nonatomic) double dragStartValue;
@property(nonatomic) CGFloat dragStartY;
@end

@implementation A737PanelView
- (BOOL)isFlipped { return YES; }
- (void)requestRedraw { [self setNeedsDisplay:YES]; }
- (instancetype)initWithFrame:(NSRect)frame controller:(a737::vst3::A737Controller*)controller {
    self=[super initWithFrame:frame];
    if(self){ self.controller=controller; self.wantsLayer=YES; self.layer.backgroundColor=[[NSColor blackColor] CGColor]; [self rebuildHits]; }
    return self;
}
- (double)v:(ParamID)pid { return self.controller ? self.controller->guiValue(pid) : 0.0; }
- (void)rebuildHits {
    using namespace a737::vst3;
    _hits.clear();
    auto K=[&](ParamID id, CGFloat x,CGFloat y,CGFloat w,CGFloat h){ _hits.push_back({id,NSMakeRect(x,y,w,h),true,0,1,-1}); };
    auto B=[&](ParamID id, CGFloat x,CGFloat y,CGFloat w,CGFloat h){ _hits.push_back({id,NSMakeRect(x,y,w,h),false,0,1,-1}); };
    auto C=[&](ParamID id, int choice, CGFloat x,CGFloat y,CGFloat w,CGFloat h){ _hits.push_back({id,NSMakeRect(x,y,w,h),false,0,1,choice}); };
    K(kPreampGain,72,237,124,124); C(kInputMode,0,48,385,53,40); C(kInputMode,2,106,385,53,40); C(kInputMode,1,164,385,53,40);
    B(kHighGain,105,454,59,28); B(kPhase,95,543,72,38);
    K(kHPFFrequency,260,258,86,86); B(kHPFOn,269,385,62,40);
    K(kBassGain,370,258,86,86); K(kBassFrequency,379,418,66,66);
    K(kLowMidGain,482,258,86,86); K(kLowMidFrequency,491,418,66,66); B(kLowMidX10,480,502,38,27); B(kLowMidQ,526,502,38,27);
    K(kHighMidGain,594,258,86,86); K(kHighMidFrequency,603,418,66,66); B(kHighMidX10,592,502,38,27); B(kHighMidQ,638,502,38,27);
    K(kTrebleGain,706,258,86,86); K(kTrebleFrequency,715,418,66,66);
    B(kEQOn,467,626,77,42); B(kSCMids,598,626,105,42);
    K(kThreshold,1151,258,88,88); K(kCompression,1265,258,88,88); K(kAttack,1151,444,88,88); K(kRelease,1265,444,88,88);
    B(kCompressorOn,1116,626,92,42); B(kEQBeforeComp,1219,626,112,42);
    K(kOutput,1450,237,124,124); B(kBypass,1460,626,91,42);
}
- (HitControl*)hitAt:(NSPoint)p {
    for(auto& h:_hits) if(NSPointInRect(p,h.rect)) return &h;
    return nullptr;
}
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    CGContextRef c=[[NSGraphicsContext currentContext] CGContext];
    const CGFloat sx=self.bounds.size.width/kDesignW, sy=self.bounds.size.height/kDesignH;
    CGContextSaveGState(c); CGContextScaleCTM(c,sx,sy);

    [panelBlack() setFill]; NSRectFill(NSMakeRect(0,0,kDesignW,kDesignH));
    // header
    [[NSColor colorWithCalibratedWhite:0.045 alpha:1] setFill]; NSRectFill(NSMakeRect(0,0,kDesignW,158));
    drawVetraMark(c,CGPointMake(97,88),0.55); drawText(@"Vetra Audio",NSMakeRect(132,68,220,36),28,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.82 alpha:1],NSTextAlignmentLeft);
    drawText(@"A737",NSMakeRect(1384,64,120,40),32,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.82 alpha:1]);
    drawText(@"VST3",NSMakeRect(1510,73,72,24),16,NSFontWeightRegular,[NSColor colorWithCalibratedWhite:0.52 alpha:1]);

    // brushed metal main panel
    CGColorSpaceRef cs=CGColorSpaceCreateDeviceRGB(); CGFloat loc[2]={0,1};
    NSArray* mc=@[(id)[metalTop() CGColor],(id)[metalBottom() CGColor]];
    CGGradientRef mg=CGGradientCreateWithColors(cs,(CFArrayRef)mc,loc);
    CGContextSaveGState(c); CGPathRef rp=CGPathCreateWithRoundedRect(CGRectMake(5,158,1638,555),5,5,nullptr); CGContextAddPath(c,rp); CGContextClip(c);
    CGContextDrawLinearGradient(c,mg,CGPointMake(0,158),CGPointMake(0,713),0);
    // subtle horizontal brushed lines
    for(int y=160;y<713;y+=3){ CGContextSetStrokeColorWithColor(c,[[NSColor colorWithCalibratedWhite:1 alpha:0.055] CGColor]); CGContextMoveToPoint(c,8,y); CGContextAddLineToPoint(c,1640,y); CGContextStrokePath(c); }
    CGContextRestoreGState(c); CGPathRelease(rp); CGGradientRelease(mg); CGColorSpaceRelease(cs);

    drawScrew(c,CGPointMake(35,189)); drawScrew(c,CGPointMake(1612,189)); drawScrew(c,CGPointMake(35,685)); drawScrew(c,CGPointMake(1612,685));
    // dividers
    const CGFloat divs[]={236,352,814,1102,1405}; for(CGFloat x:divs) drawHairline(c,x,180,x,690,0.55);

    drawText(@"INPUT",NSMakeRect(62,180,122,32),24,NSFontWeightBold,ink());
    drawText(@"HPF",NSMakeRect(259,180,86,32),24,NSFontWeightBold,ink());
    drawText(@"EQUALIZER",NSMakeRect(520,180,180,32),24,NSFontWeightBold,ink());
    drawText(@"COMPRESSOR",NSMakeRect(1162,180,190,32),24,NSFontWeightBold,ink());
    drawText(@"OUTPUT",NSMakeRect(1436,180,130,32),24,NSFontWeightBold,ink());

    // knobs/labels
    drawKnob(c,CGPointMake(134,299),53,[self v:a737::vst3::kPreampGain]); drawText(@"dB",NSMakeRect(112,353,44,22),15,NSFontWeightMedium,ink());
    const int inputChoice=(int)std::lround([self v:a737::vst3::kInputMode]*2.0);
    drawButton(c,NSMakeRect(48,385,53,40),@"MIC",inputChoice==0); drawButton(c,NSMakeRect(106,385,53,40),@"LINE",inputChoice==2); drawButton(c,NSMakeRect(164,385,53,40),@"INST",inputChoice==1);
    drawText(@"HIGH GAIN",NSMakeRect(65,438,130,22),15,NSFontWeightBold,ink()); drawButton(c,NSMakeRect(105,462,59,28),@"ON",[self v:a737::vst3::kHighGain]>=0.5);
    drawText(@"INPUT MODE",NSMakeRect(62,512,138,22),15,NSFontWeightBold,ink()); drawButton(c,NSMakeRect(95,543,72,38),@"PHASE",[self v:a737::vst3::kPhase]>=0.5);

    drawKnob(c,CGPointMake(303,301),36,[self v:a737::vst3::kHPFFrequency],true); drawText(@"30 — 140 Hz",NSMakeRect(255,345,98,18),12,NSFontWeightMedium,ink()); drawButton(c,NSMakeRect(269,385,62,40),@"IN",[self v:a737::vst3::kHPFOn]>=0.5);

    const CGFloat ex[]={413,525,637,749}; NSString* en[]={@"BASS",@"LOW MID",@"HIGH MID",@"TREBLE"};
    ParamID gainIds[]={a737::vst3::kBassGain,a737::vst3::kLowMidGain,a737::vst3::kHighMidGain,a737::vst3::kTrebleGain};
    ParamID freqIds[]={a737::vst3::kBassFrequency,a737::vst3::kLowMidFrequency,a737::vst3::kHighMidFrequency,a737::vst3::kTrebleFrequency};
    for(int i=0;i<4;++i){ drawText(en[i],NSMakeRect(ex[i]-49,215,98,24),16,NSFontWeightBold,ink()); drawKnob(c,CGPointMake(ex[i],301),36,[self v:gainIds[i]],true); drawText(@"±16 dB",NSMakeRect(ex[i]-44,345,88,18),12,NSFontWeightMedium,ink()); drawKnob(c,CGPointMake(ex[i],451),27,[self v:freqIds[i]],true); drawText(@"FREQ",NSMakeRect(ex[i]-36,487,72,18),12,NSFontWeightSemibold,ink()); }
    drawButton(c,NSMakeRect(480,502,38,27),@"×10",[self v:a737::vst3::kLowMidX10]>=0.5); drawButton(c,NSMakeRect(526,502,38,27),@"Q",[self v:a737::vst3::kLowMidQ]>=0.5);
    drawButton(c,NSMakeRect(592,502,38,27),@"×10",[self v:a737::vst3::kHighMidX10]>=0.5); drawButton(c,NSMakeRect(638,502,38,27),@"Q",[self v:a737::vst3::kHighMidQ]>=0.5);
    drawButton(c,NSMakeRect(467,626,77,42),@"EQ IN",[self v:a737::vst3::kEQOn]>=0.5); drawButton(c,NSMakeRect(598,626,105,42),@"SC → MIDS",[self v:a737::vst3::kSCMids]>=0.5);

    drawVU(c,NSMakeRect(824,211,269,178),self.meterOut,self.meterGR,[self v:a737::vst3::kCompressorOn]>=0.5 && self.meterGR>0.015);
    drawVetraMark(c,CGPointMake(958,443),0.72); drawText(@"VETRA AUDIO",NSMakeRect(856,485,204,30),24,NSFontWeightSemibold,ink()); drawText(@"A737",NSMakeRect(894,531,128,42),34,NSFontWeightMedium,ink()); drawText(@"CHANNEL STRIP",NSMakeRect(865,574,186,24),17,NSFontWeightMedium,ink());

    drawText(@"THRESHOLD",NSMakeRect(1137,215,116,22),16,NSFontWeightBold,ink()); drawKnob(c,CGPointMake(1195,301),37,[self v:a737::vst3::kThreshold],true);
    drawText(@"RATIO",NSMakeRect(1262,215,92,22),16,NSFontWeightBold,ink()); drawKnob(c,CGPointMake(1309,301),37,[self v:a737::vst3::kCompression],true);
    drawText(@"ATTACK",NSMakeRect(1149,405,92,22),16,NSFontWeightBold,ink()); drawKnob(c,CGPointMake(1195,487),37,[self v:a737::vst3::kAttack],true);
    drawText(@"RELEASE",NSMakeRect(1262,405,96,22),16,NSFontWeightBold,ink()); drawKnob(c,CGPointMake(1309,487),37,[self v:a737::vst3::kRelease],true);
    drawButton(c,NSMakeRect(1116,626,92,42),@"COMP IN",[self v:a737::vst3::kCompressorOn]>=0.5); drawButton(c,NSMakeRect(1219,626,112,42),@"EQ → COMP",[self v:a737::vst3::kEQBeforeComp]>=0.5);

    drawKnob(c,CGPointMake(1512,299),53,[self v:a737::vst3::kOutput]); drawText(@"dB",NSMakeRect(1490,353,44,22),15,NSFontWeightMedium,ink());
    drawButton(c,NSMakeRect(1460,626,91,42),@"BYPASS",[self v:a737::vst3::kBypass]>=0.5);
    NSRect badge=NSMakeRect(1428,456,144,70); NSBezierPath* bp=[NSBezierPath bezierPathWithRoundedRect:badge xRadius:5 yRadius:5]; [[NSColor colorWithCalibratedWhite:0.70 alpha:0.55] setFill];[bp fill];[[NSColor colorWithCalibratedWhite:0.15 alpha:0.8] setStroke];[bp stroke]; drawVetraMark(c,CGPointMake(1461,491),0.42); drawText(@"VETRA\nAUDIO",NSMakeRect(1480,472,82,44),16,NSFontWeightBold,ink());

    // bottom ventilation / brand zone
    [[NSColor colorWithCalibratedWhite:0.055 alpha:1] setFill]; NSRectFill(NSMakeRect(5,716,1638,96));
    drawText(@"PURE TUBE TONE\nDEFINED BY MUSIC",NSMakeRect(58,744,195,48),13,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.55 alpha:1],NSTextAlignmentLeft);
    drawVetraMark(c,CGPointMake(824,751),0.46); drawText(@"VETRA AUDIO",NSMakeRect(752,779,144,21),14,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.55 alpha:1]);
    drawText(@"ANALOG SOUL\nIN A DIGITAL WORLD",NSMakeRect(1394,744,190,48),13,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.55 alpha:1],NSTextAlignmentRight);
    for(int bank=0;bank<2;++bank){ CGFloat bx=bank==0?315:953; for(int row=0;row<3;++row)for(int col=0;col<10;++col){ NSRect slot=NSMakeRect(bx+col*38,736+row*18,30,8); [[NSColor colorWithCalibratedWhite:0.015 alpha:1] setFill]; [[NSBezierPath bezierPathWithRoundedRect:slot xRadius:4 yRadius:4] fill]; }}
    [[NSColor colorWithCalibratedWhite:0.035 alpha:1] setFill]; NSRectFill(NSMakeRect(0,817,kDesignW,63)); drawText(@"A737   |   VST3",NSMakeRect(28,836,180,25),16,NSFontWeightRegular,[NSColor colorWithCalibratedWhite:0.52 alpha:1],NSTextAlignmentLeft);
    drawText(@"VETRA AUDIO",NSMakeRect(752,836,144,25),14,NSFontWeightMedium,[NSColor colorWithCalibratedWhite:0.48 alpha:1]);

    CGContextRestoreGState(c);
}
- (NSPoint)designPoint:(NSEvent*)event {
    NSPoint p=[self convertPoint:event.locationInWindow fromView:nil];
    return NSMakePoint(p.x*kDesignW/self.bounds.size.width,p.y*kDesignH/self.bounds.size.height);
}
- (void)mouseDown:(NSEvent*)event {
    if(!self.controller) return;
    NSPoint p=[self designPoint:event]; HitControl* h=[self hitAt:p]; if(!h) return;
    self.activeParam=h->id;
    if(h->fixedChoice>=0){
        double val=(h->fixedChoice==0?0.0:(h->fixedChoice==1?0.5:1.0));
        self.controller->guiBeginEdit(h->id); self.controller->guiPerformEdit(h->id,val); self.controller->guiEndEdit(h->id); [self setNeedsDisplay:YES]; return;
    }
    if(!h->knob){
        double v=[self v:h->id]>=0.5?0.0:1.0;
        self.controller->guiBeginEdit(h->id); self.controller->guiPerformEdit(h->id,v); self.controller->guiEndEdit(h->id); [self setNeedsDisplay:YES]; return;
    }
    if(event.clickCount >= 2){
        double def=0.5;
        switch(h->id){ case a737::vst3::kHPFFrequency: case a737::vst3::kAttack: case a737::vst3::kRelease: def=0.0; break; case a737::vst3::kBassFrequency: case a737::vst3::kTrebleFrequency:def=1.0/3.0;break; default:break; }
        self.controller->guiBeginEdit(h->id); self.controller->guiPerformEdit(h->id,def); self.controller->guiEndEdit(h->id); [self setNeedsDisplay:YES]; return;
    }
    self.dragging=YES; self.dragStartY=p.y; self.dragStartValue=[self v:h->id]; self.controller->guiBeginEdit(h->id);
}
- (void)mouseDragged:(NSEvent*)event {
    if(!self.dragging||!self.controller)return;
    NSPoint p=[self designPoint:event]; double v=self.dragStartValue+(self.dragStartY-p.y)/180.0;
    self.controller->guiPerformEdit(self.activeParam,std::max(0.0,std::min(1.0,v))); [self setNeedsDisplay:YES];
}
- (void)mouseUp:(NSEvent*)event { (void)event; if(self.dragging&&self.controller) self.controller->guiEndEdit(self.activeParam); self.dragging=NO; }
- (void)rightMouseDown:(NSEvent*)event {
    NSPoint p=[self designPoint:event]; HitControl* h=[self hitAt:p]; if(!h||!h->knob||!self.controller)return;
    const int inputMode=(int)std::lround([self v:a737::vst3::kInputMode]*2.0);
    const double current=plainFromNormalized(h->id,[self v:h->id],inputMode);
    NSAlert* alert=[[NSAlert alloc] init];
    [alert setMessageText:@"Enter parameter value"];
    [alert setInformativeText:[NSString stringWithFormat:@"Current: %.3f %@", current, unitsForParam(h->id)]];
    NSTextField* field=[[NSTextField alloc] initWithFrame:NSMakeRect(0,0,220,24)];
    [field setStringValue:[NSString stringWithFormat:@"%.6g",current]];
    [alert setAccessoryView:field];
    [alert addButtonWithTitle:@"Set"]; [alert addButtonWithTitle:@"Cancel"];
    NSInteger result=[alert runModal];
    if(result==NSAlertFirstButtonReturn){
        double plain=[[field stringValue] doubleValue];
        double norm=normalizedFromPlain(h->id,plain,inputMode);
        self.controller->guiBeginEdit(h->id); self.controller->guiPerformEdit(h->id,norm); self.controller->guiEndEdit(h->id); [self setNeedsDisplay:YES];
    }
    [field release]; [alert release];
}
@end
} // anonymous namespace

namespace a737 { namespace vst3 {
A737EditorView::A737EditorView(A737Controller* controller)
    : CPluginView(nullptr), controller_(controller) {
    rect.left=0; rect.top=0; rect.right=(Steinberg::int32)kDesignW; rect.bottom=(Steinberg::int32)kDesignH;
    if(controller_) controller_->setEditorView(this);
}
A737EditorView::~A737EditorView(){
    if(controller_) controller_->setEditorView(nullptr);
    if(nativeView_){ A737PanelView* v=(A737PanelView*)nativeView_; [v removeFromSuperview]; [v release]; nativeView_=nullptr; }
}
Steinberg::tresult PLUGIN_API A737EditorView::isPlatformTypeSupported(Steinberg::FIDString type){
    return type && std::strcmp(type,Steinberg::kPlatformTypeNSView)==0 ? Steinberg::kResultTrue : Steinberg::kResultFalse;
}
Steinberg::tresult PLUGIN_API A737EditorView::attached(void* parent, Steinberg::FIDString type){
    if(isPlatformTypeSupported(type)!=Steinberg::kResultTrue||!parent)return Steinberg::kResultFalse;
    NSView* parentView=(NSView*)parent;
    A737PanelView* panel=[[A737PanelView alloc] initWithFrame:NSMakeRect(0,0,kDesignW,kDesignH) controller:controller_];
    panel.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable; [parentView addSubview:panel];
    nativeView_=panel; systemWindow=parent; return Steinberg::kResultTrue;
}
Steinberg::tresult PLUGIN_API A737EditorView::removed(){
    if(nativeView_){ A737PanelView* v=(A737PanelView*)nativeView_; [v removeFromSuperview]; [v release]; nativeView_=nullptr; }
    systemWindow=nullptr; return Steinberg::kResultTrue;
}
Steinberg::tresult PLUGIN_API A737EditorView::onSize(Steinberg::ViewRect* newSize){ if(!newSize)return Steinberg::kInvalidArgument; rect=*newSize; if(nativeView_){A737PanelView* v=(A737PanelView*)nativeView_;v.frame=NSMakeRect(0,0,rect.getWidth(),rect.getHeight());} return Steinberg::kResultTrue; }
Steinberg::tresult PLUGIN_API A737EditorView::getSize(Steinberg::ViewRect* size){ if(!size)return Steinberg::kInvalidArgument;*size=rect;return Steinberg::kResultTrue; }
Steinberg::tresult PLUGIN_API A737EditorView::checkSizeConstraint(Steinberg::ViewRect* r){ if(!r)return Steinberg::kInvalidArgument; r->right=r->left+(Steinberg::int32)kDesignW; r->bottom=r->top+(Steinberg::int32)kDesignH; return Steinberg::kResultTrue; }
void A737EditorView::parameterChanged(ParamID tag, ParamValue value) noexcept {
    if(!nativeView_) return;
    A737PanelView* v=(A737PanelView*)nativeView_;
    if(tag==kMeterOut)v.meterOut=value; else if(tag==kMeterGR)v.meterGR=value;
    if([NSThread isMainThread]) {
        [v setNeedsDisplay:YES];
    } else {
        [v performSelectorOnMainThread:@selector(requestRedraw) withObject:nil waitUntilDone:NO];
    }
}
}} // namespace a737::vst3
#endif
