#include "A737Controller.h"
#include "A737Parameters.h"
#include "base/source/fstreamer.h"
#include "pluginterfaces/gui/iplugview.h"
#include <cstring>
#include <cmath>

#if defined(__APPLE__)
#include "A737CocoaView.h"
#endif

using namespace Steinberg;

namespace a737 { namespace vst3 {
namespace {
void addContinuous(Vst::ParameterContainer& p, const TChar* name, Vst::ParamID id, double def) {
    p.addParameter(name, nullptr, 0, def, Vst::ParameterInfo::kCanAutomate, id);
}
void addToggle(Vst::ParameterContainer& p, const TChar* name, Vst::ParamID id, bool def=false, bool bypass=false) {
    int32 flags = Vst::ParameterInfo::kCanAutomate;
    if (bypass) flags |= Vst::ParameterInfo::kIsBypass;
    p.addParameter(name, nullptr, 1, def ? 1.0 : 0.0, flags, id);
}
}

tresult PLUGIN_API A737Controller::initialize(FUnknown* context) {
    tresult r = EditControllerEx1::initialize(context);
    if (r != kResultOk) return r;
    addToggle(parameters, STR16("Bypass"), kBypass, false, true);
    parameters.addParameter(STR16("Input Mode"), nullptr, 2, 1.0, Vst::ParameterInfo::kCanAutomate, kInputMode);
    addContinuous(parameters, STR16("Preamp Gain"), kPreampGain, 0.5);
    addToggle(parameters, STR16("High Gain"), kHighGain);
    addToggle(parameters, STR16("Phase Reverse"), kPhase);
    addToggle(parameters, STR16("High Pass"), kHPFOn);
    addContinuous(parameters, STR16("HPF Frequency"), kHPFFrequency, 0.0);
    addToggle(parameters, STR16("Compressor"), kCompressorOn);
    addContinuous(parameters, STR16("Threshold"), kThreshold, 0.5);
    addContinuous(parameters, STR16("Compression"), kCompression, 0.5);
    addContinuous(parameters, STR16("Attack"), kAttack, 0.0);
    addContinuous(parameters, STR16("Release"), kRelease, 0.0);
    addToggle(parameters, STR16("Equalizer"), kEQOn);
    addToggle(parameters, STR16("EQ Before Compressor"), kEQBeforeComp);
    addToggle(parameters, STR16("SC to Mids"), kSCMids);
    parameters.addParameter(STR16("Bass Frequency"), nullptr, 3, 1.0/3.0, Vst::ParameterInfo::kCanAutomate, kBassFrequency);
    addContinuous(parameters, STR16("Bass Gain"), kBassGain, 0.5);
    addContinuous(parameters, STR16("Low Mid Frequency"), kLowMidFrequency, 0.5);
    addToggle(parameters, STR16("Low Mid X10"), kLowMidX10);
    addToggle(parameters, STR16("Low Mid Hi-Q"), kLowMidQ);
    addContinuous(parameters, STR16("Low Mid Gain"), kLowMidGain, 0.5);
    addContinuous(parameters, STR16("High Mid Frequency"), kHighMidFrequency, 0.5);
    addToggle(parameters, STR16("High Mid X10"), kHighMidX10);
    addToggle(parameters, STR16("High Mid Hi-Q"), kHighMidQ);
    addContinuous(parameters, STR16("High Mid Gain"), kHighMidGain, 0.5);
    parameters.addParameter(STR16("Treble Frequency"), nullptr, 3, 1.0/3.0, Vst::ParameterInfo::kCanAutomate, kTrebleFrequency);
    addContinuous(parameters, STR16("Treble Gain"), kTrebleGain, 0.5);
    addContinuous(parameters, STR16("Output"), kOutput, 0.5);

    parameters.addParameter(STR16("Output Meter"), nullptr, 0, 0.0,
                            Vst::ParameterInfo::kIsReadOnly, kMeterOut);
    parameters.addParameter(STR16("Gain Reduction Meter"), nullptr, 0, 0.0,
                            Vst::ParameterInfo::kIsReadOnly, kMeterGR);
    return kResultOk;
}

tresult PLUGIN_API A737Controller::setComponentState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    for (int i=0;i<kParameterCount;++i) {
        double v=0.0; if (!s.readDouble(v)) return kResultFalse;
        setParamNormalized(static_cast<Vst::ParamID>(i), v);
    }
    return kResultOk;
}

tresult PLUGIN_API A737Controller::setParamNormalized(Vst::ParamID tag, Vst::ParamValue value) {
    const tresult r = EditControllerEx1::setParamNormalized(tag, value);
#if defined(__APPLE__)
    if (r == kResultOk && editorView_) editorView_->parameterChanged(tag, value);
#endif
    return r;
}

IPlugView* PLUGIN_API A737Controller::createView(FIDString name) {
#if defined(__APPLE__)
    if (name && std::strcmp(name, Vst::ViewType::kEditor) == 0)
        return new A737EditorView(this);
#else
    (void)name;
#endif
    return nullptr;
}

void A737Controller::guiBeginEdit(Vst::ParamID tag) {
    beginEdit(tag);
}
void A737Controller::guiPerformEdit(Vst::ParamID tag, Vst::ParamValue value) {
    value = value < 0.0 ? 0.0 : (value > 1.0 ? 1.0 : value);
    if (tag == kBassFrequency || tag == kTrebleFrequency)
        value = std::floor(value * 3.0 + 0.5) / 3.0;
    else if (tag == kInputMode)
        value = std::floor(value * 2.0 + 0.5) / 2.0;
    setParamNormalized(tag, value);
    performEdit(tag, value);
}
void A737Controller::guiEndEdit(Vst::ParamID tag) {
    endEdit(tag);
}
Vst::ParamValue A737Controller::guiValue(Vst::ParamID tag) const {
    return const_cast<A737Controller*>(this)->getParamNormalized(tag);
}

}} // namespace a737::vst3
