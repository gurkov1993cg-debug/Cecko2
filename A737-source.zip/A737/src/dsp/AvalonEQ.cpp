#include "AvalonEQ.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {
namespace {
const double kBassFreqs[4] = {15.0, 30.0, 60.0, 150.0};
const double kTrebleFreqs[4] = {10000.0, 15000.0, 20000.0, 32000.0};
}

AvalonEQ::AvalonEQ(double sampleRate)
    : classA_(DiscreteClassAStage::Config()) {
    setSampleRate(sampleRate);
    setControls(EQControls());
}
void AvalonEQ::setSampleRate(double sampleRate) noexcept {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    bass_.setSampleRate(sampleRate_);
    lowMid_.setSampleRate(sampleRate_);
    highMid_.setSampleRate(sampleRate_);
    treble_.setSampleRate(sampleRate_);
    updateCells();
}
void AvalonEQ::setControls(const EQControls& c) noexcept {
    controls_ = c;
    updateCells();
}
void AvalonEQ::reset() noexcept {
    bass_.reset(); lowMid_.reset(); highMid_.reset(); treble_.reset();
}
double AvalonEQ::mapLog(double p, double lo, double hi) noexcept {
    p = clampd(p, 0.0, 1.0);
    return lo * std::pow(hi / lo, p);
}
void AvalonEQ::updateCells() noexcept {
    const int bi = std::max(0, std::min(3, controls_.bassFrequencyIndex));
    const int ti = std::max(0, std::min(3, controls_.trebleFrequencyIndex));
    bass_.setCorner(kBassFreqs[bi]);
    bass_.setGainDb(-24.0 + 48.0 * clampd(controls_.bassGain01, 0.0, 1.0));
    treble_.setCorner(std::min(kTrebleFreqs[ti], 0.40 * sampleRate_));
    treble_.setGainDb(-20.0 + 40.0 * clampd(controls_.trebleGain01, 0.0, 1.0));

    double lf = mapLog(controls_.lowMidFrequency01, 30.0, 450.0);
    if (controls_.lowMidX10) lf *= 10.0;
    lowMid_.setFrequency(lf);
    lowMid_.setQ(controls_.lowMidHighQ ? 0.85 : 0.20);
    lowMid_.setGainDb(-16.0 + 32.0 * clampd(controls_.lowMidGain01, 0.0, 1.0));

    double hf = mapLog(controls_.highMidFrequency01, 200.0, 2800.0);
    if (controls_.highMidX10) hf *= 10.0;
    highMid_.setFrequency(hf);
    highMid_.setQ(controls_.highMidHighQ ? 0.85 : 0.20);
    highMid_.setGainDb(-16.0 + 32.0 * clampd(controls_.highMidGain01, 0.0, 1.0));
}

double AvalonEQ::processAudio(double x) noexcept {
    if (!controls_.enabled && !controls_.sidechainMids) return x;
    double y = x;
    if (controls_.enabled) {
        y = bass_.process(y);
        if (!controls_.sidechainMids) {
            y = lowMid_.process(y);
            y = highMid_.process(y);
        }
        y = treble_.process(y);
        // CONFIRMED architecture: discrete high-voltage Class A EQ stages.
        y = classA_.process(y);
    }
    return y;
}

double AvalonEQ::processSidechainMids(double x) noexcept {
    if (!controls_.sidechainMids) return x;
    double y = lowMid_.process(x);
    y = highMid_.process(y);
    return classA_.process(y);
}

}} // namespace a737::dsp
