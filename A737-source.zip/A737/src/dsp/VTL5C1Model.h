#pragma once

#include <cstddef>

namespace a737 {
namespace dsp {

// VTL5C1 circuit-level photoresistor model for the A737 project.
//
// CONFIRMED source data (PerkinElmer/Excelitas VTL5C1 datasheet):
//   R(1 mA)  = 20 kOhm (typ., dark adapted)
//   R(10 mA) = 600 Ohm (typ., dark adapted)
//   R(40 mA) = 200 Ohm (typ., dark adapted)
//   R(0.5 mA) / R(5 mA) = 15 (typ. slope definition)
//   R_dark >= 50 MOhm after 10 s
//   I_LED,max = 40 mA
//   turn-on to 63% final conductance = 2.5 ms typ.
//   turn-off to 100 kOhm = 35 ms max.
//   transfer curves depend on light-adapt history.
//
// IMPORTANT: parameters not numerically specified by the datasheet are not
// silently invented. They live in Calibration and are marked ASSUMPTION/TODO.
class VTL5C1Model final {
public:
    struct Calibration {
        // ASSUMPTION: shape of the 0..0.5 mA bridge in log(R). The datasheet
        // explicitly warns that <=1 mA units may differ substantially.
        // TODO: verify/calibrate from a selected Avalon-binned VTL5C1 sample.
        double subHalfMilliampShape = 1.0;

        // INFERENCE: single-pole conductance release time constant chosen so a
        // 40 mA state (200 Ohm) reaches 100 kOhm in 35 ms, matching the datasheet response-test drive condition.
        // This enforces the datasheet maximum response criterion but is not a
        // claimed physical time constant of the device.
        double turnOffTauSeconds = derivedTurnOffTauSeconds();

        // UNKNOWN: kinetics of the datasheet light-history adaptation are not
        // specified. A value <=0 disables history movement until calibrated.
        // TODO: derive from measurements on an Avalon-selected cell.
        double historyAttackSeconds = 0.0;
        double historyReleaseSeconds = 0.0;

        // UNKNOWN: full light-adapt shift of ln(R) at 25 C is visible in the
        // datasheet graph but not tabulated numerically. 0.0 means no shift.
        // TODO: digitize curves 1 and 2 or measure selected hardware.
        double historyFullAdaptLogRShift = 0.0;

        // UNKNOWN: mapping LED current -> long-term adaptation target.
        // TODO: calibrate. Exponent=1 is only used if history is explicitly
        // enabled by non-zero history time constants and shift.
        double historyCurrentExponent = 1.0;
    };

    explicit VTL5C1Model(double sampleRate);
    VTL5C1Model(double sampleRate, Calibration calibration);

    void setSampleRate(double sampleRate);
    void setCalibration(Calibration calibration);
    void reset(double initialLedCurrentAmps = 0.0);

    // Advances the optocell by one sample and returns LDR resistance in ohms.
    double process(double ledCurrentAmps) noexcept;

    double resistanceOhms() const noexcept;
    double conductanceSiemens() const noexcept;
    double lightHistoryState() const noexcept;

    // Static nominal transfer before dynamic response/history.
    static double nominalResistanceOhms(
        double ledCurrentAmps,
        double subHalfMilliampShape = 1.0) noexcept;

    // Derived, not measured: first-order conductance tau that reaches 100 kOhm
    // at 35 ms starting from 200 Ohm and asymptoting to 50 MOhm.
    static double derivedTurnOffTauSeconds() noexcept;

private:
    static constexpr double kDarkResistanceOhms = 50.0e6;
    static constexpr double kMaxLedCurrentAmps = 40.0e-3;
    static constexpr double kTurnOnTauSeconds = 2.5e-3;

    double sampleRate_ = 44100.0;
    Calibration calibration_{};
    double conductance_ = 1.0 / kDarkResistanceOhms;
    double history_ = 0.0;

    double historyTarget(double ledCurrentAmps) const noexcept;
    double applyHistory(double resistanceOhms) const noexcept;
    static double clamp(double x, double lo, double hi) noexcept;
    static double smoothHermiteLogLog(double currentAmps) noexcept;
};

} // namespace dsp
} // namespace a737
