#pragma once

#include <algorithm>
#include <cmath>

namespace a737 { namespace dsp {

inline double clampd(double x, double lo, double hi) noexcept {
    return std::max(lo, std::min(x, hi));
}

inline double dbToGain(double db) noexcept {
    return std::pow(10.0, db / 20.0);
}

inline double gainToDb(double g) noexcept {
    return 20.0 * std::log10(std::max(g, 1.0e-20));
}

inline double dBuToVrms(double dBu) noexcept {
    return 0.775 * std::pow(10.0, dBu / 20.0);
}

inline double dBuToVpeak(double dBu) noexcept {
    return dBuToVrms(dBu) * 1.4142135623730951;
}

// Project I/O calibration: a full-scale sine (peak = 1.0) represents +24 dBu RMS.
// ASSUMPTION: this is a plug-in calibration choice, not an Avalon hardware fact.
inline double digitalToVolts(double x) noexcept {
    return x * dBuToVpeak(24.0);
}

inline double voltsToDigital(double v) noexcept {
    return v / dBuToVpeak(24.0);
}

}} // namespace a737::dsp
