#pragma once

#include "Transformer45100001.h"
#include "Triode6922.h"
#include "PassiveFilters.h"
#include "OptoCompressor.h"
#include "AvalonEQ.h"
#include "DiscreteClassAStage.h"

namespace a737 { namespace dsp {

enum class InputMode { Mic = 0, Instrument = 1, Line = 2 };

struct A737Controls {
    bool bypass = false;
    InputMode inputMode = InputMode::Line;
    double preampGain01 = 0.5;
    bool highGain = false;
    bool phaseReverse = false;
    bool highPassEnabled = false;
    double highPassFrequency01 = 0.0;
    bool eqBeforeCompressor = false;
    CompressorControls compressor;
    EQControls eq;
    double output01 = 0.5;
};

class A737Channel final {
public:
    explicit A737Channel(double sampleRate = 44100.0);
    void setSampleRate(double sampleRate);
    void setControls(const A737Controls& c);
    void reset();

    double processSample(double inputDigital) noexcept;
    double gainReductionDb() const noexcept { return compressor_.gainReductionDb(); }

private:
    double preamp(double volts) noexcept;
    double outputTrimGain() const noexcept;
    double gainPotAttenuation() const noexcept;

    double sampleRate_ = 44100.0;
    A737Controls controls_;
    Transformer45100001 micTransformer_;
    DualTriode6922 v1_;
    DualTriode6922 v2_;
    RCOnePole hpfLowpass_;
    OptoCompressor compressor_;
    AvalonEQ eq_;
    DualTriode6922 v3_;
    DiscreteClassAStage lineInputStage_;
    DiscreteClassAStage outputStage_;
};

}} // namespace a737::dsp
