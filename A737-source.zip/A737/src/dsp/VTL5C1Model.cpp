#include "VTL5C1Model.h"

#include <algorithm>
#include <cmath>

namespace a737 {
namespace dsp {
namespace {
constexpr double kOneMilliamp = 1.0e-3;
constexpr double kHalfMilliamp = 0.5e-3;
constexpr double kFiveMilliamp = 5.0e-3;
constexpr double kTenMilliamp = 10.0e-3;
constexpr double kFortyMilliamp = 40.0e-3;
constexpr double kRAtOneMilliamp = 20.0e3;
constexpr double kRAtTenMilliamp = 600.0;
constexpr double kRAtFortyMilliamp = 200.0;
constexpr double kRDark = 50.0e6;
constexpr double kSlopeRatio = 15.0;
constexpr double kTurnOffCriterionResistance = 100.0e3;
constexpr double kTurnOffCriterionSeconds = 35.0e-3;

// INFERENCE: represent the datasheet 0.5..5 mA slope ratio as one straight
// segment in log(I)-log(R), anchored to the confirmed 1 mA point.
const double kSlopeExponent = std::log(kSlopeRatio) / std::log(10.0);

inline double resistanceAtFiveMilliamp() noexcept {
    return kRAtOneMilliamp * std::pow(5.0, -kSlopeExponent);
}

inline double logLogPowerResistance(double currentAmps,
                                    double anchorCurrentAmps,
                                    double anchorResistanceOhms,
                                    double exponent) noexcept {
    return anchorResistanceOhms *
           std::pow(currentAmps / anchorCurrentAmps, -exponent);
}

inline double onePoleCoefficient(double sampleRate, double tauSeconds) noexcept {
    if (sampleRate <= 0.0 || tauSeconds <= 0.0) {
        return 0.0;
    }
    return std::exp(-1.0 / (sampleRate * tauSeconds));
}
} // namespace

VTL5C1Model::VTL5C1Model(double sampleRate)
    : VTL5C1Model(sampleRate, Calibration{}) {}

VTL5C1Model::VTL5C1Model(double sampleRate, Calibration calibration)
    : calibration_(calibration) {
    setSampleRate(sampleRate);
    reset();
}

void VTL5C1Model::setSampleRate(double sampleRate) {
    // Defensive runtime fallback only; not a circuit assumption.
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
}

void VTL5C1Model::setCalibration(Calibration calibration) {
    calibration_ = calibration;
}

void VTL5C1Model::reset(double initialLedCurrentAmps) {
    history_ = 0.0;
    const double r = nominalResistanceOhms(initialLedCurrentAmps,
                                            calibration_.subHalfMilliampShape);
    conductance_ = 1.0 / clamp(r, 1.0, kDarkResistanceOhms);
}

double VTL5C1Model::process(double ledCurrentAmps) noexcept {
    const double current = clamp(ledCurrentAmps, 0.0, kMaxLedCurrentAmps);

    // Slow light-history state. Disabled until calibration values are supplied.
    const double targetHistory = historyTarget(current);
    if (targetHistory > history_ && calibration_.historyAttackSeconds > 0.0) {
        const double a = onePoleCoefficient(sampleRate_, calibration_.historyAttackSeconds);
        history_ = targetHistory + (history_ - targetHistory) * a;
    } else if (targetHistory < history_ && calibration_.historyReleaseSeconds > 0.0) {
        const double a = onePoleCoefficient(sampleRate_, calibration_.historyReleaseSeconds);
        history_ = targetHistory + (history_ - targetHistory) * a;
    }
    history_ = clamp(history_, 0.0, 1.0);

    double targetResistance = nominalResistanceOhms(
        current, calibration_.subHalfMilliampShape);
    targetResistance = applyHistory(targetResistance);
    targetResistance = clamp(targetResistance, 1.0, kDarkResistanceOhms);
    const double targetConductance = 1.0 / targetResistance;

    // CONFIRMED specification note: ascent is measured to 63% of final
    // conductance after application of 40 mA. We therefore keep conductance as
    // the dynamic state. INFERENCE: a single first-order pole with constant
    // tau models that criterion away from the specified test condition.
    const bool turningOn = targetConductance > conductance_;
    const double tau = turningOn ? kTurnOnTauSeconds
                                 : calibration_.turnOffTauSeconds;
    const double a = onePoleCoefficient(sampleRate_, tau);
    conductance_ = targetConductance + (conductance_ - targetConductance) * a;

    const double minConductance = 1.0 / kDarkResistanceOhms;
    conductance_ = std::max(conductance_, minConductance);
    return resistanceOhms();
}

double VTL5C1Model::resistanceOhms() const noexcept {
    if (conductance_ <= 0.0 || !std::isfinite(conductance_)) {
        return kDarkResistanceOhms;
    }
    return clamp(1.0 / conductance_, 1.0, kDarkResistanceOhms);
}

double VTL5C1Model::conductanceSiemens() const noexcept {
    return conductance_;
}

double VTL5C1Model::lightHistoryState() const noexcept {
    return history_;
}

double VTL5C1Model::nominalResistanceOhms(double ledCurrentAmps,
                                           double subHalfMilliampShape) noexcept {
    const double current = clamp(ledCurrentAmps, 0.0, kFortyMilliamp);
    const double shape = subHalfMilliampShape > 0.0 ? subHalfMilliampShape : 1.0;

    if (current <= 0.0) {
        return kRDark;
    }

    const double rAtHalfMilliamp = logLogPowerResistance(
        kHalfMilliamp, kOneMilliamp, kRAtOneMilliamp, kSlopeExponent);

    if (current < kHalfMilliamp) {
        // ASSUMPTION: smooth bridge in log(R) from exact project dark clamp to
        // the slope-constrained 0.5 mA endpoint. Its shape is calibration-only.
        // TODO: replace by measured/digitized selected-cell data.
        const double u = clamp(current / kHalfMilliamp, 0.0, 1.0);
        const double s = std::pow(u, shape);
        const double logR = (1.0 - s) * std::log(kRDark) +
                            s * std::log(rAtHalfMilliamp);
        return std::exp(logR);
    }

    if (current <= kFiveMilliamp) {
        return logLogPowerResistance(current,
                                     kOneMilliamp,
                                     kRAtOneMilliamp,
                                     kSlopeExponent);
    }

    if (current < kTenMilliamp) {
        return smoothHermiteLogLog(current);
    }

    // CONFIRMED endpoints with INFERENCE log-log interpolation between them.
    const double exponent = std::log(kRAtTenMilliamp / kRAtFortyMilliamp) /
                            std::log(kFortyMilliamp / kTenMilliamp);
    return logLogPowerResistance(current,
                                 kTenMilliamp,
                                 kRAtTenMilliamp,
                                 exponent);
}

double VTL5C1Model::derivedTurnOffTauSeconds() noexcept {
    // INFERENCE from confirmed datasheet criterion, not a measured tau.
    const double gStart = 1.0 / kRAtFortyMilliamp;
    const double gTarget = 1.0 / kTurnOffCriterionResistance;
    const double gDark = 1.0 / kRDark;
    const double ratio = (gTarget - gDark) / (gStart - gDark);
    if (!(ratio > 0.0 && ratio < 1.0)) {
        return 6.8e-3;
    }
    return -kTurnOffCriterionSeconds / std::log(ratio);
}

double VTL5C1Model::historyTarget(double ledCurrentAmps) const noexcept {
    const bool enabled = calibration_.historyFullAdaptLogRShift != 0.0 &&
                         calibration_.historyAttackSeconds > 0.0 &&
                         calibration_.historyReleaseSeconds > 0.0;
    if (!enabled) {
        return history_;
    }

    const double normalized = clamp(ledCurrentAmps / kMaxLedCurrentAmps, 0.0, 1.0);
    const double exponent = calibration_.historyCurrentExponent > 0.0
                                ? calibration_.historyCurrentExponent
                                : 1.0;
    return std::pow(normalized, exponent);
}

double VTL5C1Model::applyHistory(double resistanceOhms) const noexcept {
    // UNKNOWN magnitude until curve 1 vs curve 2 is digitized/measured.
    const double shift = history_ * calibration_.historyFullAdaptLogRShift;
    return std::exp(std::log(std::max(resistanceOhms, 1.0)) + shift);
}

double VTL5C1Model::clamp(double x, double lo, double hi) noexcept {
    return std::max(lo, std::min(x, hi));
}

double VTL5C1Model::smoothHermiteLogLog(double currentAmps) noexcept {
    const double x0 = std::log(kFiveMilliamp);
    const double x1 = std::log(kTenMilliamp);
    const double y0 = std::log(resistanceAtFiveMilliamp());
    const double y1 = std::log(kRAtTenMilliamp);
    const double dx = x1 - x0;
    const double x = std::log(clamp(currentAmps, kFiveMilliamp, kTenMilliamp));
    const double t = (x - x0) / dx;

    // Left derivative follows the slope-constrained 0.5..5 mA segment.
    const double m0 = -kSlopeExponent;

    // Right derivative follows the confirmed-endpoint 10..40 mA log-log line.
    const double rightExponent = std::log(kRAtTenMilliamp / kRAtFortyMilliamp) /
                                 std::log(kFortyMilliamp / kTenMilliamp);
    const double m1 = -rightExponent;

    const double t2 = t * t;
    const double t3 = t2 * t;
    const double h00 = 2.0 * t3 - 3.0 * t2 + 1.0;
    const double h10 = t3 - 2.0 * t2 + t;
    const double h01 = -2.0 * t3 + 3.0 * t2;
    const double h11 = t3 - t2;

    const double y = h00 * y0 + h10 * dx * m0 +
                     h01 * y1 + h11 * dx * m1;
    return std::exp(y);
}

} // namespace dsp
} // namespace a737
