#include "DiscreteClassAStage.h"
#include <cmath>
#include <algorithm>

namespace a737 { namespace dsp {

double DiscreteClassAStage::process(double x) const noexcept {
    const double loaded = c_.loadOhms / (c_.loadOhms + c_.outputResistanceOhms);
    const double linear = c_.smallSignalGain * x * loaded;
    // Differential-pair/current-converter inspired soft saturation toward rails.
    const double scale = c_.linearityVolts > 0.0 ? c_.linearityVolts : c_.railVolts;
    const double shaped = scale * std::tanh(linear / scale);
    // final hard physical rail guard
    const double rail = c_.railVolts * 0.995;
    return std::max(-rail, std::min(rail, shaped));
}

}} // namespace a737::dsp
