#pragma once

#include "PassiveFilters.h"
#include "DiscreteClassAStage.h"

namespace a737 { namespace dsp {

struct EQControls {
    bool enabled = false;
    bool sidechainMids = false;
    int bassFrequencyIndex = 1;    // 15,30,60,150
    double bassGain01 = 0.5;       // -24..+24 dB
    double lowMidFrequency01 = 0.5;
    bool lowMidX10 = false;
    bool lowMidHighQ = false;
    double lowMidGain01 = 0.5;     // -16..+16 dB
    double highMidFrequency01 = 0.5;
    bool highMidX10 = false;
    bool highMidHighQ = false;
    double highMidGain01 = 0.5;
    int trebleFrequencyIndex = 1;  // 10k,15k,20k,32k
    double trebleGain01 = 0.5;     // -20..+20 dB
};

class AvalonEQ final {
public:
    explicit AvalonEQ(double sampleRate = 44100.0);
    void setSampleRate(double sampleRate) noexcept;
    void setControls(const EQControls& c) noexcept;
    void reset() noexcept;

    // Full audio EQ; when sidechainMids=true only bass/treble remain here.
    double processAudio(double x) noexcept;
    // Mid-only sidechain coloration, active even if EQ main switch is off.
    double processSidechainMids(double x) noexcept;
private:
    void updateCells() noexcept;
    static double mapLog(double p, double lo, double hi) noexcept;

    double sampleRate_ = 44100.0;
    EQControls controls_;
    RCShelfCell bass_{RCShelfCell::Type::Low};
    GyratorMidCell lowMid_;
    GyratorMidCell highMid_;
    RCShelfCell treble_{RCShelfCell::Type::High};
    DiscreteClassAStage classA_;
};

}} // namespace a737::dsp
