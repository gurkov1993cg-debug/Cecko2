#pragma once

#include "PassiveFilters.h"

namespace a737 { namespace dsp {

// Engineering reconstruction of Avalon input transformer P/N 4510-0001.
// CONFIRMED: transformer-balanced mic input, nominal 850 ohm input impedance.
// UNKNOWN: turns ratio, inductance, leakage, copper resistance and core material.
// ASSUMPTION values below are chosen to reproduce plausible VT-737sp headroom,
// including reduced low-frequency maximum level (26 dBu @ 25 Hz vs 30 dBu @ 1 kHz).
class Transformer45100001 final {
public:
    void setSampleRate(double sampleRate) noexcept;
    void reset() noexcept;
    double process(double inputVolts) noexcept;
private:
    double sampleRate_ = 44100.0;
    double fluxVs_ = 0.0;
    double turnsRatio_ = 2.5;       // ASSUMPTION: ~7.96 dB voltage step-up.
    double fluxLimitVs_ = 0.18;     // ASSUMPTION: calibrates LF saturation onset.
    double fluxLeakHz_ = 1.0;       // numerical/core-remanence relaxation.
    RCOnePole hfPole_;
};

}} // namespace a737::dsp
