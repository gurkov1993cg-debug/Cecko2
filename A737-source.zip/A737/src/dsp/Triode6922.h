#pragma once

namespace a737 { namespace dsp {

// Direct nonlinear triode circuit reconstruction using a Child-Langmuir-style
// 3/2 law calibrated to published 6922/E88CC operating data.
// CONFIRMED tube data used: mu ~= 33, 15 mA at Va=90 V / Vgk=-1.3 V,
// typical cathode resistor 82..120 ohm range in datasheets.
// ASSUMPTION: each A737 gain half is represented as a self-biased common-
// cathode stage with B+=185 V, Ra=6.2 k, Rk=82 ohm. The unpublished Avalon
// tube-card netlist is not claimed to use these exact values.
class Triode6922Stage final {
public:
    struct Circuit {
        double bPlusVolts = 185.0;
        double plateResistorOhms = 6200.0;
        double cathodeResistorOhms = 82.0;
        double inputScale = 1.0;
        double outputScale = 1.0;
    };

    Triode6922Stage();
    explicit Triode6922Stage(const Circuit& circuit);
    void reset() noexcept;
    double process(double gridAcVolts) noexcept;
    double quiescentCurrentAmps() const noexcept { return iq_; }
    double quiescentPlateVolts() const noexcept { return vaq_; }

    static double plateCurrentAmps(double vak, double vgk) noexcept;
private:
    double solveCurrent(double gridVolts, double initial) const noexcept;
    Circuit c_;
    double iq_ = 0.0;
    double vaq_ = 0.0;
    double previousI_ = 0.0;
};

// Two triode halves with a passive interstage divider.
class DualTriode6922 final {
public:
    DualTriode6922();
    void reset() noexcept;
    double process(double x) noexcept;
    void setInterstageAttenuation(double a) noexcept { interstageAttenuation_ = a; }
private:
    Triode6922Stage a_;
    Triode6922Stage b_;
    double interstageAttenuation_ = 0.40; // ASSUMPTION chosen for useful 737 gain structure.
};

}} // namespace a737::dsp
