#include "Triode6922.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {
namespace {
const double kMu = 33.0;
const double kReferenceCurrent = 15.0e-3;
const double kReferenceVak = 90.0;
const double kReferenceVgk = -1.3;
const double kEquivalentDrive = kReferenceVgk + kReferenceVak / kMu;
const double kK = kReferenceCurrent / (kEquivalentDrive * std::sqrt(kEquivalentDrive));
}

Triode6922Stage::Triode6922Stage() : c_() { reset(); }
Triode6922Stage::Triode6922Stage(const Circuit& circuit) : c_(circuit) { reset(); }

void Triode6922Stage::reset() noexcept {
    iq_ = solveCurrent(0.0, 0.012);
    previousI_ = iq_;
    vaq_ = c_.bPlusVolts - iq_ * c_.plateResistorOhms;
}

double Triode6922Stage::plateCurrentAmps(double vak, double vgk) noexcept {
    if (vak <= 0.0) return 0.0;
    const double drive = vgk + vak / kMu;
    if (drive <= 0.0) return 0.0;
    double current = kK * drive * std::sqrt(drive);
    // ASSUMPTION: soft emission/current ceiling prevents nonphysical runaway.
    const double maxCurrent = 25.0e-3;
    current = maxCurrent * std::tanh(current / maxCurrent);
    return std::max(0.0, current);
}

double Triode6922Stage::solveCurrent(double gridVolts, double initial) const noexcept {
    double i = clampd(initial, 0.0, 0.024);
    for (int n = 0; n < 6; ++n) {
        const double vk = i * c_.cathodeResistorOhms;
        const double va = c_.bPlusVolts - i * c_.plateResistorOhms;
        const double vak = std::max(0.0, va - vk);
        const double vgk = clampd(gridVolts * c_.inputScale - vk, -20.0, 2.0);
        const double model = plateCurrentAmps(vak, vgk);
        const double f = i - model;
        if (std::abs(f) < 1.0e-10) break;

        const double di = 1.0e-6;
        const double ip = clampd(i + di, 0.0, 0.0245);
        const double vkp = ip * c_.cathodeResistorOhms;
        const double vap = c_.bPlusVolts - ip * c_.plateResistorOhms;
        const double modelp = plateCurrentAmps(std::max(0.0, vap - vkp),
                                               clampd(gridVolts * c_.inputScale - vkp, -20.0, 2.0));
        const double fp = ip - modelp;
        const double derivative = (fp - f) / di;
        if (std::abs(derivative) < 1.0e-8) break;
        i = clampd(i - f / derivative, 0.0, 0.0245);
    }
    return i;
}

double Triode6922Stage::process(double gridAcVolts) noexcept {
    const double i = solveCurrent(gridAcVolts, previousI_);
    previousI_ = i;
    const double va = c_.bPlusVolts - i * c_.plateResistorOhms;
    // Coupling capacitor removes the DC operating point; the low-frequency pole
    // is far below audio in the assumed 10uF/1M interstage connection.
    return (va - vaq_) * c_.outputScale;
}

DualTriode6922::DualTriode6922() : a_(), b_() {}
void DualTriode6922::reset() noexcept { a_.reset(); b_.reset(); }
double DualTriode6922::process(double x) noexcept {
    const double y1 = a_.process(x);
    return b_.process(y1 * interstageAttenuation_);
}

}} // namespace a737::dsp
