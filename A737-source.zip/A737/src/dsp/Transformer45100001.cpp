#include "Transformer45100001.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {
namespace { const double kPi = 3.1415926535897932384626433832795; }

void Transformer45100001::setSampleRate(double sampleRate) noexcept {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    hfPole_.setSampleRate(sampleRate_);
    // ASSUMPTION: transformer itself is essentially flat through audible HF.
    hfPole_.setCutoff(std::min(120000.0, 0.45 * sampleRate_));
}
void Transformer45100001::reset() noexcept {
    fluxVs_ = 0.0;
    hfPole_.reset();
}
double Transformer45100001::process(double inputVolts) noexcept {
    const double dt = 1.0 / sampleRate_;
    const double leak = std::exp(-2.0 * kPi * fluxLeakHz_ * dt);
    fluxVs_ = leak * fluxVs_ + inputVolts * dt;

    const double z = fluxVs_ / fluxLimitVs_;
    double coreScale = 1.0;
    if (std::abs(z) > 1.0e-12) coreScale = std::tanh(z) / z;

    const double secondary = turnsRatio_ * inputVolts * coreScale;
    return hfPole_.lowpass(secondary);
}

}} // namespace a737::dsp
