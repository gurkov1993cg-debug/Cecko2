#include "PassiveFilters.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {
namespace { const double kPi = 3.1415926535897932384626433832795; }

void RCOnePole::setSampleRate(double sampleRate) noexcept {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    update();
}
void RCOnePole::setCutoff(double hz) noexcept {
    cutoff_ = clampd(hz, 0.001, 0.45 * sampleRate_);
    update();
}
void RCOnePole::reset(double value) noexcept { state_ = value; }
void RCOnePole::update() noexcept {
    a_ = std::exp(-2.0 * kPi * cutoff_ / sampleRate_);
}
double RCOnePole::lowpass(double x) noexcept {
    state_ = (1.0 - a_) * x + a_ * state_;
    return state_;
}
double RCOnePole::highpass(double x) noexcept {
    const double lp = lowpass(x);
    return x - lp;
}

void RCShelfCell::setSampleRate(double sampleRate) noexcept {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    update();
}
void RCShelfCell::setCorner(double hz) noexcept {
    cornerHz_ = clampd(hz, 0.001, 0.45 * sampleRate_);
    update();
}
void RCShelfCell::setGainDb(double db) noexcept {
    gainDb_ = db;
    update();
}
void RCShelfCell::reset() noexcept { x1_ = 0.0; y1_ = 0.0; }
void RCShelfCell::update() noexcept {
    // ASSUMPTION: pole/zero RC shelf with the selected Avalon frequency at the
    // geometric midpoint of the transition. This has an explicit first-order
    // analog realization and is superior to blending a generic low/high-pass.
    const double A = dbToGain(gainDb_);
    const double w = 2.0 * kPi * cornerHz_;
    const double rootA = std::sqrt(A);
    double pole = w;
    double zero = w;
    double k = 1.0;
    if (type_ == Type::Low) {
        zero = w * rootA;
        pole = w / rootA;
    } else {
        zero = w / rootA;
        pole = w * rootA;
        k = A;
    }
    const double c = 2.0 * sampleRate_;
    const double d0 = c + pole;
    b0_ = k * (c + zero) / d0;
    b1_ = k * (-c + zero) / d0;
    a1_ = (-c + pole) / d0;
}
double RCShelfCell::process(double x) noexcept {
    const double y = b0_ * x + b1_ * x1_ - a1_ * y1_;
    x1_ = x;
    y1_ = y;
    return y;
}

void GyratorMidCell::setSampleRate(double sampleRate) noexcept {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
}
void GyratorMidCell::setFrequency(double hz) noexcept {
    frequency_ = clampd(hz, 5.0, 0.40 * sampleRate_);
    updateComponents();
}
void GyratorMidCell::setQ(double q) noexcept {
    q_ = clampd(q, 0.05, 4.0);
    updateComponents();
}
void GyratorMidCell::setGainDb(double db) noexcept {
    gainDb_ = db;
    mix_ = dbToGain(db) - 1.0;
}
void GyratorMidCell::reset() noexcept {
    current_ = 0.0;
    capacitorV_ = 0.0;
}
void GyratorMidCell::updateComponents() noexcept {
    const double w = 2.0 * kPi * frequency_;
    l_ = 1.0 / (w * w * c_);
    r_ = w * l_ / q_;
}
double GyratorMidCell::process(double x) noexcept {
    // Series R-L-C state equations:
    // L di/dt = Vin - R*i - Vc ; C dVc/dt = i
    // A semi-implicit trapezoidal step keeps the resonator stable at audio rates.
    const double dt = 1.0 / sampleRate_;
    const double a = 0.5 * dt / l_;
    const double b = 0.5 * dt / c_;

    // Solve trapezoidal equations analytically for i[n+1].
    const double numerator = current_ + a * (2.0 * x - 2.0 * capacitorV_ - r_ * current_) - a * b * current_;
    const double denominator = 1.0 + a * r_ + a * b;
    const double newI = numerator / denominator;
    const double newVc = capacitorV_ + b * (current_ + newI);

    current_ = newI;
    capacitorV_ = newVc;

    const double band = r_ * current_;
    return x + mix_ * band;
}

}} // namespace a737::dsp
