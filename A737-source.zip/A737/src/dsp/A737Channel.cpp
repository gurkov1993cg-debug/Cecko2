#include "A737Channel.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {

A737Channel::A737Channel(double sampleRate)
    : compressor_(sampleRate), eq_(sampleRate),
      lineInputStage_(DiscreteClassAStage::Config()),
      outputStage_([](){ DiscreteClassAStage::Config c; c.railVolts=34.0; c.smallSignalGain=1.058; c.linearityVolts=26.0; c.outputResistanceOhms=35.0; c.loadOhms=600.0; return c; }()) {
    v1_.setInterstageAttenuation(0.40);
    v2_.setInterstageAttenuation(0.40);
    v3_.setInterstageAttenuation(0.20);
    setSampleRate(sampleRate);
    reset();
}
void A737Channel::setSampleRate(double sampleRate) {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    micTransformer_.setSampleRate(sampleRate_);
    compressor_.setSampleRate(sampleRate_);
    eq_.setSampleRate(sampleRate_);
    hpfLowpass_.setSampleRate(sampleRate_);
    setControls(controls_);
}
void A737Channel::setControls(const A737Controls& c) {
    controls_ = c;
    compressor_.setControls(c.compressor);
    eq_.setControls(c.eq);
    // CONFIRMED HPF range 30..140 Hz in current Avalon specification.
    hpfLowpass_.setCutoff(30.0 + 110.0 * clampd(c.highPassFrequency01, 0.0, 1.0));
}
void A737Channel::reset() {
    micTransformer_.reset(); v1_.reset(); v2_.reset(); v3_.reset();
    hpfLowpass_.reset(); compressor_.reset(); eq_.reset();
}

double A737Channel::gainPotAttenuation() const noexcept {
    const double p = clampd(controls_.preampGain01, 0.0, 1.0);
    double rangeDb = 55.0; // Line: -27..+28 = 55 dB documented range.
    if (controls_.inputMode == InputMode::Mic) rangeDb = 58.0;
    if (controls_.inputMode == InputMode::Instrument) rangeDb = 30.0;
    const double amin = dbToGain(-rangeDb);
    // ASSUMPTION: dual 25k linear sections form distributed passive dividers.
    // This expression is equivalent to a fixed bleed plus linear wiper travel.
    return amin + (1.0 - amin) * p;
}

double A737Channel::preamp(double volts) noexcept {
    double x = controls_.phaseReverse ? -volts : volts;
    const double att = gainPotAttenuation();

    if (controls_.inputMode == InputMode::Line) {
        // CONFIRMED routing: Line bypasses V1 and uses V2 path.
        x = lineInputStage_.process(x);
        x *= att;
        x = v2_.process(x * 0.025); // ASSUMPTION input scaling to the 6922 grid network.
        // Calibrate assumed V2 network to documented +28 dB max line gain.
        x *= 9.0;
        if (controls_.highGain) x *= dbToGain(8.0);
    } else {
        if (controls_.inputMode == InputMode::Mic) {
            x = micTransformer_.process(x);
            // ASSUMPTION: no extra mic pad at maximum gain; the reconstructed
            // transformer + V1/V2 network is calibrated by the interstage divider.
        } else {
            // CONFIRMED instrument impedance 1 Mohm; ASSUMPTION pad sets documented 30dB range.
            x *= 0.10;
        }
        // Dual gain pot sections at separate nodes. We split total attenuation
        // geometrically so both sections contribute without changing feedback.
        const double section = std::sqrt(att);
        x *= section;
        x = v1_.process(x);
        x *= section * 0.24; // ASSUMPTION passive inter-tube network.
        x = v2_.process(x);
        x *= 0.10;
        if (controls_.highGain) x *= dbToGain(18.0);
    }

    if (controls_.highPassEnabled) {
        // Passive first-order high-pass: y = x - RC low-pass node.
        x = hpfLowpass_.highpass(x);
    }
    return x;
}

double A737Channel::outputTrimGain() const noexcept {
    const double p = clampd(controls_.output01, 0.0, 1.0);
    // CONFIRMED range -45..+10 dB and center detent at nominal 0.
    // ASSUMPTION: piecewise calibrated law around the center detent.
    const double db = p <= 0.5 ? -45.0 + 90.0 * p : 20.0 * (p - 0.5);
    return dbToGain(db);
}

double A737Channel::processSample(double inputDigital) noexcept {
    if (controls_.bypass) return inputDigital;

    double x = digitalToVolts(inputDigital);
    x = preamp(x);

    // SC->MIDS stays active for compressor sidechain even if main EQ bypassed.
    const double sc = controls_.eq.sidechainMids ? eq_.processSidechainMids(x) : x;

    if (controls_.eqBeforeCompressor) {
        x = eq_.processAudio(x);
        x = compressor_.process(x, controls_.eq.sidechainMids ? sc : x);
    } else {
        x = compressor_.process(x, sc);
        x = eq_.processAudio(x);
    }

    x *= outputTrimGain();

    // CONFIRMED broad architecture: output pot -> V3 -> high-voltage-to-current
    // converter -> balanced DC-coupled Class-A output.
    // ASSUMPTION: reconstructed V3 dual triode is gain-normalized into the
    // discrete output block.
    x = v3_.process(x * 0.01745);
    x = outputStage_.process(x);
    return voltsToDigital(x);
}

}} // namespace a737::dsp
