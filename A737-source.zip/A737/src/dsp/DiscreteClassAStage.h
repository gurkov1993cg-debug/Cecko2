#pragma once

namespace a737 { namespace dsp {

// ASSUMPTION: equivalent emitter-degenerated Class-A differential/current-
// conversion stage. It reproduces the documented high-voltage headroom and
// low-order saturation without pretending to know the private 5600-7372 netlist.
class DiscreteClassAStage final {
public:
    struct Config {
        double railVolts = 34.0;          // CONFIRMED family: about +/-34 V.
        double smallSignalGain = 1.0;
        double linearityVolts = 20.0;     // ASSUMPTION emitter degeneration equivalent.
        double outputResistanceOhms = 50.0; // ASSUMPTION, comfortably drives 600 ohm spec.
        double loadOhms = 10000.0;
    };
    DiscreteClassAStage() : c_() {}
    explicit DiscreteClassAStage(const Config& c) : c_(c) {}
    double process(double x) const noexcept;
private:
    Config c_;
};

}} // namespace a737::dsp
