#pragma once

#include "VTL5C1Model.h"
#include "PassiveFilters.h"
#include "Triode6922.h"

namespace a737 { namespace dsp {

struct CompressorControls {
    bool enabled = false;
    double threshold01 = 0.5;   // -30..+20 dBu
    double compression01 = 0.5; // 1:1..20:1 front-panel intent
    double attack01 = 0.0;      // 2..200 ms
    double release01 = 0.0;     // 0.1..5 s
};

class OptoCompressor final {
public:
    explicit OptoCompressor(double sampleRate = 44100.0);
    void setSampleRate(double sampleRate);
    void setControls(const CompressorControls& c) noexcept { controls_ = c; }
    void reset();

    // sidechainVolts may differ from audioVolts when SC->MIDS is engaged.
    double process(double audioVolts, double sidechainVolts) noexcept;
    double gainReductionDb() const noexcept { return gainReductionDb_; }
    double ledCurrentAmps() const noexcept { return ledCurrentAmps_; }
    double ldrResistanceOhms() const noexcept { return cell_.resistanceOhms(); }

private:
    void updateEnvelope(double rectifiedVolts) noexcept;
    double thresholdPeakVolts() const noexcept;

    double sampleRate_ = 44100.0;
    CompressorControls controls_;
    VTL5C1Model cell_;
    DualTriode6922 v4_;
    double envelope_ = 0.0;
    double ledCurrentAmps_ = 0.0;
    double gainReductionDb_ = 0.0;

    // ASSUMPTION: VTL5C1 is the shunt leg of a passive divider. 1.8 kOhm
    // gives approximately -20 dB at the confirmed 200 Ohm/40mA endpoint.
    double dividerSeriesOhms_ = 1800.0;

    // ASSUMPTION: LF347 detector/driver equivalent transconductance.
    double ledDriverSiemens_ = 8.0e-3;
    // V4 path is gain-normalized after its nonlinear dual-triode behavior.
    double v4Makeup_ = 0.00872; // ASSUMPTION: ~1/114.6, unity small-signal through reconstructed V4.
};

}} // namespace a737::dsp
