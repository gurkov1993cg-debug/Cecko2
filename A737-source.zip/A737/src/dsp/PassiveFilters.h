#pragma once

namespace a737 { namespace dsp {

class RCOnePole final {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setCutoff(double hz) noexcept;
    void reset(double value = 0.0) noexcept;
    double lowpass(double x) noexcept;
    double highpass(double x) noexcept;
private:
    void update() noexcept;
    double sampleRate_ = 44100.0;
    double cutoff_ = 1000.0;
    double a_ = 0.0;
    double state_ = 0.0;
};

// ASSUMPTION: equivalent passive RC shelf cell. This is an explicit first-order
// RC branch plus a gain-recovery summing stage. It is not claimed to be the
// undisclosed 5600-7373 shelf netlist.
class RCShelfCell final {
public:
    enum class Type { Low, High };
    explicit RCShelfCell(Type type) : type_(type) {}
    void setSampleRate(double sampleRate) noexcept;
    void setCorner(double hz) noexcept;
    void setGainDb(double db) noexcept;
    void reset() noexcept;
    double process(double x) noexcept;
private:
    void update() noexcept;
    Type type_;
    double sampleRate_ = 44100.0;
    double cornerHz_ = 1000.0;
    double gainDb_ = 0.0;
    double b0_ = 1.0, b1_ = 0.0, a1_ = 0.0;
    double x1_ = 0.0, y1_ = 0.0;
};

// ASSUMPTION: active-gyrator equivalent of a series RLC band-pass branch used
// as the frequency-selective leg of a discrete Class-A peaking EQ. The state
// equations are solved directly with trapezoidal integration.
class GyratorMidCell final {
public:
    void setSampleRate(double sampleRate) noexcept;
    void setFrequency(double hz) noexcept;
    void setQ(double q) noexcept;
    void setGainDb(double db) noexcept;
    void reset() noexcept;
    double process(double x) noexcept;

    double equivalentR() const noexcept { return r_; }
    double equivalentL() const noexcept { return l_; }
    double equivalentC() const noexcept { return c_; }
private:
    void updateComponents() noexcept;
    double sampleRate_ = 44100.0;
    double frequency_ = 1000.0;
    double q_ = 0.2;
    double gainDb_ = 0.0;
    double mix_ = 0.0;

    // We choose a fixed gyrator capacitance and derive the equivalent L/R.
    // ASSUMPTION: 10 nF is a reconstruction convenience, not an OEM value.
    double c_ = 10.0e-9;
    double l_ = 1.0;
    double r_ = 1000.0;

    double current_ = 0.0;
    double capacitorV_ = 0.0;
};

}} // namespace a737::dsp
