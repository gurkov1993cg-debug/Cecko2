#include "OptoCompressor.h"
#include "AnalogMath.h"

#include <cmath>

namespace a737 { namespace dsp {

OptoCompressor::OptoCompressor(double sampleRate)
    : sampleRate_(sampleRate), cell_(sampleRate) {
    setSampleRate(sampleRate);
    v4_.setInterstageAttenuation(0.40);
    reset();
}

void OptoCompressor::setSampleRate(double sampleRate) {
    sampleRate_ = sampleRate > 1.0 ? sampleRate : 44100.0;
    cell_.setSampleRate(sampleRate_);
}
void OptoCompressor::reset() {
    envelope_ = 0.0;
    ledCurrentAmps_ = 0.0;
    gainReductionDb_ = 0.0;
    cell_.reset(0.0);
    v4_.reset();
}

double OptoCompressor::thresholdPeakVolts() const noexcept {
    const double dBu = -30.0 + 50.0 * clampd(controls_.threshold01, 0.0, 1.0);
    return dBuToVpeak(dBu);
}

void OptoCompressor::updateEnvelope(double rectifiedVolts) noexcept {
    // CONFIRMED control ranges: attack 2..200 ms, release 100 ms..5 s.
    // ASSUMPTION: map the linear front-panel pots linearly in time. The exact
    // LF347/C4/C5 resistor network is unpublished.
    const double attack = 0.002 + 0.198 * clampd(controls_.attack01, 0.0, 1.0);
    const double release = 0.100 + 4.900 * clampd(controls_.release01, 0.0, 1.0);
    const double tau = rectifiedVolts > envelope_ ? attack : release;
    const double a = std::exp(-1.0 / (sampleRate_ * tau));
    envelope_ = rectifiedVolts + (envelope_ - rectifiedVolts) * a;
}

double OptoCompressor::process(double audioVolts, double sidechainVolts) noexcept {
    if (!controls_.enabled) {
        // Hard-wire bypass concept: opto/ V4 are not in the audio path.
        ledCurrentAmps_ = 0.0;
        gainReductionDb_ = 0.0;
        updateEnvelope(std::abs(sidechainVolts));
        cell_.process(0.0);
        return audioVolts;
    }

    // ASSUMPTION: LF347 precision full-wave rectifier equivalent.
    updateEnvelope(std::abs(sidechainVolts));
    const double threshold = thresholdPeakVolts();
    const double over = std::max(0.0, envelope_ - threshold);

    // The 200-ohm COMPRESSION pot is reconstructed as a linear control of the
    // LED driver's transconductance. At zero it approaches 1:1; at maximum the
    // driver can reach the VTL5C1 40mA limit on strong over-threshold signals.
    const double c = clampd(controls_.compression01, 0.0, 1.0);
    ledCurrentAmps_ = clampd(ledDriverSiemens_ * c * over, 0.0, 40.0e-3);
    const double rLdr = cell_.process(ledCurrentAmps_);
    const double attenuation = rLdr / (dividerSeriesOhms_ + rLdr);
    gainReductionDb_ = -gainToDb(std::max(attenuation, 1.0e-9));

    const double attenuated = audioVolts * attenuation;
    // V4 is physically present for gain matching. We run the assumed 6922
    // circuit and normalize its nominal voltage gain back near unity.
    return v4_.process(attenuated * v4Makeup_);
}

}} // namespace a737::dsp
