# A737

Circuit-oriented Avalon VT-737sp VST3 reconstruction.

## Fixed project rules

- Direct Steinberg VST3 SDK; **no JUCE**.
- Own C++ DSP; no third-party audio-path DSP libraries.
- Target: Intel x86_64, macOS 10.13.
- Confirmed circuit facts remain separated from engineering assumptions.
- Assumption-filled sections are documented and replaceable when real schematic data appears.

## Current state

A complete working audio-path reconstruction now exists:

`Input -> transformer/line input -> V1/V2 -> passive HPF -> compressor/VTL5C1/V4 -> EQ -> Output -> V3 -> discrete Class-A output`

EQ/compressor order and SC->MIDS routing are implemented. The gain structure is calibrated at low signal to the documented Mic / Instrument / Line endpoint ranges.

See `docs/ENGINEERING_RECONSTRUCTION.md` for every non-confirmed circuit value and rationale.

## Build standalone DSP tests

```sh
cmake -S . -B build -DA737_BUILD_TESTS=ON -DA737_BUILD_VST3=OFF
cmake --build build
ctest --test-dir build --output-on-failure
```

## Fast macOS build

```sh
./build-macos.sh
```

This produces `dist/A737.vst3` and `dist/A737-macOS-Intel.zip`. See `BUILD_MACOS.md`.

## Build VST3

For the macOS 10.13 target use a Steinberg VST3 SDK 3.7.x checkout (the included CI workflow pins `v3.7.10_build_14`).

```sh
git clone --recursive --branch v3.7.10_build_14 https://github.com/steinbergmedia/vst3sdk.git vst3sdk
cmake -S . -B build-vst3 -GXcode \
  -DA737_BUILD_TESTS=OFF \
  -DA737_BUILD_VST3=ON \
  -DA737_VST3_SDK_ROOT="$PWD/vst3sdk" \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13
cmake --build build-vst3 --config Release --target A737
```

The VST3 wrapper has no JUCE/VSTGUI dependency and exposes the full parameter set to the host. The final custom production GUI must be connected to the approved A737 visual specification when that asset is available in the source tree.

## Native Vetra Audio GUI

The current source includes a native Cocoa/Core Graphics editor for macOS. It follows the approved Vetra Audio A737 brushed-metal channel-strip visual direction and does not depend on JUCE or VSTGUI. Knobs and buttons are true parameter controls, not a clickable screenshot. Double-click resets a knob; right-click opens numeric entry; switched controls snap to valid positions. Output and gain-reduction meters are fed by read-only processor output parameters.

See `docs/gui/GUI_SPEC.md` and `docs/gui/A737_GUI_REFERENCE.png`.
