# A737 engineering reconstruction ledger

This file records every place where the working A737 model intentionally fills an unpublished VT-737sp schematic gap by engineering reconstruction.

**Important:** these values are not claimed to be Avalon OEM component values. They exist so the complete signal path can run and be calibrated. Replace them when verified schematic data becomes available.

## CONFIRMED architecture retained

- Four 6922/E88CC dual triodes are represented as V1/V2/V3/V4 functional blocks.
- Mic input uses a transformer; line mode bypasses V1 and uses the V2 path.
- Optical gain reduction is a passive attenuator using a VTL5C1-type cell.
- Compressor gain matching is performed by V4.
- Bass/treble are shelving bands; two mids have sweep, Q and X10 functions.
- EQ is followed/implemented with high-voltage discrete Class-A gain stages.
- Output path is Output control -> V3 -> high-voltage/current-conversion -> balanced DC-coupled Class-A output.
- Compressor and EQ can be reordered; SC->MIDS sends the mid equalizer to the compressor sidechain.
- Nominal rail family used by the model: B+ 185 V, discrete rails about +/-34 V.

## ASSUMPTION: digital/analog calibration

- Full-scale sine peak 1.0 is mapped to +24 dBu RMS equivalent.
- This gives internal voltage-domain processing and leaves roughly 6 dB of modeled hardware output headroom above digital full scale, consistent with the documented +30 dBu hardware ceiling.

## ASSUMPTION: microphone transformer 4510-0001

- Turns ratio: 1:2.5 (7.96 dB voltage step-up).
- Core flux soft limit: 0.18 V*s.
- Flux leakage/relaxation pole: 1 Hz.
- HF pole: effectively above the audio band.

Rationale: the public specification states +26 dBu maximum mic input at 25 Hz and +30 dBu at 1 kHz. A flux-integrating core model naturally reduces LF headroom.

## ASSUMPTION: 6922 stage circuit

Each modeled triode half uses:

- B+ = 185 V.
- Ra = 6.2 kOhm.
- Rk = 82 Ohm.
- mu = 33.
- 3/2 Child-Langmuir style plate-current law, calibrated to 15 mA at Va=90 V and Vgk=-1.3 V.
- soft current ceiling = 25 mA.

The reconstructed quiescent point is approximately 14.9 mA and 92.9 V plate voltage. This conflicts with reports of ~180 V observed on tube pins in some VT-737sp units, therefore the R/C/bias network remains an explicit reconstruction rather than a confirmed Avalon netlist.

A `DualTriode6922` is two nonlinear triode halves in cascade with an interstage passive divider. Default divider = 0.40; V3 uses 0.20.

## ASSUMPTION: gain-control wiring

The dual 25 kOhm linear preamp gain pot is represented by two passive attenuator sections located at different nodes.

- Mic/Instrument: both sections participate, split geometrically around V1/V2.
- Line: one section participates and V1 is bypassed.
- No tube feedback coefficient is changed by the gain control.

The passive dividers are calibrated so small-signal endpoint gains match the documented ranges:

- Mic: approximately 0 to +58 dB.
- Instrument: approximately 0 to +30 dB.
- Line: approximately -27 to +28 dB.
- High Gain adds +18 dB in Mic/Instrument and +8 dB in Line.

The *law between endpoints* remains an engineering reconstruction of the physical linear-pot network.

## ASSUMPTION: passive opto divider / 5600-7374 missing netlist

- VTL5C1 is used as a shunt-to-ground variable resistor.
- Fixed series resistor = 1.8 kOhm.
- With R_LDR = 200 Ohm at 40 mA, the divider approaches 20 dB attenuation.
- U1/U2 LF347 behavior is represented as full-wave rectification plus timing and LED current drive.
- LED driver transconductance = 8 mA/V at maximum COMPRESSION setting.
- The 200 Ohm COMPRESSION control scales LED-driver transconductance from zero toward maximum.
- Attack and release controls map linearly to documented 2..200 ms and 0.1..5 s ranges.

These assumptions are replaceable when U1/U2/U5/RN1/RN2 and surrounding R/C netlist is recovered.

## CONFIRMED + INFERENCE: VTL5C1

The standalone VTL5C1 model continues to use confirmed R(I) anchor points and timing criteria. The interpolation and light-history kinetics remain explicitly tagged in source.

## ASSUMPTION: EQ 5600-7373 replacement circuit

The current working EQ is an explicit analog-equivalent circuit, not four generic digital biquads:

- Bass/Treble: first-order RC selective branch plus a Class-A recovery/summing stage.
- Mid bands: active-gyrator equivalent of a series RLC selective branch, integrated directly in state-space/trapezoidal form.
- Equivalent gyrator capacitor C = 10 nF; L and R are derived from requested f0 and Q.
- Q values use confirmed 0.20 / 0.85 settings.
- X10 multiplies center frequency by exactly ten.
- Boost/cut ranges use the documented shelf/mid ranges.

When the real 5600-7373 netlist is found, these cells are intended to be replaced node-for-node without changing the external parameter or routing architecture.

## ASSUMPTION: discrete Class-A stages / 5600-7372

The discrete stage is represented as an emitter-degenerated differential/current-conversion equivalent with:

- rail = +/-34 V;
- smooth differential-pair-style saturation;
- assumed 35..50 Ohm output source resistance depending on use;
- output load = 600 Ohm for the final balanced output model.

The final stage is calibrated for unity small-signal transfer around the center-detent output setting and preserves the documented high voltage headroom.

## ASSUMPTION: Output pot

The documented -45..+10 dB range and center detent are honored. Because the exact 25 kOhm surrounding network is missing, the implemented pot law is piecewise calibrated around the 0 dB center detent.

## Functional relay reconstruction

Known hardware routing is represented functionally:

- global bypass -> exact hard-wire pass;
- Line bypasses V1;
- compressor OFF removes opto/V4 audio path;
- EQ OFF removes EQ audio path;
- EQ-before-COMP changes serial order;
- SC->MIDS removes mids from main EQ processing and inserts them into compressor sidechain while shelves remain available in the main EQ path.

Unknown physical relay K-number/contact assignments are not fabricated.

## Replacement policy

Every value above is intentionally centralized/documented as an engineering reconstruction. New verified Avalon information must replace the corresponding assumption rather than being layered on top of it.
