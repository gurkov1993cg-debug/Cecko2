# A737 circuit data ledger

Every circuit fact used by DSP code must be tagged **CONFIRMED**, **INFERENCE**, or **UNKNOWN**.
No unknown component value may be silently replaced by a convenient value.

## VTL5C1 optocell

### CONFIRMED
Source: PerkinElmer/Excelitas VTL5C1 datasheet.

- `R(1 mA) = 20 kOhm` typical, dark adapted.
- `R(10 mA) = 600 Ohm` typical, dark adapted.
- `R(40 mA) = 200 Ohm` typical, dark adapted.
- `R(0.5 mA) / R(5 mA) = 15` typical slope definition.
- `R_dark >= 50 MOhm` after 10 s.
- LED maximum current `40 mA`.
- LED forward voltage `1.65 V typ.` at `20 mA` (`2.0 V` listed maximum/nominal column value).
- Cell voltage `100 V` maximum.
- Cell capacitance `5 pF`.
- Turn-on response `2.5 ms typ.` to 63% final `R_ON`.
- Turn-off response `35 ms max.` to `100 kOhm`.
- Datasheet output-resistance curves are specified under four light-adapt conditions:
  1. 25 C, 24 h, no input.
  2. 25 C, 24 h, 40 mA input.
  3. +50 C, 24 h, 40 mA input.
  4. -20 C, 24 h, 40 mA input.
- At 1 mA and below, units may have substantially higher resistance than the typical curves.
- Response-time curves are measured following light-adapt condition (2).

Primary public datasheet copy:
https://www.logosfoundation.org/instrum_gwr/playerpiano/Optor_VTL5C1_87223.pdf

### INFERENCE used by `VTL5C1Model`

- Static transfer is represented in log(I)-log(R).
- The 0.5..5 mA region is a power-law segment constrained by the confirmed slope ratio 15 and anchored at the confirmed 1 mA / 20 kOhm point.
- The 5..10 mA gap is joined with a cubic Hermite segment in log-log coordinates so value and local slope stay continuous.
- The 10..40 mA region is a straight log-log interpolation between the two confirmed endpoints.
- Dynamic state is conductance `G=1/R`, with independent turn-on and turn-off poles.
- `2.5 ms` is used as the nominal turn-on pole because it is the confirmed 63% response criterion.
- The nominal turn-off pole is mathematically derived so a 200 Ohm start reaches 100 kOhm after 35 ms while asymptoting to the 50 MOhm project clamp. It is not claimed as a measured physical tau.

### UNKNOWN / calibration-only

- Exact transfer below 0.5 mA.
- Exact selected-cell bin used by a specific VT-737sp unit.
- Current dependence of turn-on time.
- Multi-time-constant shape of turn-off/recovery.
- Exact numeric displacement between light-adapt curves 1 and 2.
- Light-history attack/release kinetics.
- Current-to-history-target law.

The corresponding code fields are explicitly marked `ASSUMPTION` / `TODO: verify`.

## VTL5C1 response-time clarification

- **CONFIRMED:** the PerkinElmer specification notes define ascent as reaching 63% of final conductance after application of 40 mA input.
- **CONFIRMED:** response-time characteristics are specified after light-adapt condition (2): 25 C, 24 hours at 40 mA input.
- **CONFIRMED:** decay is specified as time to 100 kOhm, maximum 35 ms for VTL5C1.
- **INFERENCE:** A737's current v1 component model uses a single-pole conductance release calibrated from 200 Ohm (the 40 mA anchor) to reach 100 kOhm in 35 ms. This is a constrained numerical model, not a claim that the physical VTL5C1 has a single exponential release.
