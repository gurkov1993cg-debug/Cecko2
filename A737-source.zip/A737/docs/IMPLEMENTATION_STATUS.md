# A737 implementation status

## Implemented and tested

### VTL5C1 component model

- Static nominal `R(I_LED)` from confirmed datasheet anchors.
- Log-log constrained segment for the specified slope ratio.
- Smooth 5–10 mA bridge without introducing an invented component value.
- Clamp at the project nominal 50 MOhm dark resistance.
- Separate turn-on / turn-off conductance dynamics.
- Turn-on test uses the datasheet response-test condition of a 40 mA step.
- Turn-off derived one-pole calibration is constrained to reach 100 kOhm after 35 ms starting from the confirmed 40 mA / 200 Ohm state.
- Light-history state exists, but its kinetics and curve displacement are disabled by default because those numerical values remain UNKNOWN.

All non-confirmed modelling choices are marked `ASSUMPTION` or `INFERENCE` in source.

## Not implemented on purpose

The following blocks are deliberately not replaced by generic DSP:

- 5600-7374 detector / rectifier / LED driver / ratio law.
- Passive compressor divider topology.
- V4 tube gain-matching circuit.
- 5600-7373 EQ network.
- 5600-7372 discrete input/output network.
- V1..V4 tube circuits where R/C/bias data are missing.
- Unknown relay contacts/routing.
- Production GUI until the exact approved layout/assets/specification are available in the working tree.

## Verification

Local standalone C++14 build and tests pass with CMake/CTest.
Target constraints encoded in CMake for Apple: x86_64 and macOS deployment target 10.13.
