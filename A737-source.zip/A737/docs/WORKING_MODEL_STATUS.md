# A737 working model status

The project now contains a complete runnable DSP path under the engineering-reconstruction policy requested by the user.

Implemented:

1. Digital-to-analog voltage calibration.
2. Mic transformer flux/headroom model.
3. Mic / Instrument / Line routing.
4. Dual-section preamp gain control reconstruction.
5. V1 and V2 6922 nonlinear circuit stages.
6. Passive first-order HPF.
7. VTL5C1 dynamic optocell.
8. Compressor full-wave detector, attack/release RC behavior, LED driver reconstruction and passive optical divider.
9. V4 nonlinear gain-matching tube path.
10. Bass / low-mid / high-mid / treble analog-equivalent EQ circuits.
11. Q and X10 functions.
12. SC->MIDS sidechain routing.
13. EQ pre/post compressor routing.
14. Output control.
15. V3 nonlinear tube output path.
16. Discrete high-voltage Class-A output equivalent.
17. Exact global bypass.
18. Direct Steinberg VST3 processor/controller wrapper, without JUCE and without VSTGUI dependency.
19. 32-bit and 64-bit VST3 processing paths.
20. State serialization and host-automatable parameters.

Current standalone C++14 tests validate:

- VTL5C1 anchor/timing constraints.
- finite/stable full channel processing.
- exact hard bypass.
- compressor finite operation.
- endpoint gain calibration for Mic / Instrument / Line.

Not claimed:

- The assumption-filled blocks are not a recovered OEM Avalon schematic.
- The production 1:1 approved GUI is not present in the current repository/source material. The VST3 wrapper therefore exposes the complete parameter set to the host, but a final custom editor must use the approved A737 GUI asset/spec when that source becomes available.
