# A737 validation snapshot

Standalone C++14 DSP validation passed on the development container.

## Automated tests

- VTL5C1 static anchor points: pass.
- VTL5C1 slope ratio: pass.
- VTL5C1 2.5 ms conductance turn-on criterion: pass.
- VTL5C1 35 ms / 100 kOhm release constraint: pass.
- Full A737 signal path finite/stable: pass.
- Exact hard bypass: pass.
- Compressor finite operation: pass.
- Reconstructed endpoint gain calibration: pass.

Measured low-level endpoint gains (1 kHz):

- Mic minimum: about -0.07 dB (target 0 dB).
- Mic maximum: about +57.91 dB (target +58 dB).
- Instrument minimum: about -0.03 dB (target 0 dB).
- Instrument maximum: about +29.97 dB (target +30 dB).
- Line minimum: about -27.02 dB (target -27 dB).
- Line maximum: about +28.18 dB (target +28 dB).
- Line High Gain delta: +8.0 dB.

Selected EQ reconstruction checks at 96 kHz:

- Bass +24 dB / 60 Hz selection: about +19.6 dB at 20 Hz, ~+0.2 dB at 1 kHz.
- Treble +20 dB / 10 kHz selection: about +15.5 dB at 20 kHz, ~+0.37 dB at 1 kHz.
- Low-mid +16 dB / 1 kHz / Q=0.85: about +16.0 dB at 1 kHz.
- Maximum opto drive: VTL5C1 reaches 40 mA / 200 Ohm and the assumed 1.8 kOhm divider produces 20 dB gain reduction.

These values validate the engineering reconstruction, not an OEM component-identical circuit.
