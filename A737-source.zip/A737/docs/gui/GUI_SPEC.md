# A737 GUI Specification — locked visual direction

Status: **APPROVED VISUAL DIRECTION**

Reference: `A737_GUI_REFERENCE.png`.

The plug-in GUI must preserve the approved visual language:

- wide rack/channel-strip composition;
- brushed silver central faceplate;
- black header and lower ventilation/footer zones;
- premium **Vetra Audio** metal logo treatment;
- dark machined rotary controls with silver faces, tick rings and thin white pointers;
- red illuminated square push buttons;
- central warm analog VU meter;
- sections from left to right: Input / HPF / Equalizer / VU+brand / Compressor / Output;
- compact, hardware-like typography and engraved/divider lines;
- no generic flat DAW controls replacing the approved hardware style.

## Runtime implementation

The first runtime implementation is native Cocoa (`A737CocoaView.mm`), using Core Graphics/Cocoa drawing. It intentionally does **not** use JUCE or VSTGUI. Controls are drawn and hit-tested individually rather than using the reference PNG as a clickable bitmap.

Design coordinate system: **1648 × 880**.

The editor is currently fixed-size to preserve the approved proportions on macOS 10.13-era hosts.

## Functional controls wired

- Input mode: MIC / LINE / INST
- Preamp Gain
- High Gain
- Phase
- HPF In + frequency
- Bass gain + switched frequency
- Low Mid gain/frequency + X10 + Q
- High Mid gain/frequency + X10 + Q
- Treble gain + switched frequency
- EQ In
- SC -> MIDS
- Threshold / Compression / Attack / Release
- Compressor In
- EQ -> Compressor routing
- Output
- Global Bypass
- live Output VU and GR display values from processor read-only parameters

No decorative software control is allowed to masquerade as functional hardware. Phantom power is therefore not exposed as an active plug-in control in this build.

## Interaction policy

- drag vertically on knobs;
- double-click a knob resets it to project default;
- buttons are host-automatable gestures through `beginEdit / performEdit / endEdit`;
- switched frequency knobs snap to their real discrete positions.

## TODO before visual lock release

- exact typography pass against approved reference;
- final calibrated tick labels for every control;
- numeric-entry overlay for every parameter;
- A/B and preset header controls once the preset subsystem is implemented;
- final VU ballistics calibration and needle graphics;
- Retina verification on 1x/2x displays;
- screenshot comparison against reference on macOS host.
