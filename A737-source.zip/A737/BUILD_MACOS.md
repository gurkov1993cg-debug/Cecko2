# A737 macOS Intel build

Target: macOS 10.13+, Intel x86_64, Steinberg VST3 SDK 3.7.10, no JUCE.

## One-command build

Open Terminal in the A737 folder and run:

```bash
./build-macos.sh
```

The script downloads the pinned VST3 SDK if missing, builds and runs the DSP tests, builds the VST3 with Xcode, verifies the Intel executable, and creates:

- `dist/A737.vst3`
- `dist/A737-macOS-Intel.zip`

To install for the current user:

```bash
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3"
ditto dist/A737.vst3 "$HOME/Library/Audio/Plug-Ins/VST3/A737.vst3"
```

Then restart/rescan the DAW.
