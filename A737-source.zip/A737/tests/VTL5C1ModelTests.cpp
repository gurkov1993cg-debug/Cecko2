#include "VTL5C1Model.h"

#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>

namespace {
bool approx(double a, double b, double relativeTolerance) {
    const double scale = std::max(std::abs(a), std::abs(b));
    return scale == 0.0 ? true : std::abs(a - b) <= relativeTolerance * scale;
}
}

int main() {
    using a737::dsp::VTL5C1Model;

    // Confirmed datasheet anchor points must be hit exactly by nominal transfer.
    assert(approx(VTL5C1Model::nominalResistanceOhms(1.0e-3), 20000.0, 1.0e-12));
    assert(approx(VTL5C1Model::nominalResistanceOhms(10.0e-3), 600.0, 1.0e-12));
    assert(approx(VTL5C1Model::nominalResistanceOhms(40.0e-3), 200.0, 1.0e-12));

    // Slope constraint R(0.5 mA) / R(5 mA) = 15.
    const double r05 = VTL5C1Model::nominalResistanceOhms(0.5e-3);
    const double r5 = VTL5C1Model::nominalResistanceOhms(5.0e-3);
    assert(approx(r05 / r5, 15.0, 1.0e-12));

    // Project dark clamp.
    assert(approx(VTL5C1Model::nominalResistanceOhms(0.0), 50.0e6, 1.0e-12));

    // Dynamic turn-on: 2.5 ms first-order conductance response should be near 63.2%.
    constexpr double sampleRate = 192000.0;
    VTL5C1Model cell(sampleRate);
    cell.reset(0.0);
    const double g0 = 1.0 / 50.0e6;
    const double gFinal = 1.0 / 200.0;
    const int nOn = static_cast<int>(std::lround(0.0025 * sampleRate));
    for (int i = 0; i < nOn; ++i) {
        cell.process(40.0e-3);
    }
    const double fraction = (cell.conductanceSiemens() - g0) / (gFinal - g0);
    assert(std::abs(fraction - (1.0 - std::exp(-1.0))) < 0.005);

    // Datasheet response test uses application/removal of 40 mA. Derived release
    // tau must therefore satisfy 35 ms -> 100 kOhm starting from 200 Ohm.
    VTL5C1Model releaseCell(sampleRate);
    releaseCell.reset(40.0e-3);
    const int nOff = static_cast<int>(std::lround(0.035 * sampleRate));
    double r = 0.0;
    for (int i = 0; i < nOff; ++i) {
        r = releaseCell.process(0.0);
    }
    assert(r >= 99000.0 && r <= 102000.0);


    // Nominal transfer must remain finite and monotonic over the modelled LED range.
    double previousR = VTL5C1Model::nominalResistanceOhms(0.0);
    for (int i = 1; i <= 4000; ++i) {
        const double current = 40.0e-3 * static_cast<double>(i) / 4000.0;
        const double currentR = VTL5C1Model::nominalResistanceOhms(current);
        assert(std::isfinite(currentR));
        assert(currentR <= previousR * (1.0 + 1.0e-12));
        previousR = currentR;
    }

    // The absolute-maximum LED-current clamp prevents extrapolation above 40 mA.
    assert(approx(VTL5C1Model::nominalResistanceOhms(100.0e-3), 200.0, 1.0e-12));

    // Light-history kinetics are intentionally disabled until calibrated.
    VTL5C1Model uncalibratedHistory(sampleRate);
    for (int i = 0; i < static_cast<int>(sampleRate); ++i) {
        uncalibratedHistory.process(40.0e-3);
    }
    assert(uncalibratedHistory.lightHistoryState() == 0.0);

    std::cout << "VTL5C1Model tests passed\n";
    return 0;
}
