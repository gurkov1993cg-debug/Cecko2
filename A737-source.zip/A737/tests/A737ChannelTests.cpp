#include "A737Channel.h"
#include "AnalogMath.h"

#include <cassert>
#include <cmath>
#include <iostream>

int main() {
    using namespace a737::dsp;
    const double fs = 48000.0;
    A737Channel ch(fs);
    A737Controls c;
    c.inputMode = InputMode::Line;
    c.preampGain01 = 0.5;
    c.output01 = 0.5;
    ch.setControls(c);
    ch.reset();

    // silence remains finite and near zero
    for (int i=0;i<1000;++i) {
        const double y = ch.processSample(0.0);
        assert(std::isfinite(y));
        assert(std::abs(y) < 1.0e-8);
    }

    // signal path must be finite for a useful audio range
    for (int i=0;i<48000;++i) {
        const double x = 0.05 * std::sin(2.0 * 3.141592653589793 * 1000.0 * i / fs);
        const double y = ch.processSample(x);
        assert(std::isfinite(y));
        assert(std::abs(y) < 100.0);
    }

    // Hard-wire global bypass is exact in the digital wrapper.
    c.bypass = true;
    ch.setControls(c);
    const double test = 0.123456789;
    assert(ch.processSample(test) == test);

    // Compressor path produces non-negative GR and finite output.
    c.bypass = false;
    c.compressor.enabled = true;
    c.compressor.threshold01 = 0.0;
    c.compressor.compression01 = 1.0;
    c.compressor.attack01 = 0.0;
    c.compressor.release01 = 0.0;
    c.preampGain01 = 1.0;
    ch.setControls(c);
    ch.reset();
    for (int i=0;i<24000;++i) ch.processSample(0.5 * std::sin(2.0 * 3.141592653589793 * 500.0 * i / fs));
    assert(ch.gainReductionDb() >= 0.0);
    assert(std::isfinite(ch.gainReductionDb()));


    auto measureGainDb = [fs](InputMode mode, double gain01, bool highGain) {
        A737Channel m(fs);
        A737Controls mc;
        mc.inputMode = mode;
        mc.preampGain01 = gain01;
        mc.highGain = highGain;
        mc.output01 = 0.5;
        m.setControls(mc);
        m.reset();
        double si = 0.0, so = 0.0;
        for (int i=0;i<24000;++i) {
            const double x = 1.0e-4 * std::sin(2.0 * 3.141592653589793 * 1000.0 * i / fs);
            const double y = m.processSample(x);
            if (i > 1000) { si += x*x; so += y*y; }
        }
        return 10.0 * std::log10(so / si);
    };
    // Engineering reconstruction is calibrated to confirmed endpoint ranges.
    assert(std::abs(measureGainDb(InputMode::Mic, 0.0, false) - 0.0) < 1.0);
    assert(std::abs(measureGainDb(InputMode::Mic, 1.0, false) - 58.0) < 1.0);
    assert(std::abs(measureGainDb(InputMode::Instrument, 0.0, false) - 0.0) < 1.0);
    assert(std::abs(measureGainDb(InputMode::Instrument, 1.0, false) - 30.0) < 1.0);
    assert(std::abs(measureGainDb(InputMode::Line, 0.0, false) - (-27.0)) < 1.0);
    assert(std::abs(measureGainDb(InputMode::Line, 1.0, false) - 28.0) < 1.0);
    assert(std::abs((measureGainDb(InputMode::Line, 1.0, true) - measureGainDb(InputMode::Line, 1.0, false)) - 8.0) < 0.5);

    std::cout << "A737Channel tests passed\n";
    return 0;
}
