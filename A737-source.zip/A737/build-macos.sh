#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

SDK_DIR="${A737_VST3_SDK_ROOT:-$ROOT/vst3sdk}"

if [ ! -f "$SDK_DIR/CMakeLists.txt" ]; then
  echo "Fetching Steinberg VST3 SDK 3.7.10..."
  git clone --recursive --branch v3.7.10_build_14 --depth 1 \
    https://github.com/steinbergmedia/vst3sdk.git "$SDK_DIR"
fi

export MACOSX_DEPLOYMENT_TARGET=10.13

rm -rf build-tests build-vst3 dist

cmake -S . -B build-tests \
  -DA737_BUILD_TESTS=ON \
  -DA737_BUILD_VST3=OFF \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13

cmake --build build-tests --config Release -j 4
ctest --test-dir build-tests -C Release --output-on-failure

cmake -S . -B build-vst3 -GXcode \
  -DA737_BUILD_TESTS=OFF \
  -DA737_BUILD_VST3=ON \
  -DA737_VST3_SDK_ROOT="$SDK_DIR" \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13

cmake --build build-vst3 --config Release --target A737

VST="$(find build-vst3 -type d -name 'A737.vst3' -print -quit)"
if [ -z "$VST" ]; then
  echo "ERROR: A737.vst3 was not produced"
  exit 1
fi

BIN="$(find "$VST/Contents/MacOS" -type f -print -quit)"
if [ -z "$BIN" ]; then
  echo "ERROR: VST3 executable was not found"
  exit 1
fi

mkdir -p dist
ditto "$VST" dist/A737.vst3
file "$BIN" | tee dist/binary-info.txt

if command -v xcrun >/dev/null 2>&1 && xcrun --find vtool >/dev/null 2>&1; then
  xcrun vtool -show-build "$BIN" | tee dist/deployment-info.txt
fi

ditto -c -k --sequesterRsrc --keepParent dist/A737.vst3 dist/A737-macOS-Intel.zip

echo
echo "DONE"
echo "VST3: $ROOT/dist/A737.vst3"
echo "ZIP : $ROOT/dist/A737-macOS-Intel.zip"
