# GitHub build layout

This ZIP is intended to live at the repository root as `A737-source.zip`.
The GitHub Actions workflow must live separately at:

`.github/workflows/build-a737.yml`

The workflow extracts this ZIP, runs the DSP tests, checks out Steinberg VST3 SDK 3.7.10, builds the Intel x86_64 VST3 with macOS 10.13 deployment target, validates the binary, and uploads the built plug-in as an Actions artifact.
